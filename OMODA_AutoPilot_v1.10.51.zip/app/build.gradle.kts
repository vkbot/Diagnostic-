plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.omoda.autopilot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.github.uiautomator"
        minSdk = 23
        targetSdk = 28
        versionCode = 73
        versionName = "1.10.51"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        // targetSdk 28 намеренно: на Android 11 setWifiEnabled() не работает с targetSdk 29+.
        disable.add("ExpiredTargetSdkVersion")
        abortOnError = true
    }
}
