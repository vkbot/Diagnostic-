package ru.omoda.autopilot

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import java.io.File

/** Перехватывает INSTALL_PACKAGE от RuStore: копирует APK из content:// и ставит через pm install. */
class InterceptInstallActivity : Activity() {
    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        out = TextView(this).apply { textSize = 22f; setPadding(40, 40, 40, 40) }
        setContentView(out)
        val uri = intent?.data
        if (uri == null) {
            out.text = "Нет данных установки"
            return
        }
        out.text = "Получен запрос установки. Копирую APK..."
        Thread {
            val msg = try { install(uri) } catch (e: Exception) { "ошибка: ${e.javaClass.simpleName}: ${e.message}" }
            SettingsRepository(applicationContext).addEvent("перехват установки: $msg")
            runOnUiThread { out.text = msg }
        }.start()
    }

    /** Копирует поток из провайдера в свой каталог и ставит через pm install (этот путь у нас работает). */
    private fun install(uri: Uri): String {
        val file = File(filesDir, "incoming.apk")
        val input = contentResolver.openInputStream(uri) ?: return "не открылся поток: $uri"
        input.use { i -> file.outputStream().use { i.copyTo(it) } }
        if (file.length() == 0L) return "файл пустой"
        val p = ProcessBuilder("sh", "-c", "pm install -r -S ${file.length()}").redirectErrorStream(true).start()
        file.inputStream().use { it.copyTo(p.outputStream) }
        p.outputStream.close()
        val res = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        file.delete()
        return res.ifEmpty { "pm: пустой ответ" }
    }
}
