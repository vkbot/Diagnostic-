package ru.omoda.autopilot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var settings: SettingsRepository
    private lateinit var status: TextView
    private lateinit var eventsView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsRepository(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("OMODA AutoPilot", 26f))
        root.addView(labelView(versionText(), 14f, 4))
        status = labelView("", 14f, 16)
        root.addView(status)

        val run = actionButton("ЗАПУСТИТЬ") { runNow() }
        run.textSize = 22f
        run.minimumHeight = dp(96)
        val runParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        runParams.topMargin = dp(24)
        root.addView(run, runParams)

        root.addView(actionButton("Настройки") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        root.addView(actionButton("Обновить статус") { refreshStatus() })
        root.addView(actionButton("Установка с флешки") {
            startActivity(Intent(this, InstallTestActivity::class.java))
        })
        root.addView(actionButton("Настройки Android") {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        })
        root.addView(labelView("Уведомления", 16f, 20))
        eventsView = labelView("", 13f, 4)
        root.addView(eventsView)

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            refreshStatus()
            handler.post(ticker)
        }
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun versionText(): String =
        try {
            val info = packageManager.getPackageInfo(packageName, 0)
            "Версия ${info.versionName} (код ${info.versionCode})"
        } catch (e: Exception) {
            "Версия неизвестна"
        }

    private fun runOneCommand(cmd: String) {
        val appContext = applicationContext
        toast("Выполняется: $cmd")
        Thread {
            SettingsRepository(appContext).addEvent("shell «$cmd»: " + runShell(cmd))
        }.start()
    }

    private fun runDiagnostics() {
        val appContext = applicationContext
        toast("Диагностика запущена, результаты в разделе «Уведомления»")
        Thread {
            val repo = SettingsRepository(appContext)
            val commands = listOf(
                "settings get global wifi_on",
                "settings get global airplane_mode_on",
                "cmd wifi status",
                "svc wifi enable",
                "settings get global wifi_on"
            )
            for (cmd in commands) {
                repo.addEvent("shell «$cmd»: " + runShell(cmd))
            }
        }.start()
    }

    private fun runShell(cmd: String): String =
        try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            process.waitFor(10, TimeUnit.SECONDS)
            (out + err).trim().replace(Regex("\\s+"), " ").take(300).ifEmpty { "пусто" }
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }

    private fun runNow() {
        startService(Intent(this, AutoPilotService::class.java).setAction(AutoStartConfig.ACTION_RUN_ALL))
        toast("Запущено. Результат появится в статусе и в уведомлении")
    }

    private fun refreshStatus() {
        val autoOn = settings.isWifiEnabledOnBoot() || settings.isLaunchEnabledOnBoot()
        val lines = mutableListOf<String>()
        lines.add("Автозапуск при загрузке: " + (if (autoOn) "включён" else "выключен"))
        lines.add(
            if (settings.ranThisBoot()) "После текущего включения уже запускалось."
            else "После текущего включения ещё не запускалось."
        )
        lines.add(SystemSignature.statusLine(this))
        val last = settings.lastResult()
        if (last.isNotEmpty()) {
            val time = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())
                .format(Date(settings.lastResultTime()))
            lines.add("")
            lines.add("Последний запуск $time:")
            lines.add(last)
        }
        status.text = lines.joinToString("\n")
        eventsView.text = settings.events().ifEmpty { listOf("Пока пусто") }.joinToString("\n")
    }
}
