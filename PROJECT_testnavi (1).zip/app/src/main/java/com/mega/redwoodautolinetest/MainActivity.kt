package com.mega.redwoodautolinetest

import android.app.Activity
import android.content.Intent
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import javax.net.ssl.HttpsURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        const val NAVI_PKG = "ru.yandex.yandexnavi"
        const val OVERALL_URL = "https://backapi.rustore.ru/applicationData/overallInfo/$NAVI_PKG"
        const val LINK_URL = "https://backapi.rustore.ru/applicationData/download-link"
        const val APK_NAME = "yandex_navigator.apk"
        const val SYSTEM_UID = 1000
    }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = "Готово"
        }
        val wifiBtn = Button(this).apply {
            text = "Включить Wi-Fi"
            setOnClickListener { enableWifi() }
        }
        val settingsBtn = Button(this).apply {
            text = "Открыть настройки Wi-Fi"
            setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        }
        val installBtn = Button(this).apply {
            text = "Скачать и установить Яндекс Навигатор"
            setOnClickListener { installNavigator() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(wifiBtn)
            addView(settingsBtn)
            addView(installBtn)
            addView(status)
        })
    }

    private fun show(text: String) = runOnUiThread { status.text = text }

    private fun enableWifi() {
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        wifi.isWifiEnabled = true
        show("Wi-Fi включён")
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo?.isConnected == true
    }

    // Папка приложения на внешнем хранилище: запись без общих прав (Android 13+)
    private fun apkFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        dir.mkdirs()
        return File(dir, APK_NAME)
    }

    private fun httpJson(url: String, method: String, body: JSONObject? = null): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 15000
            // RuStore с июля 2026 требует заголовок версии клиента (число >= 247)
            c.setRequestProperty("ruStoreVerCode", "2000000000")
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw IOException("HTTP $code")
            return JSONObject(c.inputStream.bufferedReader().readText())
        } finally {
            c.disconnect()
        }
    }

    private fun progressText(done: Long, total: Long): String {
        val doneMb = String.format("%.1f", done / 1048576.0)
        return if (total > 0) {
            val pct = done * 100 / total
            val totalMb = String.format("%.1f", total / 1048576.0)
            "Загрузка: $pct% ($doneMb из $totalMb МБ)"
        } else {
            "Загрузка: $doneMb МБ"
        }
    }

    // Шаг 1: GET -> body.appId; Шаг 2: POST -> body.apkUrl; Шаг 3: прямая загрузка APK
    private fun installNavigator() {
        if (!isOnline()) {
            show("Нет подключения к сети. Включите Wi-Fi.")
            return
        }
        show("Получаю ссылку из RuStore...")
        Thread {
            val apkUrl: String
            try {
                val appId = httpJson(OVERALL_URL, "GET")
                    .getJSONObject("body").getLong("appId")
                apkUrl = httpJson(
                    LINK_URL, "POST",
                    JSONObject().put("appId", appId).put("firstInstall", true)
                ).getJSONObject("body").getString("apkUrl")
            } catch (e: Exception) {
                show("Ошибка RuStore: ${e.message}")
                return@Thread
            }
            try {
                downloadFile(apkUrl, BundledTrust.socketFactory(this, R.raw.ru_root_ca))
            } catch (e: Exception) {
                apkFile().delete()
                show("Ошибка загрузки: ${e.javaClass.simpleName}: ${e.message}")
                return@Thread
            }
            runOnUiThread { install() }
        }.start()
    }

    private fun downloadFile(url: String, sslFactory: javax.net.ssl.SSLSocketFactory) {
        val file = apkFile()
        file.delete()
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            if (c is HttpsURLConnection) c.sslSocketFactory = sslFactory
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("ruStoreVerCode", "2000000000")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11)")
            val code = c.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw IOException("HTTP $code")
            val total = c.contentLengthLong
            var done = 0L
            var lastUi = 0L
            show(progressText(0, total))
            c.inputStream.use { input ->
                file.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 500) {
                            lastUi = now
                            show(progressText(done, total))
                        }
                    }
                }
            }
            if (total > 0 && done != total) throw IOException("получено $done из $total байт")
            unwrapContainer(file)
            show("Загрузка завершена: ${progressText(done, total).removePrefix("Загрузка: ")}")
        } finally {
            c.disconnect()
        }
    }

    // Проверка файла до установки: заголовок ZIP, разбор Android, нужный пакет
    // RuStore отдаёт ZIP-обёртку: внутри один APK (и служебные файлы). Достаём APK.
    private fun unwrapContainer(file: File) {
        val tmp = File(file.parentFile, "inner.tmp")
        val extracted = java.util.zip.ZipFile(file).use { z ->
            if (z.getEntry("AndroidManifest.xml") != null) return
            val inner = z.entries().toList()
                .firstOrNull { it.name.endsWith(".apk", ignoreCase = true) } ?: return
            z.getInputStream(inner).use { inp -> tmp.outputStream().use { inp.copyTo(it, 64 * 1024) } }
            true
        }
        if (extracted) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    private fun install() {
        val apk = apkFile()
        val head = ByteArray(4)
        val n = apk.inputStream().use { it.read(head) }
        val hex = head.take(maxOf(n, 0)).joinToString(" ") { "%02X".format(it) }
        val sizeMb = String.format("%.1f", apk.length() / 1048576.0)
        if (n < 2 || head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) {
            show("Файл не APK: заголовок [$hex], размер $sizeMb МБ")
            return
        }
        val info = packageManager.getPackageArchiveInfo(apk.absolutePath, 0)
        if (info == null) {
            show("Android не разобрал APK: размер $sizeMb МБ, заголовок [$hex]\n${zipContents(apk)}")
            return
        }
        if (info.packageName != NAVI_PKG) {
            show("Это не Яндекс Навигатор: ${info.packageName}")
            return
        }
        show("APK ок: ${info.packageName} ${info.versionName}, $sizeMb МБ")
        if (Process.myUid() == SYSTEM_UID) installSilently() else installWithPrompt()
    }

    // ГУ (системный uid): APK подаётся в pm install через стандартный ввод (pm install -S),
    // без записи на диск: запись в /data/local/tmp из приложения запрещена SELinux (EACCES)
    private fun installSilently() {
        show("Установка...")
        Thread {
            val src = apkFile()
            try {
                val p = Runtime.getRuntime().exec(
                    arrayOf("pm", "install", "-r", "-S", src.length().toString())
                )
                src.inputStream().use { it.copyTo(p.outputStream, 64 * 1024) }
                p.outputStream.close()
                val out = p.inputStream.bufferedReader().readText() +
                    p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                show(
                    if (code == 0 && out.contains("Success")) "Яндекс Навигатор установлен"
                    else "Ошибка установки:\n$out"
                )
            } catch (e: Exception) {
                show("Ошибка установки: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                src.delete()
            }
        }.start()
    }

    // Телефон: системный установщик, пользователь подтверждает установку
    // Что лежит внутри ZIP: есть ли AndroidManifest.xml в корне и какие APK вложены
    private fun zipContents(apk: File): String {
        return try {
            java.util.zip.ZipFile(apk).use { z ->
                val names = z.entries().toList().map { it.name }
                val hasManifest = names.contains("AndroidManifest.xml")
                val apks = names.filter { it.endsWith(".apk", ignoreCase = true) }
                val sample = names.take(6).joinToString(", ")
                "Записей: ${names.size}, AndroidManifest в корне: $hasManifest, вложенных APK: ${apks.size}\nПервые: $sample"
            }
        } catch (e: Exception) {
            "ZIP не открылся: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun installWithPrompt() {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apkFile())
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        show("Подтвердите установку Яндекс Навигатора")
    }
}
