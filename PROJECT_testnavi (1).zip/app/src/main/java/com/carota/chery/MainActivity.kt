package com.carota.chery

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        const val NAVI_PKG = "ru.yandex.yandexnavi"
        const val OVERALL_URL = "https://backapi.rustore.ru/applicationData/overallInfo/$NAVI_PKG"
        const val LINK_URL = "https://backapi.rustore.ru/applicationData/download-link"
        const val APK_NAME = "yandex_navigator.apk"
        const val SYSTEM_UID = 1000
    }

    private lateinit var status: TextView
    private var downloadId = -1L
    private val ui = Handler(Looper.getMainLooper())

    // Опрос DownloadManager каждые 500 мс: процент и размер
    private val progressTick = object : Runnable {
        override fun run() {
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val cur = dm.query(DownloadManager.Query().setFilterById(downloadId))
            var running = false
            if (cur.moveToFirst()) {
                val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                if (st == DownloadManager.STATUS_PENDING ||
                    st == DownloadManager.STATUS_RUNNING ||
                    st == DownloadManager.STATUS_PAUSED) {
                    running = true
                    val done = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    show(progressText(done, total))
                }
            }
            cur.close()
            if (running) ui.postDelayed(this, 500)
        }
    }

    private fun progressText(done: Long, total: Long): String {
        val doneMb = String.format("%.1f", done / 1048576.0)
        return if (total > 0) {
            val pct = done * 100 / total
            val totalMb = String.format("%.1f", total / 1048576.0)
            "Загрузка: $pct% ($doneMb из $totalMb МБ)"
        } else {
            "Загрузка: $doneMb МБ"
        }
    }

    private val downloadDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != downloadId) return
            ui.removeCallbacks(progressTick)
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val cur = dm.query(DownloadManager.Query().setFilterById(downloadId))
            var st = -1
            var reason = -1
            if (cur.moveToFirst()) {
                st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                reason = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            }
            cur.close()
            if (st == DownloadManager.STATUS_SUCCESSFUL) install() else {
                apkFile().delete()
                show("Ошибка загрузки: статус $st, причина $reason")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = "Готово"
        }
        val wifiBtn = Button(this).apply {
            text = "Включить Wi-Fi"
            setOnClickListener { enableWifi() }
        }
        val settingsBtn = Button(this).apply {
            text = "Открыть настройки Wi-Fi"
            setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        }
        val installBtn = Button(this).apply {
            text = "Скачать и установить Яндекс Навигатор"
            setOnClickListener { installNavigator() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(wifiBtn)
            addView(settingsBtn)
            addView(installBtn)
            addView(status)
        })

        registerReceiver(downloadDone, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
    }

    override fun onDestroy() {
        unregisterReceiver(downloadDone)
        super.onDestroy()
    }

    private fun show(text: String) = runOnUiThread { status.text = text }

    private fun enableWifi() {
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        wifi.isWifiEnabled = true
        show("Wi-Fi включён")
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo?.isConnected == true
    }

    private fun apkFile(): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        APK_NAME
    )

    private fun httpJson(url: String, method: String, body: JSONObject? = null): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 15000
            // RuStore с июля 2026 требует заголовок версии клиента (число >= 247)
            c.setRequestProperty("ruStoreVerCode", "2000000000")
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw IOException("HTTP $code")
            return JSONObject(c.inputStream.bufferedReader().readText())
        } finally {
            c.disconnect()
        }
    }

    // Шаг 1: GET -> body.appId; Шаг 2: POST -> body.apkUrl; Шаг 3: DownloadManager
    private fun installNavigator() {
        if (!isOnline()) {
            show("Нет подключения к сети. Включите Wi-Fi.")
            return
        }
        show("Получаю ссылку из RuStore...")
        Thread {
            try {
                val appId = httpJson(OVERALL_URL, "GET")
                    .getJSONObject("body").getLong("appId")
                val apkUrl = httpJson(
                    LINK_URL, "POST",
                    JSONObject().put("appId", appId).put("firstInstall", true)
                ).getJSONObject("body").getString("apkUrl")
                runOnUiThread { download(apkUrl) }
            } catch (e: Exception) {
                show("Ошибка RuStore: ${e.message}")
            }
        }.start()
    }

    private fun download(url: String) {
        apkFile().delete()
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle("Яндекс Навигатор")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, APK_NAME)
        downloadId = dm.enqueue(req)
        show("Загрузка: 0%")
        ui.post(progressTick)
    }

    private fun install() {
        if (Process.myUid() == SYSTEM_UID) installSilently() else installWithPrompt()
    }

    // ГУ (системный uid): установка через pm, затем удаление файла
    private fun installSilently() {
        show("Установка...")
        Thread {
            val apk = apkFile()
            try {
                val p = Runtime.getRuntime().exec(arrayOf("pm", "install", "-r", apk.absolutePath))
                val out = p.inputStream.bufferedReader().readText() +
                    p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                show(
                    if (code == 0 && out.contains("Success")) "Яндекс Навигатор установлен"
                    else "Ошибка установки:\n$out"
                )
            } finally {
                apk.delete()
            }
        }.start()
    }

    // Телефон: системный установщик, пользователь подтверждает установку
    private fun installWithPrompt() {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apkFile())
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        show("Подтвердите установку Яндекс Навигатора")
    }
}
