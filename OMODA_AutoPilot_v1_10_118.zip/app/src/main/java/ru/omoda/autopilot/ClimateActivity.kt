package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.util.concurrent.Executors

/** Ручное управление климатом: кнопки шлют значение сразу. Текущие значения обновляются раз в две секунды. */
class ClimateActivity : Activity() {
    private val apk = "/system/priv-app/CarService/CarService.apk"
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var link: Link? = null
    private val rows = HashMap<String, TextView>()
    private var dirLabel: TextView? = null
    private val dirNames = mapOf(0 to "выкл", 1 to "верх", 2 to "низ", 3 to "верх+низ", 4 to "стекло", 6 to "низ+стекло", 7 to "все", 8 to "верх+стекло")
    private val vals = HashMap<String, Any>()

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private class Ctl(
        val key: String,
        val title: String,
        val id: Int,
        val area: Int,
        val step: Double,
        val min: Double,
        val max: Double,
        val isFloat: Boolean,
        val fallback: Double
    )

    private val ctls = listOf(
        Ctl("left", "Температура слева", 33554551, 0, 0.5, 16.0, 28.0, true, 22.0),
        Ctl("right", "Температура справа", 33554552, 0, 0.5, 16.0, 28.0, true, 22.0),
        Ctl("fan", "Скорость обдува", 33554448, 80, 1.0, 0.0, 7.0, false, 4.0),
        Ctl("seat", "Подогрев сиденья слева", 33554453, 16, 1.0, 0.0, 3.0, false, 0.0)
    )

    private val poll = object : Runnable {
        override fun run() {
            worker.execute {
                try {
                    val l = link ?: connect().also { link = it }
                    for (c in ctls) {
                        val got = l.getProp.invoke(l.prop, c.id, c.area)
                        val ok = got != null && (l.getStatus.invoke(got) as Int) == 0
                        val nv = if (ok) l.getValue.invoke(got) else null
                        runOnUiThread {
                            if (nv != null) vals[c.key] = nv
                            render(c)
                        }
                    }
                    val gotDir = l.getProp.invoke(l.prop, 33554449, 80)
                    val okDir = gotDir != null && (l.getStatus.invoke(gotDir) as Int) == 0
                    val dv = if (okDir) (l.getValue.invoke(gotDir) as Number).toInt() else null
                    runOnUiThread {
                        dirLabel?.text = "Направление: " + (dv?.let { dirNames[it] ?: it.toString() } ?: "—")
                    }
                } catch (e: Throwable) {
                    link = null
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Климат"; textSize = 22f })
        for (c in ctls) {
            val label = TextView(this).apply { textSize = 18f; text = "${c.title}: —" }
            rows[c.key] = label
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(Button(this).apply {
                text = "−"
                textSize = 22f
                setOnClickListener { change(c, -1) }
            })
            line.addView(label)
            line.addView(Button(this).apply {
                text = "+"
                textSize = 22f
                setOnClickListener { change(c, 1) }
            })
            root.addView(line)
        }
        root.addView(TextView(this).apply { textSize = 18f; text = "Направление: —" }.also { dirLabel = it })
        val dirLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("верх" to 1, "низ" to 2, "верх+низ" to 3, "стекло" to 4).forEach { (name, value) ->
            dirLine.addView(Button(this).apply {
                text = name
                textSize = 16f
                setOnClickListener { setDirection(value) }
            })
        }
        root.addView(dirLine)
        root.addView(Button(this).apply {
            text = "Авто обдув"
            textSize = 16f
            setOnClickListener { setFixed(33554463, 80, 1) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun render(c: Ctl) {
        val v = vals[c.key]
        val text = when {
            v == null -> "—"
            c.isFloat -> String.format(java.util.Locale.US, "%.1f °C", (v as Number).toDouble())
            else -> v.toString()
        }
        rows[c.key]?.text = "${c.title}: $text"
    }

    /** Одно нажатие — один шаг. Без проверок и перечитывания: шлём сразу. */
    private fun change(c: Ctl, sign: Int) {
        val base = (vals[c.key] as? Number)?.toDouble() ?: c.fallback
        val nxt = (base + sign * c.step).coerceIn(c.min, c.max)
        val v: Any = if (c.isFloat) nxt.toFloat() else nxt.toInt()
        vals[c.key] = v
        render(c)
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(c.id, c.area, v))
            } catch (e: Throwable) {
                link = null
            }
        }
    }

    /** Направление обдува: ID_BLW_DIRECT, зона передний ряд (80). */
    private fun setDirection(value: Int) {
        dirLabel?.text = "Направление: " + (dirNames[value] ?: value.toString())
        setFixed(33554449, 80, value)
    }

    /** Фиксированное значение без шага: один вызов записи. */
    private fun setFixed(id: Int, area: Int, value: Int) {
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, value))
            } catch (e: Throwable) {
                link = null
            }
        }
    }

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
