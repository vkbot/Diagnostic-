package ru.adbinstaller.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.adbinstaller.app.adb.AdbUsbClient
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

private data class CarEntry(val name: String, val isDir: Boolean, val isLink: Boolean, val size: Long)

// Строка вывода ls -la (toybox): режим, число ссылок, владелец, группа, размер, дата, время, имя
private val LS_LINE = Regex("""^([bcdlps-][rwxsStT-]{9})\s+\d+\s+\S+\s+\S+\s+(\d+)\s+\S+\s+\S+\s+(.+)$""")

private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

class MainActivity : AppCompatActivity() {
    companion object {
        private const val ACTION_USB_PERMISSION = "ru.adbinstaller.app.USB_PERMISSION"
        private const val REMOTE_APK = "/data/local/tmp/adb_install.apk"
        private const val DOWNLOADS_DIR = "/sdcard/Download"
        private const val CAR_START_DIR = "/sdcard"
    }

    private enum class PendingAction { UPLOAD, INSTALL }

    private lateinit var usbManager: UsbManager
    private lateinit var stateView: TextView
    private lateinit var outputView: TextView
    private lateinit var connectButton: Button
    private lateinit var uploadButton: Button
    private lateinit var installButton: Button
    private lateinit var browseButton: Button
    private lateinit var upButton: Button
    private lateinit var copyButton: Button
    private lateinit var browserBox: LinearLayout
    private lateinit var fileList: ListView
    private lateinit var adapter: ArrayAdapter<String>

    private var selectedDevice: UsbDevice? = null
    private var activeClient: AdbUsbClient? = null
    private var workJob: Job? = null
    private var busy = false
    private var pendingAction = PendingAction.INSTALL
    private var currentDir = CAR_START_DIR
    private var carEntries: List<CarEntry> = emptyList()

    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        when (pendingAction) {
            PendingAction.UPLOAD -> uploadApk(uri)
            PendingAction.INSTALL -> installApk(uri)
        }
    }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_USB_PERMISSION) return
            val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (device == null || device.deviceId != selectedDevice?.deviceId) return
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                connectTo(device)
            } else {
                setState("Ошибка: разрешение USB не предоставлено")
                refreshButtons()
            }
        }
    }

    private val detachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != UsbManager.ACTION_USB_DEVICE_DETACHED) return
            val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (device != null && device.deviceId == selectedDevice?.deviceId) {
                workJob?.cancel()
                activeClient?.close()
                activeClient = null
                busy = false
                hideBrowser()
                setState("Кабель отключён")
                refreshButtons()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()
        ContextCompat.registerReceiver(this, permissionReceiver, IntentFilter(ACTION_USB_PERMISSION), ContextCompat.RECEIVER_NOT_EXPORTED)
        ContextCompat.registerReceiver(this, detachReceiver, IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED), ContextCompat.RECEIVER_NOT_EXPORTED)
        setState("Готово. Подключите целевой смартфон через USB OTG.")
        refreshButtons()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "ADB Установщик"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Установка APK и файлы ГУ через ADB (USB OTG)"
            textSize = 15f
            setTextColor(0xFF5D6678.toInt())
            setPadding(0, dp(4), 0, dp(20))
        }
        connectButton = Button(this).apply {
            text = "1. Подключиться к ГУ"
            setOnClickListener { showDevices() }
        }
        uploadButton = Button(this).apply {
            text = "2. Загрузить APK в Загрузки ГУ"
            setOnClickListener {
                pendingAction = PendingAction.UPLOAD
                pickApk.launch(arrayOf("*/*"))
            }
        }
        installButton = Button(this).apply {
            text = "3. Установить APK"
            setOnClickListener {
                pendingAction = PendingAction.INSTALL
                pickApk.launch(arrayOf("*/*"))
            }
        }
        browseButton = Button(this).apply {
            text = "4. Файлы ГУ"
            setOnClickListener { openCarDir(currentDir) }
        }
        copyButton = Button(this).apply {
            text = "Копировать вывод"
            setOnClickListener { copyOutput() }
        }

        adapter = ArrayAdapter(this, R.layout.item_car_entry, mutableListOf<String>())
        fileList = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setBackgroundColor(0xFFFFFFFF.toInt())
            setOnItemClickListener { _, _, position, _ -> onEntryClick(carEntries[position]) }
            // внешний ScrollView не должен перехватывать жесты прокрутки списка
            setOnTouchListener { v, _ ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        upButton = Button(this).apply {
            text = "⬆ Вверх"
            setOnClickListener { openCarDir(parentDir(currentDir)) }
        }
        browserBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(upButton, matchWrap())
            addView(fileList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)))
        }

        stateView = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(0, dp(14), 0, dp(14))
        }
        outputView = TextView(this).apply {
            text = "Вывод появится здесь."
            setTextIsSelectable(true)
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 13f
            setTextColor(0xFF202939.toInt())
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(connectButton, matchWrap())
        root.addView(uploadButton, matchWrap())
        root.addView(installButton, matchWrap())
        root.addView(browseButton, matchWrap())
        root.addView(browserBox, matchWrap())
        root.addView(copyButton, matchWrap())
        root.addView(stateView)
        root.addView(outputView, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** Общая обёртка: один фоновый процесс за раз, ошибки выводятся в поле вывода. */
    private fun runBusy(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        refreshButtons()
        workJob = lifecycleScope.launch {
            try {
                block()
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                setState("Ошибка: $msg")
                appendOutput("ОШИБКА: $msg")
            } finally {
                busy = false
                refreshButtons()
            }
        }
    }

    private fun showDevices() {
        val devices = usbManager.deviceList.values.filter { findAdbInterface(it) }
        if (devices.isEmpty()) {
            setState("Устройство ADB не найдено. Проверьте OTG-кабель, USB-отладку и режим USB на целевом телефоне.")
            return
        }
        val labels = devices.map { deviceLabel(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Выберите устройство")
            .setItems(labels) { _, index ->
                val device = devices[index]
                selectedDevice = device
                if (usbManager.hasPermission(device)) connectTo(device) else requestUsbPermission(device)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun requestUsbPermission(device: UsbDevice) {
        setState("Ожидание разрешения USB…")
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        val permissionIntent = PendingIntent.getBroadcast(this, device.deviceId, intent, flags)
        usbManager.requestPermission(device, permissionIntent)
    }

    private fun connectTo(device: UsbDevice) {
        activeClient?.close()
        activeClient = null
        hideBrowser()
        setState("Подключение к ${deviceLabel(device)}. Если появится RSA-диалог, подтвердите его на телефоне.")
        runBusy {
            val client = withContext(Dispatchers.IO) {
                AdbUsbClient(usbManager, device, filesDir).also { c ->
                    try {
                        c.connect()
                    } catch (e: Exception) {
                        c.close()
                        throw e
                    }
                }
            }
            activeClient = client
            setState("ADB подключён: ${deviceLabel(device)}. Выберите действие.")
        }
    }

    private fun uploadApk(uri: Uri) = runBusy {
        val client = activeClient ?: error("Сначала подключитесь к устройству")
        outputView.text = ""
        withContext(Dispatchers.IO) {
            val remote = "$DOWNLOADS_DIR/${displayName(uri)}"
            appendOutput("Загрузка в $remote ...")
            val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть выбранный файл")
            val bytes = input.use { client.push(it, remote) }
            appendOutput("Готово: $remote ($bytes байт)")
        }
        setState("Файл загружен в Загрузки ГУ.")
    }

    private fun installApk(uri: Uri) = runBusy {
        val client = activeClient ?: error("Сначала подключитесь к устройству")
        outputView.text = ""
        withContext(Dispatchers.IO) {
            appendOutput("Загрузка APK в $REMOTE_APK ...")
            val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть выбранный файл")
            val bytes = input.use { client.push(it, REMOTE_APK) }
            appendOutput("Загружено $bytes байт. Выполняю: pm install -r -d $REMOTE_APK")
            try {
                val result = client.shell("pm install -r -d $REMOTE_APK")
                val exit = result.exitCode?.toString() ?: "не получен"
                val completed = if (result.completed) "" else " (команда не завершилась)"
                appendOutput("Код завершения: $exit$completed")
                appendOutput(result.output.trim().ifEmpty { "(вывода нет)" })
            } finally {
                try { client.shell("rm -f $REMOTE_APK") } catch (_: Exception) { }
            }
        }
        setState("Установка завершена. Результат ниже.")
    }

    /** Открывает каталог на ГУ и показывает его содержимое. */
    private fun openCarDir(path: String) = runBusy {
        val client = activeClient ?: error("Сначала подключитесь к устройству")
        val entries = withContext(Dispatchers.IO) { listRemote(client, path) }
        currentDir = path
        showEntries(entries)
        setState("ГУ: $path")
    }

    /** Нажатие на папку — войти, на файл — скачать на телефон. */
    private fun onEntryClick(entry: CarEntry) = runBusy {
        val client = activeClient ?: error("Сначала подключитесь к устройству")
        val path = joinPath(currentDir, entry.name)
        val isDir = entry.isDir ||
            (entry.isLink && withContext(Dispatchers.IO) { isRemoteDir(client, path) })
        if (isDir) {
            val entries = withContext(Dispatchers.IO) { listRemote(client, path) }
            currentDir = path
            showEntries(entries)
            setState("ГУ: $path")
        } else {
            val saved = withContext(Dispatchers.IO) { saveFromCar(client, path, entry.name) }
            appendOutput("Сохранено на телефон: $saved")
            setState("Файл скачан: ${entry.name}")
        }
    }

    /** Выполняется в IO-потоке. */
    private fun listRemote(client: AdbUsbClient, path: String): List<CarEntry> {
        val res = client.shell("ls -la ${shq(path)}")
        val entries = res.output.lines().mapNotNull { raw ->
            val m = LS_LINE.find(raw.trim()) ?: return@mapNotNull null
            val mode = m.groupValues[1]
            val name = m.groupValues[3].substringBefore(" -> ")
            if (name == "." || name == "..") return@mapNotNull null
            CarEntry(name, mode[0] == 'd', mode[0] == 'l', m.groupValues[2].toLongOrNull() ?: 0L)
        }
        if (entries.isEmpty() && res.output.contains("ls:")) error(res.output.trim())
        return entries.sortedWith(compareBy<CarEntry>({ !it.isDir }, { it.name.lowercase() }))
    }

    private fun isRemoteDir(client: AdbUsbClient, path: String): Boolean =
        client.shell("test -d ${shq(path)} && echo DIR").output.contains("DIR")

    /** Выполняется в IO-потоке: скачивает файл с ГУ в «Загрузки» телефона. */
    private fun saveFromCar(client: AdbUsbClient, remote: String, name: String): String {
        val safeName = name.replace("/", "_")
        appendOutput("Скачивание $remote ...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Не удалось создать файл в «Загрузках»")
            try {
                val out = contentResolver.openOutputStream(uri) ?: error("Нет доступа к файлу в «Загрузках»")
                val bytes = out.use { client.pull(remote, it) }
                appendOutput("Получено $bytes байт")
                val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
            return "«Загрузки»/$safeName"
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val file = File(dir, safeName)
            try {
                val bytes = FileOutputStream(file).use { client.pull(remote, it) }
                appendOutput("Получено $bytes байт")
            } catch (e: Exception) {
                file.delete()
                throw e
            }
            return file.absolutePath
        }
    }

    private fun showEntries(entries: List<CarEntry>) {
        carEntries = entries
        adapter.clear()
        adapter.addAll(entries.map { e ->
            if (e.isDir) "▸ ${e.name}/" else "${e.name}  (${formatSize(e.size)})"
        })
        browserBox.visibility = View.VISIBLE
        refreshButtons()
    }

    private fun hideBrowser() {
        carEntries = emptyList()
        adapter.clear()
        browserBox.visibility = View.GONE
    }

    private fun joinPath(dir: String, name: String) = if (dir.endsWith("/")) dir + name else "$dir/$name"

    private fun parentDir(path: String): String {
        val trimmed = path.trimEnd('/')
        if (trimmed.isEmpty()) return "/"
        return trimmed.substringBeforeLast('/', "").ifEmpty { "/" }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format(Locale.US, "%.1f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", bytes / (1L shl 20).toDouble())
        bytes >= 1L shl 10 -> String.format(Locale.US, "%.1f KB", bytes / (1L shl 10).toDouble())
        else -> "$bytes B"
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val name = c.getString(0)
                if (!name.isNullOrBlank()) return name.replace("/", "_")
            }
        }
        return "app_${System.currentTimeMillis()}.apk"
    }

    private fun appendOutput(line: String) {
        runOnUiThread { outputView.append(line + "\n") }
    }

    private fun copyOutput() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ADB Установщик", outputView.text))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }

    private fun setState(value: String) {
        stateView.text = "Состояние: $value"
    }

    private fun refreshButtons() {
        val connected = activeClient != null
        connectButton.isEnabled = !busy && !connected
        uploadButton.isEnabled = !busy && connected
        installButton.isEnabled = !busy && connected
        browseButton.isEnabled = !busy && connected
        upButton.isEnabled = !busy && connected && currentDir != "/"
    }

    private fun findAdbInterface(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass != 0xFF || intf.interfaceSubclass != 0x42 || intf.interfaceProtocol != 0x01) continue
            var inBulk = false
            var outBulk = false
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inBulk = true
                if (ep.direction == UsbConstants.USB_DIR_OUT) outBulk = true
            }
            if (inBulk && outBulk) return true
        }
        return false
    }

    private fun deviceLabel(device: UsbDevice): String {
        val product = try { device.productName?.takeIf { it.isNotBlank() } } catch (_: SecurityException) { null }
        val manufacturer = try { device.manufacturerName?.takeIf { it.isNotBlank() } } catch (_: SecurityException) { null }
        val name = listOfNotNull(manufacturer, product).joinToString(" ").ifBlank { "Android / USB device" }
        return String.format(Locale.getDefault(), "%s (VID %04X, PID %04X)", name, device.vendorId, device.productId)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        workJob?.cancel()
        activeClient?.close()
        activeClient = null
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) { }
        try { unregisterReceiver(detachReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }
}
