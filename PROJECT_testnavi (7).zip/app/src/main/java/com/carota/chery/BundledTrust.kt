package com.carota.chery

import android.content.Context
import java.security.KeyStore
import java.security.cert.CertificateFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory

// Доверяем только сертификатам, которые лежат в приложении (res/raw)
object BundledTrust {
    fun socketFactory(ctx: Context, rawResId: Int): SSLSocketFactory {
        val certs = ctx.resources.openRawResource(rawResId).use {
            CertificateFactory.getInstance("X.509").generateCertificates(it)
        }
        val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply { load(null, null) }
        certs.forEachIndexed { i, cert -> ks.setCertificateEntry("bundled-$i", cert) }
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        tmf.init(ks)
        val sc = SSLContext.getInstance("TLS")
        sc.init(null, tmf.trustManagers, null)
        return sc.socketFactory
    }
}
