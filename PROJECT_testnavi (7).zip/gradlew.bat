@echo off
rem Запускает установленный Gradle (версия из gradle/wrapper/gradle-wrapper.properties)
gradle %*
