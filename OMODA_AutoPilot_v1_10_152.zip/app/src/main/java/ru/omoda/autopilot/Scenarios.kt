package ru.omoda.autopilot

import android.content.Context

/** Настройки сценариев климата. Хранятся в SharedPreferences. */
object Scenarios {
    private const val PREF = "scenarios"

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    /** Порог 1: ниже этой температуры — подогревы сидений и HI. */
    fun t1(c: Context): Int = p(c).getInt("t1", 10)
    /** Порог 2: ниже этой температуры — ещё лобовое и заднее стекло. */
    fun t2(c: Context): Int = p(c).getInt("t2", 2)
    fun seatLevel(c: Context): Int = p(c).getInt("seat", 4)

    /** Лобовое стекло по умолчанию выключено: запись 33554486 ещё не подтверждена на машине. */
    fun flag(c: Context, key: String): Boolean = p(c).getBoolean(key, key != "front")
    fun setFlag(c: Context, key: String, v: Boolean) = p(c).edit().putBoolean(key, v).apply()
    fun setInt(c: Context, key: String, v: Int) = p(c).edit().putInt(key, v).apply()

    fun last(c: Context): String = p(c).getString("last", "") ?: ""
    fun setLast(c: Context, v: String) = p(c).edit().putString("last", v).apply()
}
