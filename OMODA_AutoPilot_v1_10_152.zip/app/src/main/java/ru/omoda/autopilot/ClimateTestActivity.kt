package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.concurrent.Executors

/** Тестовый климат: непроверенные ID, монитор изменений и поиск ID. Ничего отсюда не переносится в обычный экран без проверки. */
class ClimateTestActivity : Activity() {
    private val apk = "/system/priv-app/CarService/CarService.apk"
    private val loader by lazy { dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader()) }
    private val worker = Executors.newCachedThreadPool()
    private var link: Link? = null
    private var scanView: TextView? = null
    @Volatile private var monitoring = false
    private val monLog = ArrayDeque<String>()

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private class Fixed(val label: String, val id: Int, val area: Int, val value: Any)

    private val tests = listOf(
        Fixed("Авто обдув 1 (463)", 33554463, 80, 1),
        Fixed("SYNC зона 16 =1 (436)", 33554436, 16, 1),
        Fixed("SYNC зона 16 =0", 33554436, 16, 0),
        Fixed("SYNC зона 64 =1", 33554436, 64, 1),
        Fixed("SYNC зона 64 =0", 33554436, 64, 0),
        Fixed("A/C зона 16 =1 (438)", 33554438, 16, 1),
        Fixed("A/C зона 16 =0", 33554438, 16, 0),
        Fixed("A/C зона 64 =1", 33554438, 64, 1),
        Fixed("A/C зона 64 =0", 33554438, 64, 0),
        Fixed("A/C режим 1 (438)", 33554438, 0, 1),
        Fixed("A/C режим 0", 33554438, 0, 0),
        Fixed("MAX A/C 1 (439)", 33554439, 0, 1),
        Fixed("MAX A/C 0", 33554439, 0, 0),
        Fixed("A/C запрос 1 (498)", 33554498, 0, 1),
        Fixed("A/C запрос 0", 33554498, 0, 0),
        Fixed("A/C зона 1 (549)", 33554549, 0, 1),
        Fixed("A/C зона 0", 33554549, 0, 0),
        Fixed("SWT? 500 =1", 33554500, 0, 1),
        Fixed("SWT? 500 =0", 33554500, 0, 0),
        Fixed("SWT_AUTO? 503 =1", 33554503, 0, 1),
        Fixed("SWT_AUTO? 503 =0", 33554503, 0, 0),
        Fixed("зерк лев 1 (578)", 33554578, 0, 1),
        Fixed("зерк лев 0", 33554578, 0, 0),
        Fixed("зерк прав 1 (579)", 33554579, 0, 1),
        Fixed("зерк прав 0", 33554579, 0, 0),
        Fixed("вент пасс 2 (574/64)", 33554574, 64, 2),
        Fixed("вент пасс ВЫКЛ (574=1)", 33554574, 64, 1),
        Fixed("подогрев вод ВЫКЛ (453=1)", 33554453, 16, 1)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Тестовый климат"; textSize = 22f })
        scanView = TextView(this).apply { textSize = 15f; text = "" }
        root.addView(scanView)

        root.addView(button("МОНИТОР (жмите кнопку на штатной панели)") { toggleMonitor() })
        root.addView(button("Поиск ID руля и ОЖ") { scan() })
        root.addView(button("Вернуть исходное (все тесты)") { restoreAll() })
        root.addView(button("A/C ВЫКЛ все зоны (438=0)") { offAllZones(33554438) })
        root.addView(button("SYNC ВЫКЛ все зоны (436=0)") { offAllZones(33554436) })
        root.addView(button("Температуры: снимок ХОЛОДНЫЙ") { snapshot(1) })
        root.addView(button("Температуры: снимок ТЁПЛЫЙ") { snapshot(2) })
        root.addView(button("Температуры: сравнить") { compareSnaps() })
        root.addView(button("Температуры: все сейчас") { showAllTemps() })

        tests.chunked(3).forEach { chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in chunk) line.addView(button(t.label) { write(t.id, t.area, t.value) })
            root.addView(line)
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onDestroy() {
        monitoring = false
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            setOnClickListener { onClick() }
        }

    private fun setScan(msg: String) {
        runOnUiThread { scanView?.text = msg }
    }

    /**
     * Запись без автовозврата: читаем исходное значение и статус, запоминаем исходное, пишем новое,
     * читаем обратно. Вернуть можно кнопкой «Вернуть исходное». Прочитанное значение — не доказательство реакции машины.
     */
    private fun write(id: Int, area: Int, v: Any) {
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                val before = l.getProp.invoke(l.prop, id, area)
                if (before == null || (l.getStatus.invoke(before) as Int) != 0) {
                    setScan("Запись отменена: свойство недоступно (id=$id, зона=$area)")
                    return@execute
                }
                val old = l.getValue.invoke(before)
                if (old != null) {
                    synchronized(savedOld) { savedOld.putIfAbsent("$id/$area", Triple(id, area, old)) }
                }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, v))
                Thread.sleep(1500)
                val seen = l.getProp.invoke(l.prop, id, area)?.let { l.getValue.invoke(it) }
                setScan("записано $v (id=$id, зона=$area), прочитано обратно: $seen, исходное: $old")
            } catch (e: Throwable) {
                link = null
                setScan("ошибка записи: ${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}: ${e.cause?.message ?: e.message}")
            }
        }
    }

    /** Выключение во всех зонах, где штатная кнопка меняет значение (по монитору: 1024, 256, 64, 16, 0). */
    private fun offAllZones(id: Int) {
        for (a in intArrayOf(0, 16, 64, 256, 1024)) write(id, a, 0)
    }

    /** Возвращает исходные значения всех тестовых записей, которые были сделаны в этом сеансе. */
    private fun restoreAll() {
        worker.execute {
            val items = synchronized(savedOld) { savedOld.values.toList().also { savedOld.clear() } }
            if (items.isEmpty()) {
                setScan("Нечего возвращать")
                return@execute
            }
            val l = try {
                link ?: connect().also { link = it }
            } catch (e: Throwable) {
                setScan("нет связи с машиной: $e")
                return@execute
            }
            val report = StringBuilder()
            for ((id, area, old) in items) {
                try {
                    l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, old))
                    report.append("id=$id зона=$area -> $old: ок\n")
                } catch (e: Throwable) {
                    link = null
                    report.append("id=$id зона=$area: ОШИБКА, верните вручную (было $old)\n")
                }
            }
            setScan(report.toString())
        }
    }

    /** Показывает, какие ID климата меняются при нажатии на штатной панели. */
    private fun toggleMonitor() {
        if (monitoring) {
            monitoring = false
            setScan("Монитор остановлен")
            return
        }
        monitoring = true
        synchronized(monLog) { monLog.clear() }
        setScan("Монитор запущен: нажмите кнопку на штатной панели и ждите строку")
        worker.execute {
            val names = try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val classNames = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.config.") }
                df.close()
                classNames.filter { !it.contains("fuel", true) && !it.contains("network", true) }.flatMap { cn ->
                    try {
                        Class.forName(cn, false, cl).declaredFields
                            .filter {
                                Modifier.isStatic(it.modifiers) && it.type == Int::class.javaPrimitiveType &&
                                    it.name.startsWith("ID_") && !it.name.contains("FUEL", true) && !it.name.contains("NETWORK", true)
                            }
                            .map { f -> f.isAccessible = true; "${cn.removePrefix("mega.car.config.")}.${f.name}" to (f.get(null) as Int) }
                    } catch (e: Throwable) {
                        emptyList()
                    }
                }
            } catch (e: Throwable) {
                monitoring = false
                setScan("ошибка списка ID: $e")
                return@execute
            }
            val l = try {
                link ?: connect().also { link = it }
            } catch (e: Throwable) {
                monitoring = false
                setScan("нет связи с машиной: $e")
                return@execute
            }
            val areas = intArrayOf(0, 16, 64, 80, 256, 1024)
            val last = HashMap<String, String>()
            while (monitoring) {
                for ((name, id) in names) {
                    for (a in areas) {
                        val cur = try {
                            val got = l.getProp.invoke(l.prop, id, a)
                            if (got == null) "null" else {
                                val st = l.getStatus.invoke(got) as Int
                                if (st != 0) "статус$st" else l.getValue.invoke(got).toString()
                            }
                        } catch (e: Throwable) {
                            "ошибка"
                        }
                        val prev = last["$id/$a"]
                        if (prev != null && prev != cur && cur != "ошибка") {
                            val text = synchronized(monLog) {
                                monLog.addFirst("$name зона=0x${Integer.toHexString(a)}: $prev → $cur")
                                while (monLog.size > 40) monLog.removeLast()
                                monLog.joinToString("\n")
                            }
                            setScan("МОНИТОР (жмите кнопку на штатной панели):\n$text")
                        }
                        last["$id/$a"] = cur
                    }
                }
            }
        }
    }

    /** Исходные значения до тестовых записей: для кнопки «вернуть исходное». Автовозврата нет. */
    private val savedOld = LinkedHashMap<String, Triple<Int, Int, Any>>()
    private var snap1: Map<String, Double>? = null
    private var snap2: Map<String, Double>? = null

    /** Все ID с TEMP в названии из классов mega.car.*, у которых есть численное значение. */
    private fun collectTemps(): Map<String, Double> {
        @Suppress("DEPRECATION")
        val df = dalvik.system.DexFile(apk)
        val classes = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.") }
        df.close()
        val out = LinkedHashMap<String, Double>()
        val areas = intArrayOf(0, 16, 64, 80, 256, 1024)
        for (cn in classes) {
            val fields = try { Class.forName(cn, false, loader).declaredFields } catch (e: Throwable) { continue }
            for (f in fields) {
                if (!Modifier.isStatic(f.modifiers) || f.type != Int::class.javaPrimitiveType) continue
                if (!f.name.startsWith("ID_") || !f.name.contains("TEMP")) continue
                f.isAccessible = true
                val id = f.get(null) as Int
                for (a in areas) {
                    val v = CarProps.get(id, a) as? Number ?: continue
                    out["${cn.removePrefix("mega.car.")}.${f.name}@0x${Integer.toHexString(a)}"] = v.toDouble()
                }
            }
        }
        return out
    }

    private fun snapshot(n: Int) {
        setScan("Снимаю температуры...")
        worker.execute {
            val m = collectTemps()
            if (n == 1) snap1 = m else snap2 = m
            setScan("Снимок $n: ${m.size} значений. " + if (n == 1) "Прогрейте двигатель и сделайте снимок ТЁПЛЫЙ" else "Теперь нажмите «сравнить»")
        }
    }

    private fun compareSnaps() {
        val a = snap1
        val b = snap2
        if (a == null || b == null) {
            setScan("Нужны оба снимка: ХОЛОДНЫЙ и ТЁПЛЫЙ")
            return
        }
        val diffs = a.keys.intersect(b.keys).mapNotNull { k ->
            val d = b[k]!! - a[k]!!
            if (kotlin.math.abs(d) < 0.01) null else Pair(k, d)
        }.sortedByDescending { kotlin.math.abs(it.second) }.take(60)
        setScan(
            if (diffs.isEmpty()) "Изменений нет"
            else "Изменилось (по величине):\n" + diffs.joinToString("\n") { (k, d) ->
                "$k: ${"%.1f".format(a[k])} → ${"%.1f".format(b[k])} (Δ ${"%+.1f".format(d)})"
            }
        )
    }

    private fun showAllTemps() {
        setScan("Считаю...")
        worker.execute {
            val m = collectTemps()
            setScan(if (m.isEmpty()) "Ни одного значения" else m.entries.joinToString("\n") { "${it.key} = ${"%.1f".format(it.value)}" }.take(8000))
        }
    }

    /** Ищет в SDK поля с ключевыми словами руля и охлаждающей жидкости, плюс все enum-ы Climate. */
    private fun scan() {
        setScan("Поиск...")
        worker.execute {
            val found = StringBuilder()
            try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val names = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.") }
                df.close()
                val key = Regex("STEER|STRW|STRG|WHEEL|HANDLE|SWT|HEAT|COOLANT|ENG_TEMP|ENGINE_TEMP|WATER|ECT")
                for (n in names) {
                    val c = try { Class.forName(n, false, cl) } catch (e: Throwable) { continue }
                    val allFields = n.startsWith("mega.car.config.Climate\$")
                    for (f in c.declaredFields) {
                        if (!Modifier.isStatic(f.modifiers) || !(allFields || key.containsMatchIn(f.name))) continue
                        val v = try { f.isAccessible = true; f.get(null).toString() } catch (e: Throwable) { "?" }
                        found.append(n).append('.').append(f.name).append(" = ").append(v).append('\n')
                    }
                }
            } catch (e: Throwable) {
                found.append("ошибка: ").append(e)
            }
            setScan(if (found.isEmpty()) "ничего не найдено" else found.take(8000).toString())
        }
    }

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = loader
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
