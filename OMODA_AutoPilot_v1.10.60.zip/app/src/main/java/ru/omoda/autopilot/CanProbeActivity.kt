package ru.omoda.autopilot

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.TimeUnit

/** Тест шины: только чтение. Ничего не пишет и не отправляет в шину. */
class CanProbeActivity : Activity() {
    private lateinit var out: TextView

    private val probes = listOf(
        "Список всех сервисов системы" to "dumpsys -l 2>&1",
        "CAN и serial-устройства в /dev" to "ls /dev 2>&1 | grep -iE 'can|ttyS|ttyUSB|ttyMT|vehicle|mcu'",
        "Сетевые интерфейсы" to "cat /proc/net/dev 2>&1",
        "Модули ядра (CAN, MCU, UART)" to "cat /proc/modules 2>&1 | grep -iE 'can|vehicle|mcu|uart'",
        "Драйверы tty" to "cat /proc/tty/drivers 2>&1",
        "Платформенные устройства" to "ls /sys/bus/platform/devices 2>&1 | grep -iE 'can|car|vehicle|mcu|uart'",
        "Вендорские бинарники" to "ls /vendor/bin /system/bin 2>&1 | grep -iE 'car|can|vehicle|vhal|mcu'",
        "Вендорские библиотеки" to "ls /vendor/lib64 /system/lib64 2>&1 | grep -iE 'vehicle|car|can|vhal'",
        "Приложения вендора" to "ls /system/priv-app /system/app /vendor/app 2>&1 | head -150",
        "Сообщения ядра (dmesg)" to "dmesg 2>&1 | grep -iE 'can|vehicle|mcu|uart' | tail -40",
        "Сервисы автомобиля" to "service list 2>&1 | grep -iE 'car|vehicle|omoda|chery|can'",
        "dumpsys car_service" to "dumpsys car_service 2>&1 | head -80",
        "Свойства автомобиля и температур" to "getprop 2>&1 | grep -iE 'car|vehicle|chery|omoda|can|temp' | head -60",
        "Логи шины (последние)" to "logcat -d 2>&1 | grep -iE 'can|vehicle|vhal' | tail -40"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Тест шины (только чтение)", 18f))

        out = TextView(this)
        out.text = "Сбор данных..."
        out.textSize = 11f
        out.typeface = Typeface.MONOSPACE
        out.setTextColor(COLOR_TEXT)
        out.setTextIsSelectable(true)
        root.addView(out, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
        collect()
    }

    private fun collect() {
        Thread {
            val sb = StringBuilder()
            sb.append("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            sb.append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            sb.append("Сборка: ${Build.FINGERPRINT}\n\n")
            for ((title, cmd) in probes) {
                sb.append("=== $title\n")
                sb.append(run(cmd).take(4000)).append("\n\n")
                val snapshot = sb.toString()
                runOnUiThread { out.text = snapshot }
            }
            sb.append("=== Классы Car API\n").append(classCheck()).append("\n")
            val snapshot = sb.toString()
            runOnUiThread { out.text = snapshot }
        }.start()
    }

    /** Выполняет одну команду оболочки, не дольше 10 секунд. */
    private fun run(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        if (!p.waitFor(10, TimeUnit.SECONDS)) p.destroy()
        p.inputStream.bufferedReader().readText().trim().ifEmpty { "(пусто)" }
    } catch (e: Exception) {
        "ошибка: ${e.javaClass.simpleName}: ${e.message}"
    }

    /** Есть ли в системе классы Car API и интерфейсы HAL автомобиля. */
    private fun classCheck(): String =
        listOf(
            "android.car.Car",
            "android.car.hardware.property.CarPropertyManager",
            "android.car.VehiclePropertyIds",
            "android.car.hardware.CarPropertyValue",
            "android.hardware.automotive.vehicle.V2_0.IVehicle"
        ).joinToString("\n") { name ->
            val ok = try { Class.forName(name); true } catch (e: Throwable) { false }
            "$name: ${if (ok) "есть" else "нет"}"
        }
}
