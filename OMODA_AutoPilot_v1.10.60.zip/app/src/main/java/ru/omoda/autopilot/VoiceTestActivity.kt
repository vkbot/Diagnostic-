package ru.omoda.autopilot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/** Голосовые команды офлайн: запись 5 секунд, распознавание Vosk, выполнение команды. */
class VoiceTestActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var text: TextView
    private lateinit var command: TextView
    private var model: Model? = null
    private val assetModel = "vosk-model-small-ru-0.22"
    private val rate = 16000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Голосовые команды", 18f))
        root.addView(labelView("Скажите: «карты», «музыка», «вай-фай включи», «вай-фай выключи»", 13f, 4))
        status = labelView("Нажмите «СЛУШАТЬ 5 СЕК» и говорите", 14f, 8)
        root.addView(status)
        text = labelView("", 22f, 8)
        root.addView(text)
        command = labelView("", 16f, 8)
        root.addView(command)
        root.addView(actionButton("СЛУШАТЬ 5 СЕК") { startCheck() })
        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
    }

    private fun startCheck() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        record()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) record()
        else status.text = "Нет доступа к микрофону"
    }

    /** Копирует модель из assets во внутреннюю память один раз. Vosk читает модель с файловой системы. */
    private fun modelPath(): String {
        val dest = File(filesDir, assetModel)
        if (!dest.isDirectory) {
            val tmp = File(filesDir, "$assetModel.tmp")
            tmp.deleteRecursively()
            copyAssets(assetModel, tmp)
            tmp.renameTo(dest)
        }
        return dest.absolutePath
    }

    private fun copyAssets(path: String, dest: File) {
        val children = assets.list(path) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
        } else {
            dest.mkdirs()
            for (child in children) copyAssets("$path/$child", File(dest, child))
        }
    }

    private fun record() {
        if ((assets.list(assetModel) ?: emptyArray()).isEmpty()) {
            status.text = "Модель не встроена в сборку"
            return
        }
        status.text = "Идёт запись, говорите..."
        text.text = ""
        command.text = ""
        Thread {
            var recognizer: Recognizer? = null
            var rec: AudioRecord? = null
            try {
                val m = model ?: Model(modelPath()).also { model = it }
                recognizer = Recognizer(m, rate.toFloat())
                val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
                val buf = ByteArray(4000)
                val until = System.currentTimeMillis() + 5000
                rec.startRecording()
                while (System.currentTimeMillis() < until) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) recognizer.acceptWaveForm(buf, n)
                }
                val result = JSONObject(recognizer.getFinalResult()).optString("text")
                runOnUiThread {
                    status.text = "Готово"
                    text.text = if (result.isEmpty()) "(ничего не распознано)" else result
                    if (result.isNotEmpty()) handle(result)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка: ${e.javaClass.simpleName}: ${e.message}" }
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                rec?.release()
                recognizer?.close()
            }
        }.start()
    }

    /** Выполняет команду по ключевым словам. Вызывается на UI-потоке. */
    private fun handle(spoken: String) {
        val t = spoken.lowercase()
        command.text = when {
            t.contains("карт") -> launch("ru.yandex.yandexmaps", "Яндекс Карты")
            t.contains("музык") -> launch("ru.yandex.music", "Яндекс Музыка")
            t.contains("вай фай") || t.contains("вайфай") || t.contains("wi-fi") || t.contains("wifi") || t.contains("вай-фай") -> wifi(t)
            else -> "Команда не распознана"
        }
    }

    private fun launch(pkg: String, name: String): String {
        val intent: Intent = packageManager.getLaunchIntentForPackage(pkg) ?: return "$name не установлено"
        startActivity(intent)
        return "Открываю: $name"
    }

    @Suppress("DEPRECATION")
    private fun wifi(t: String): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return when {
            t.contains("выключ") -> { wm.isWifiEnabled = false; "Wi-Fi выключен" }
            t.contains("включ") -> { wm.isWifiEnabled = true; "Wi-Fi включён" }
            else -> "Скажите «включи» или «выключи» Wi-Fi"
        }
    }

    override fun onDestroy() {
        model?.close()
        model = null
        super.onDestroy()
    }
}
