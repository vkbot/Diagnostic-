package ru.omoda.autopilot

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Ищет APK на флешке и внутренней памяти и ставит выбранный через системный PackageInstaller.
 * Копирование в /data/local/tmp и команды pm не используются.
 */
class InstallTestActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var result: TextView

    private val searchRoots = listOf("/storage", "/mnt/media_rw", "/sdcard")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("Установка APK с флешки", 18f))
        root.addView(actionButton("ОБНОВИТЬ СПИСОК") { scan() })
        root.addView(actionButton("РАЗРЕШИТЬ RUSTORE УСТАНОВКУ") { allowRuStore() })
        root.addView(actionButton("АВТО-УСТАНОВКА (ОТКРОЙТЕ RUSTORE)") { autoInstallFromStore() })

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        result = labelView("", 13f, 12)
        root.addView(result)

        scan()
    }

    /** Выставляет RuStore разрешение на установку приложений и сразу проверяет его. */
    private fun allowRuStore() {
        result.text = "Разрешаю установку для RuStore..."
        Thread {
            val out = runShell(
                "cmd appops set ru.vk.store REQUEST_INSTALL_PACKAGES allow; " +
                "cmd appops get ru.vk.store REQUEST_INSTALL_PACKAGES"
            )
            SettingsRepository(applicationContext).addEvent("appops RuStore: $out")
            runOnUiThread { result.text = "RuStore, REQUEST_INSTALL_PACKAGES:\n$out" }
        }.start()
    }

    /**
     * Через 15 секунд смотрит, что сейчас на экране, и нажимает кнопку установки, если она активна.
     * Работает через uiautomator dump и input tap, без клавиатуры.
     */
    private fun autoInstallFromStore() {
        toast("Откройте нужную страницу в RuStore. Через 15 секунд нажму «Установить»")
        Thread {
            Thread.sleep(15000)
            val dumpPath = File(filesDir, "ui.xml").absolutePath
            val dumpOut = runShell("uiautomator dump $dumpPath")
            val xml = try { File(dumpPath).readText() } catch (e: Exception) { "" }
            val keywords = listOf("Установить", "Скачать", "Установка", "Обновить")
            val candidates = parseNodes(xml).filter { node ->
                val text = node["text"].orEmpty()
                keywords.any { text.contains(it, ignoreCase = true) }
            }
            val msg = if (candidates.isEmpty()) {
                "кнопок установки не найдено (dump: $dumpOut, размер XML ${xml.length})"
            } else {
                val report = candidates.joinToString("; ") {
                    "«${it["text"]}» enabled=${it["enabled"]} bounds=${it["bounds"]}"
                }
                val target = candidates.firstOrNull { it["enabled"] == "true" }
                if (target == null) {
                    "кнопка неактивна: $report"
                } else {
                    val m = Regex("\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]").find(target["bounds"].orEmpty())
                    if (m == null) {
                        "не удалось разобрать координаты: $report"
                    } else {
                        val x = (m.groupValues[1].toInt() + m.groupValues[3].toInt()) / 2
                        val y = (m.groupValues[2].toInt() + m.groupValues[4].toInt()) / 2
                        runShell("input tap $x $y")
                        "нажал «${target["text"]}» в ($x,$y). $report"
                    }
                }
            }
            SettingsRepository(applicationContext).addEvent("автоустановка: $msg")
            runOnUiThread { result.text = msg }
        }.start()
    }

    /** Разбирает узлы uiautomator dump: каждый узел — набор атрибутов key="value". */
    private fun parseNodes(xml: String): List<Map<String, String>> =
        Regex("<node [^>]*>").findAll(xml).map { match ->
            Regex("([\\w-]+)=\"([^\"]*)\"").findAll(match.value)
                .associate { it.groupValues[1] to it.groupValues[2] }
        }.toList()

    private fun scan() {
        list.removeAllViews()
        list.addView(labelView("Поиск APK...", 14f))
        Thread {
            val found = mutableListOf<File>()
            for (path in searchRoots) {
                try {
                    File(path).walkTopDown().maxDepth(4)
                        .filter { it.isFile && it.name.lowercase().endsWith(".apk") }
                        .forEach { found.add(it) }
                } catch (e: Exception) {
                    // недоступная папка пропускается
                }
            }
            runOnUiThread { showFiles(found) }
        }.start()
    }

    private fun showFiles(files: List<File>) {
        list.removeAllViews()
        if (files.isEmpty()) {
            list.addView(labelView("APK не найдены в: ${searchRoots.joinToString(", ")}", 14f))
            return
        }
        for (file in files.take(100)) {
            list.addView(actionButton("${file.name}  (${file.length() / 1024} КБ)\n${file.parent}") {
                install(file)
            })
        }
    }

    private fun install(file: File) {
        result.text = "Установка: ${file.name} ..."
        Thread {
            val abi = abiReport(file)
            SettingsRepository(applicationContext).addEvent("проверка ${file.name}: $abi")
            val text = try {
                installViaPmStdin(file)
            } catch (e: Exception) {
                "ошибка: ${e.javaClass.simpleName}: ${e.message}"
            }
            SettingsRepository(applicationContext).addEvent("установка ${file.name}: $text")
            runOnUiThread { result.text = "${file.name}\n$abi\n$text" }
        }.start()
    }

    /** Сравнивает архитектуры процессора ГУ с нативными библиотеками внутри APK. */
    private fun abiReport(file: File): String {
        val device = android.os.Build.SUPPORTED_ABIS.joinToString(",")
        val apkLibs = try {
            java.util.zip.ZipFile(file).use { zip ->
                java.util.Collections.list(zip.entries())
                    .map { it.name }
                    .filter { it.startsWith("lib/") }
                    .mapNotNull { it.split('/').getOrNull(1) }
                    .distinct()
                    .joinToString(",")
            }
        } catch (e: Exception) {
            "ошибка чтения: ${e.javaClass.simpleName}"
        }
        return "ГУ abi=[$device], APK lib=[${apkLibs.ifEmpty { "нет нативных библиотек" }}]"
    }

    /**
     * Передаёт APK в pm install через stdin: pm не открывает путь к файлу сам,
     * поэтому ограничения доступа к каталогам на него не действуют.
     */
    private fun installViaPmStdin(file: File): String {
        val quoted = "'" + file.absolutePath.replace("'", "'\\''") + "'"
        val cmd = "cat $quoted | pm install -r -S ${file.length()}"
        return runShell(cmd)
    }

    private fun runShell(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.trim().ifEmpty { "(пусто)" }.take(1000)
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }
}
