package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Сбор диагностики моста к машине. Все команды пишутся в один текстовый файл в Загрузках,
 * его потом отдают для разбора. Ничего не меняет на системе: только чтение.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Диагностика моста"; textSize = 18f })
        root.addView(Button(this).apply {
            text = "СОБРАТЬ ДИАГНОСТИКУ"
            setOnClickListener { collect() }
        })
        info = TextView(this).apply {
            textSize = 14f
            text = "Нажмите кнопку. Файл появится в /sdcard/Download/ (около минуты)."
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun collect() {
        info.text = "Сбор... подождите"
        Thread {
            val file = File("/sdcard/Download/omoda_diag_${System.currentTimeMillis() / 1000}.txt")
            val sb = StringBuilder()
            for ((title, cmd) in COMMANDS) {
                sb.append("\n===== ").append(title).append(" =====\n$ ").append(cmd).append('\n')
                sb.append(run(cmd)).append('\n')
            }
            val result = try {
                file.writeText(sb.toString())
                "Готово: ${file.absolutePath}, ${file.length() / 1024} КБ"
            } catch (e: Exception) {
                "Ошибка записи: ${e.message}"
            }
            runOnUiThread { info.text = result }
        }.start()
    }

    private fun run(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        var out = ""
        val reader = Thread { out = p.inputStream.bufferedReader().readText() }
        reader.start()
        reader.join(TIMEOUT_S * 1000)
        if (reader.isAlive) {
            p.destroy()
            out.take(MAX_OUT) + "\n(таймаут)"
        } else {
            p.waitFor(1, TimeUnit.SECONDS)
            out.take(MAX_OUT)
        }
    } catch (e: Exception) {
        "ошибка: ${e.message}"
    }

    companion object {
        private const val TIMEOUT_S = 25L
        private const val MAX_OUT = 300_000

        private val COMMANDS = listOf(
            "свойства" to "getprop | grep -E 'ro.product|ro.build|ro.hardware|ro.board|mega|vehicle|automotive'",
            "service list" to "service list",
            "lshal" to "lshal 2>&1 | head -400",
            "vintf манифесты" to "for f in /vendor/etc/vintf/manifest*.xml /vendor/manifest.xml /system/etc/vintf/manifest*.xml; do echo \"--- \$f\"; cat \"\$f\" 2>/dev/null; done",
            "vintf каталоги" to "ls -la /vendor/etc/vintf /system/etc/vintf 2>&1",
            "файлы mega" to "find /vendor /system /odm -iname '*mega*' 2>/dev/null | head -300",
            "процессы" to "ps -A | grep -i -E 'mega|vehicle|car'",
            "/dev" to "ls -la /dev | head -200",
            "журнал HAL" to "logcat -d -t 3000 2>&1 | grep -i -E 'mega|message_center|IVehicle|VehicleHal|libvintf|hwservice' | tail -400"
        )
    }
}
