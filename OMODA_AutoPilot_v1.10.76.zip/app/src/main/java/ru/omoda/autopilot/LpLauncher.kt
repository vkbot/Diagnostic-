package ru.omoda.autopilot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Скрывает иконку помощника из лаунчера. Через 60 секунд иконка возвращается сама. */
object LpLauncher {
    private const val ICON = "ru.omoda.autopilot.LpIcon"
    private const val RESTORE_DELAY_MS = 60_000L

    fun hide(c: Context) {
        setIcon(c, false)
        val intent = Intent(c, LpRestoreReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + RESTORE_DELAY_MS, pending)
    }

    fun restore(c: Context) {
        setIcon(c, true)
    }

    private fun setIcon(c: Context, on: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            ComponentName(c, ICON),
            if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
