package ru.omoda.autopilot

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.TimeUnit

/** Тест шины: только чтение. Ничего не пишет и не отправляет в шину. */
class CanProbeActivity : Activity() {
    private lateinit var out: TextView

    private val probes = listOf(
        "Список всех сервисов системы" to "dumpsys -l 2>&1",
        "CAN и serial-устройства в /dev" to "ls /dev 2>&1 | grep -iE 'can|ttyS|ttyUSB|ttyMT|vehicle|mcu'",
        "Сетевые интерфейсы" to "cat /proc/net/dev 2>&1",
        "Модули ядра (CAN, MCU, UART)" to "cat /proc/modules 2>&1 | grep -iE 'can|vehicle|mcu|uart'",
        "Драйверы tty" to "cat /proc/tty/drivers 2>&1",
        "Платформенные устройства" to "ls /sys/bus/platform/devices 2>&1 | grep -iE 'can|car|vehicle|mcu|uart'",
        "Вендорские бинарники" to "ls /vendor/bin /system/bin 2>&1 | grep -iE 'car|can|vehicle|vhal|mcu'",
        "Вендорские библиотеки" to "ls /vendor/lib64 /system/lib64 2>&1 | grep -iE 'vehicle|car|can|vhal'",
        "Приложения вендора" to "ls /system/priv-app /system/app /vendor/app 2>&1",
        "Сообщения ядра (dmesg)" to "dmesg 2>&1 | grep -iE 'can|vehicle|mcu|uart'",
        "Сервисы автомобиля" to "service list 2>&1 | grep -iE 'car|vehicle|omoda|chery|can'",
        "dumpsys car_service" to "dumpsys car_service 2>&1",
        "Свойства автомобиля и температур" to "getprop 2>&1 | grep -iE 'car|vehicle|chery|omoda|can|temp'",
        "Логи шины (последние)" to "logcat -d 2>&1 | grep -iE 'can|vehicle|vhal'"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Тест шины (только чтение)", 18f))

        out = TextView(this)
        out.text = "Сбор данных..."
        out.textSize = 11f
        out.typeface = Typeface.MONOSPACE
        out.setTextColor(COLOR_TEXT)
        out.setTextIsSelectable(true)
        root.addView(out, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
        collect()
    }

    private fun collect() {
        Thread {
            val file = File("/sdcard/Download/can_probe.txt")
            val header = "Устройство: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Сборка: ${Build.FINGERPRINT}\n\n"
            var fileInfo: String
            try {
                file.writeText(header)
                fileInfo = "Файл: ${file.path} (дополняется по мере сбора)"
            } catch (e: Exception) {
                fileInfo = "Файл не создан: ${e.javaClass.simpleName}: ${e.message}"
            }
            val info = fileInfo
            val sb = StringBuilder(header)
            fun add(section: String) {
                sb.append(section)
                if (info.startsWith("Файл: ")) {
                    try { file.appendText(section) } catch (e: Exception) { }
                }
                val snapshot = sb.toString()
                runOnUiThread { out.text = snapshot + "\n" + info }
            }
            for ((title, cmd) in probes) add("=== $title\n" + run(cmd) + "\n\n")
            add("=== Car API: свойства (только чтение)\n" + carProps() + "\n\n")
            add("=== Классы Car API\n" + classCheck() + "\n")
        }.start()
    }

    /**
     * Выполняет команду и возвращает весь вывод. Вывод пишется во временный файл, а не в канал:
     * иначе при выводе больше буфера канала (около 64 КБ) процесс зависает, и вывод обрывается по таймауту.
     */
    private fun run(cmd: String): String {
        val tmp = File(filesDir, "probe.out")
        return try {
            val p = ProcessBuilder("sh", "-c", cmd)
                .redirectErrorStream(true)
                .redirectOutput(tmp)
                .start()
            val finished = p.waitFor(180, TimeUnit.SECONDS)
            if (!finished) p.destroy()
            val text = if (tmp.exists()) tmp.readText().trim() else ""
            val body = text.ifEmpty { "(пусто)" }
            if (finished) body else body + "\n[обрезано: команда не завершилась за 180 с]"
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            tmp.delete()
        }
    }

    /** Есть ли в системе классы Car API и интерфейсы HAL автомобиля. */
    private fun classCheck(): String =
        listOf(
            "android.car.Car",
            "android.car.hardware.property.CarPropertyManager",
            "android.car.VehiclePropertyIds",
            "android.car.hardware.CarPropertyValue",
            "android.hardware.automotive.vehicle.V2_0.IVehicle"
        ).joinToString("\n") { name ->
            val ok = try { Class.forName(name); true } catch (e: Throwable) { false }
            "$name: ${if (ok) "есть" else "нет"}"
        }

    /** Список свойств автомобиля через Car API и значения тех, что читаются. Только get, set не вызываем. */
    private fun carProps(): String {
        return try {
        val carCls = Class.forName("android.car.Car")
        val car = carCls.getMethod("createCar", Context::class.java).invoke(null, this)
            ?: return "Car.createCar вернул null"
        val isConnected = carCls.getMethod("isConnected")
        var waited = 0
        while (waited < 5000 && isConnected.invoke(car) != true) {
            Thread.sleep(250)
            waited += 250
        }
        if (isConnected.invoke(car) != true) return "Car не подключился за 5 с"
        val mgr = carCls.getMethod("getCarManager", String::class.java).invoke(car, "property")
            ?: return "CarPropertyManager недоступен"
        val mcls = mgr.javaClass
        val configs = mcls.getMethod("getPropertyList").invoke(mgr) as List<*>
        val out = StringBuilder("Свойств всего: ${configs.size}\n")
        var reads = 0
        for (cfg in configs) {
            if (cfg == null) continue
            val c = cfg.javaClass
            val id = c.getMethod("getPropertyId").invoke(cfg) as Int
            val access = c.getMethod("getAccess").invoke(cfg) as Int
            val areas = c.getMethod("getAreaIds").invoke(cfg) as IntArray
            val area = areas.firstOrNull() ?: 0
            val canRead = (access and 1) != 0
            var value = "не читается (доступ: $access)"
            if (canRead && reads < 1000) {
                reads++
                value = try {
                    val pv = mcls.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
                        .invoke(mgr, id, area)
                    pv?.javaClass?.getMethod("getValue")?.invoke(pv)?.toString() ?: "null"
                } catch (e: Throwable) {
                    "ошибка: ${e.javaClass.simpleName}"
                }
            }
            out.append("0x${Integer.toHexString(id)} area=$area доступ=$access : $value\n")
        }
        out.toString()
    } catch (e: Throwable) {
        "Car API недоступен: ${e.javaClass.simpleName}: ${e.message}"
    }
    }
}
