package ru.omoda.autopilot

import android.app.Activity
import android.app.PendingIntent
import android.content.ComponentName
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Ищет APK на флешке и внутренней памяти и ставит выбранный через системный PackageInstaller.
 * Копирование в /data/local/tmp и команды pm не используются.
 */
class InstallTestActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var result: TextView

    private val searchRoots = listOf("/storage", "/mnt/media_rw", "/sdcard")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("Установка APK с флешки", 18f))
        root.addView(actionButton("ОБНОВИТЬ СПИСОК") { scan() })
        root.addView(actionButton("ПРОВЕРКИ И ФЛЕШКА") { runChecks() })
        root.addView(actionButton("РАЗРЕШИТЬ RUSTORE УСТАНОВКУ") { allowRuStore() })
        root.addView(actionButton("АВТО-УСТАНОВКА (ОТКРОЙТЕ RUSTORE)") { autoInstallFromStore() })
        val pkgInput = android.widget.EditText(this).apply {
            hint = "пакет, например ru.example.calc"
        }
        root.addView(pkgInput)
        root.addView(actionButton("УСТАНОВИТЬ ПО ПАКЕТУ") {
            val pkg = pkgInput.text.toString().trim()
            if (pkg.isEmpty()) { result.text = "Введите имя пакета"; return@actionButton }
            result.text = "Скачиваю $pkg..."
            Thread {
                val msg = try { installByPackage(pkg) } catch (e: Exception) { "ошибка: ${e.message}" }
                SettingsRepository(applicationContext).addEvent("установка по пакету $pkg: $msg")
                runOnUiThread { result.text = "$pkg: $msg" }
            }.start()
        })
        logBtn = actionButton("ЗАПИСЬ ЖУРНАЛА") { toggleInstallLog() }
        root.addView(logBtn)
        root.addView(actionButton("СТЕРЕТЬ ЖУРНАЛ") { clearInstallLog() })
        refreshLogButton()
        root.addView(actionButton("ПРОЧИТАТЬ ЖУРНАЛ") { showInstallLog() })
        root.addView(actionButton("СКОПИРОВАТЬ ЖУРНАЛ В ЗАГРУЗКИ") { copyInstallLog() })

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        result = labelView("", 13f, 12)
        root.addView(result)

        scan()
    }

    /** Выставляет RuStore разрешение на установку приложений и сразу проверяет его. */
    private fun allowRuStore() {
        result.text = "Разрешаю установку для RuStore..."
        Thread {
            val out = runShell(
                "cmd appops set ru.vk.store REQUEST_INSTALL_PACKAGES allow; " +
                "cmd appops get ru.vk.store REQUEST_INSTALL_PACKAGES"
            )
            SettingsRepository(applicationContext).addEvent("appops RuStore: $out")
            runOnUiThread { result.text = "RuStore, REQUEST_INSTALL_PACKAGES:\n$out" }
        }.start()
    }

    /**
     * Повторяет вашу ручную последовательность: клавиша 61 (Tab) переводит фокус,
     * клавиша 66 (Enter) нажимает кнопку «Установить». Дамп экрана нужен, чтобы знать,
     * где сейчас фокус. Окон установки может быть несколько, поэтому цикл продолжается,
     * пока кнопка «Установить» появляется на экране.
     */
    private fun autoInstallFromStore() {
        toast("Откройте RuStore на странице калькулятора. Проверяю окно установщика")
        Thread {
            Thread.sleep(300)
            val a11yInfo = armAccessibility()
            Thread.sleep(2000)
            SettingsRepository(applicationContext).addEvent("автоустановка: $a11yInfo, сервис подключён: ${LpA11y.connected}")
            // Если сервис подключён, он нажимает сам: цикл Tab/Enter не запускаем, чтобы не было двойных нажатий
            val useLoop = !LpA11y.connected
            if (!useLoop) {
                LpA11y.instance?.kick()
                val end = System.currentTimeMillis() + 100000
                while (System.currentTimeMillis() < end) {
                    showLive("Сервис нажимает сам (RuStore и установщик). Клики: ${LpA11y.clicks}. ${LpA11y.lastInfo}")
                    Thread.sleep(1000)
                }
            }
            var enters = 0
            var tabs = 0
            var idleRounds = 0
            var lastFocus = ""
            val started = System.currentTimeMillis()
            while (useLoop && System.currentTimeMillis() - started < 120000 && idleRounds < 20 && tabs < 14) {
                // Сначала mCurrentFocus; если не распознан, пакет берём из самого дампа окна
                val focusPkg = currentFocusPkg().let { if (it.startsWith("неизвестно")) dumpFocusPkg() else it }
                if (focusPkg != lastFocus) {
                    lastFocus = focusPkg
                    SettingsRepository(applicationContext).addEvent("автоустановка: фокус у $focusPkg")
                }
                if (focusPkg != "ru.vk.store" && focusPkg != "com.android.packageinstaller") {
                    // Наше приложение или другое окно в фокусе: не нажимаем, ждём RuStore
                    showLive("Жду RuStore. Сейчас в фокусе: $focusPkg. Откройте RuStore на калькуляторе")
                    Thread.sleep(1000)
                    continue
                }
                if (focusPkg == "com.android.packageinstaller") {
                    showLive("Системный установщик: нажимает сервис. Клики: ${LpA11y.clicks}")
                    Thread.sleep(1000)
                    continue
                }
                val nodes = parseNodes(dumpXml()).filter { it["package"] != packageName }
                val installNodes = nodes.filter {
                    it["text"].orEmpty().trim().equals("Установить", ignoreCase = true)
                }
                // Что скрипт видит в дампе: какие элементы помечены фокусом
                val focusInfo = nodes.filter { it["focused"] == "true" }
                    .joinToString(", ") { "«${it["text"].orEmpty()}»" }
                    .ifEmpty { "нет" }
                if (installNodes.isEmpty()) {
                    idleRounds++
                    if (idleRounds == 1) {
                        val texts = nodes.mapNotNull { it["text"]?.takeIf { t -> t.isNotBlank() } }.take(30).joinToString(" | ")
                        SettingsRepository(applicationContext).addEvent("автоустановка: в $focusPkg нет «Установить». Тексты: $texts")
                    }
                    showLive("Кнопки «Установить» не видно (проверка $idleRounds/20). Фокус: $focusInfo")
                    Thread.sleep(1000)
                    continue
                }
                idleRounds = 0
                val focusedInstall = installNodes.firstOrNull {
                    it["focused"] == "true" && it["enabled"] == "true"
                }
                if (focusedInstall != null) {
                    SettingsRepository(applicationContext).addEvent("автоустановка: Enter в окне $focusPkg")
                    runShell("input keyevent 66")
                    enters++
                    tabs = 0
                    showLive("Enter на «Установить» (#$enters). Жду следующее окно")
                    Thread.sleep(5000)
                } else {
                    SettingsRepository(applicationContext).addEvent("автоустановка: Tab в окне $focusPkg")
                    runShell("input keyevent 61")
                    tabs++
                    showLive("Tab=$tabs. Кнопка «Установить» видна, фокус на ней не отмечен. Фокус сейчас: $focusInfo")
                    Thread.sleep(800)
                }
            }
            LpA11y.armedUntil = 0
            val msg = if (enters == 0 && tabs == 0) {
                "кнопка «Установить» не найдена на экране"
            } else {
                "Готово. Tab=$tabs, Enter=$enters, клики сервиса=${LpA11y.clicks}"
            }
            SettingsRepository(applicationContext).addEvent("автоустановка: $msg")
            runOnUiThread { result.text = msg }
        }.start()
    }

    /** Пакет активного окна по дампу uiautomator: чаще всего встречающийся package. */
    private fun dumpFocusPkg(): String =
        parseNodes(dumpXml()).mapNotNull { it["package"] }
            .groupingBy { it }.eachCount()
            .maxByOrNull { it.value }?.key ?: "неизвестно"

    /** Пакет окна, которое сейчас в фокусе (из dumpsys window). */
    private fun currentFocusPkg(): String {
        val out = runRaw("dumpsys window | grep mCurrentFocus")
        return Regex("""([A-Za-z0-9_.]+)/""").find(out)?.groupValues?.get(1) ?: "неизвестно: ${out.take(120)}"
    }

    private fun installLogPath(): String = File(filesDir, "install_log.txt").absolutePath

    private var logBtn: android.view.View? = null

    /** GET/POST по API RuStore; заголовок версии обязателен с июля 2026. */
    private fun httpText(url: String, body: String? = null): String {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("ruStoreVerCode", "11500")
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    /** Ставит приложение по имени пакета: APK из API RuStore, установка через pm install. */
    private fun installByPackage(pkg: String): String {
        val info = httpText("https://backapi.rustore.ru/applicationData/overallInfo/$pkg")
        val appId = Regex("\"appId\"\\s*:\\s*(\\d+)").find(info)?.groupValues?.get(1)
            ?: return "не найден appId: ${info.take(150)}"
        val link = httpText("https://backapi.rustore.ru/applicationData/download-link",
            "{\"appId\":$appId,\"firstInstall\":true}")
        val apkUrl = Regex("\"apkUrl\"\\s*:\\s*\"([^\"]+)\"").find(link)?.groupValues?.get(1)
            ?: return "нет ссылки на APK: ${link.take(150)}"
        val file = File(filesDir, "$pkg.apk")
        (java.net.URL(apkUrl).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 60000
        }.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
        val p = ProcessBuilder("sh", "-c", "pm install -r -S ${file.length()}").redirectErrorStream(true).start()
        file.inputStream().use { it.copyTo(p.outputStream) }
        p.outputStream.close()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        file.delete()
        return out.trim()
    }

    /** Включает сервис LpA11y и взводит его на время автоустановки. */
    private fun armAccessibility(): String = try {
        val comp = ComponentName(this, LpA11y::class.java).flattenToString()
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        if (!cur.contains(comp)) {
            val next = if (cur.isEmpty()) comp else "$cur:$comp"
            Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next)
        }
        Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        LpA11y.armedUntil = System.currentTimeMillis() + 120000
        "сервис взведён"
    } catch (e: Exception) {
        "ошибка включения сервиса: ${e.message}"
    }

    private fun pidFile(): File = File(filesDir, "install_log.pid")

    /** Запись идёт, если в файле есть pid и процесс с таким pid жив. */
    private fun isLogRunning(): Boolean {
        val f = pidFile()
        if (!f.exists()) return false
        val pid = f.readText().trim()
        if (pid.isEmpty() || !pid.all { it.isDigit() }) return false
        return runRaw("[ -d /proc/$pid ] && echo yes").contains("yes")
    }

    /** Включает или выключает запись журнала logcat. */
    private fun toggleInstallLog() {
        if (isLogRunning()) {
            runRaw("kill ${pidFile().readText().trim()}")
            pidFile().delete()
            toast("Запись журнала выключена")
        } else {
            val pid = runRaw("logcat -f ${installLogPath()} -r 2048 -n 2 -v time >/dev/null 2>&1 & echo $!").trim()
            if (pid.isNotEmpty() && pid.all { it.isDigit() }) {
                pidFile().writeText(pid)
                toast("Запись журнала включена")
            } else {
                toast("Не удалось включить запись: $pid")
            }
        }
        refreshLogButton()
    }

    /** Стирает журнал; если запись идёт, сначала останавливает её. */
    private fun clearInstallLog() {
        if (isLogRunning()) toggleInstallLog()
        File(installLogPath()).delete()
        File(installLogPath() + ".1").delete()
        result.text = "Журнал стёрт"
        refreshLogButton()
    }

    private fun refreshLogButton() {
        val on = isLogRunning()
        (logBtn as? android.widget.Button)?.text =
            if (on) "ЗАПИСЬ ЖУРНАЛА: ВКЛ (нажать — выключить)" else "ЗАПИСЬ ЖУРНАЛА: ВЫКЛ (нажать — включить)"
    }

    private fun showInstallLog() {
        val text = runRaw("grep -iE 'автоустановка|A11y|InstallFailed|PackageManager|PackageInstaller|INSTALL_|status code|Installation' ${installLogPath()} | tail -n 80")
        result.text = if (text.isBlank()) "журнал пуст" else text.takeLast(2500)
    }

    /** Копирует журнал (обе части после ротации) в Загрузки средствами приложения. */
    private fun copyInstallLog() {
        val current = File(installLogPath())
        val rotated = File(installLogPath() + ".1")
        val dest = File("/sdcard/Download/omoda_install_log.txt")
        if (!current.exists() && !rotated.exists()) {
            result.text = "Файлов журнала нет: ${installLogPath()}\nСначала нажмите «ЗАПИСЬ ЖУРНАЛА: ВКЛ»"
            return
        }
        try {
            dest.outputStream().use { out ->
                for (part in listOf(rotated, current)) {
                    if (part.exists()) part.inputStream().use { it.copyTo(out) }
                }
            }
            result.text = "Журнал скопирован: ${dest.absolutePath}\nразмер ${dest.length() / 1024} КБ"
        } catch (e: Exception) {
            result.text = "Ошибка копирования: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Показывает текущий шаг автоустановки на экране, не дожидаясь конца цикла. */
    private fun showLive(text: String) {
        runOnUiThread { result.text = text }
    }

    /** Снимает дамп экрана в файл и возвращает XML. */
    private fun dumpXml(): String {
        val path = File(filesDir, "ui.xml").absolutePath
        runShell("uiautomator dump $path")
        return try { File(path).readText() } catch (e: Exception) { "" }
    }

    /** Выполняет команду и возвращает весь вывод без обрезки. */
    private fun runRaw(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text
        } catch (e: Exception) {
            ""
        }

    /** Разбирает узлы uiautomator dump: каждый узел — набор атрибутов key="value". */
    private fun parseNodes(xml: String): List<Map<String, String>> =
        Regex("<node [^>]*>").findAll(xml).map { match ->
            Regex("([\\w-]+)=\"([^\"]*)\"").findAll(match.value)
                .associate { it.groupValues[1] to it.groupValues[2] }
        }.toList()

    /** Корни всех томов хранения, включая флешку: по путям app-папок на каждом томе. */
    private fun volumeRoots(): List<File> {
        val roots = mutableListOf<File>()
        for (dir in getExternalFilesDirs(null)) {
            val path = dir?.absolutePath ?: continue
            val idx = path.indexOf("/Android/")
            if (idx > 0) roots.add(File(path.substring(0, idx)))
        }
        return roots
    }

    /** Полная проверка: права, uid, флешка, RuStore, место. Результат выводится на экран. */
    private fun runChecks() {
        val sb = StringBuilder()
        fun line(text: String) { sb.append(text).append('\n') }

        line("uid приложения: ${android.os.Process.myUid()}")
        val installGranted = checkSelfPermission("android.permission.INSTALL_PACKAGES") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        line("INSTALL_PACKAGES: " + if (installGranted) "выдано" else "НЕ выдано")
        val secureGranted = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        line("WRITE_SECURE_SETTINGS: " + if (secureGranted) "выдано" else "НЕ выдано")

        line("--- RuStore:")
        line(try {
            "ru.vk.store установлен, версия " + packageManager.getPackageInfo("ru.vk.store", 0).versionName
        } catch (e: Exception) {
            "ru.vk.store НЕ установлен"
        })

        line("--- флешка и хранилище:")
        line("/storage: " + (File("/storage").list()?.joinToString(", ") ?: "нет доступа"))
        line("/mnt/media_rw: " + (File("/mnt/media_rw").list()?.joinToString(", ") ?: "нет доступа"))
        line("--- sm list-volumes:")
        line(runRaw("sm list-volumes all").ifBlank { "пусто" })
        line("--- смонтированные накопители (/proc/mounts):")
        line(runRaw("grep -iE 'vfat|exfat|fuse|media|usb' /proc/mounts").ifBlank { "нет" })
        line("--- /storage глубже:")
        line(runRaw("ls -la /storage 2>&1; ls /mnt/media_rw 2>&1").ifBlank { "пусто" })
        line("/sdcard: " + (File("/sdcard").list()?.take(20)?.joinToString(", ") ?: "нет доступа"))
        line("getExternalFilesDirs:")
        getExternalFilesDirs(null).forEach { line("  " + (it?.absolutePath ?: "null")) }
        line("корни томов: " + volumeRoots().joinToString(", ") { it.absolutePath })
        line("точки монтирования:")
        line(runRaw("cat /proc/mounts | grep -iE 'storage|media|usb|fuse|vfat|exfat' | head -n 15").ifBlank { "  (пусто)" })

        line("--- место:")
        line(runRaw("df -h /data /sdcard 2>/dev/null | head -n 6").ifBlank { "(нет данных)" })

        result.text = sb.toString()
    }

    private fun scan() {
        list.removeAllViews()
        list.addView(labelView("Поиск APK...", 14f))
        Thread {
            val found = mutableListOf<File>()
            for (path in (searchRoots + volumeRoots().map { it.absolutePath }).distinct()) {
                try {
                    File(path).walkTopDown().maxDepth(4)
                        .filter { it.isFile && it.name.lowercase().endsWith(".apk") }
                        .forEach { found.add(it) }
                } catch (e: Exception) {
                    // недоступная папка пропускается
                }
            }
            runOnUiThread { showFiles(found) }
        }.start()
    }

    private fun showFiles(files: List<File>) {
        list.removeAllViews()
        if (files.isEmpty()) {
            list.addView(labelView("APK не найдены в: ${searchRoots.joinToString(", ")}", 14f))
            return
        }
        for (file in files.take(100)) {
            list.addView(actionButton("${file.name}  (${file.length() / 1024} КБ)\n${file.parent}") {
                install(file)
            })
        }
    }

    private fun install(file: File) {
        result.text = "Установка: ${file.name} ..."
        Thread {
            val abi = abiReport(file)
            SettingsRepository(applicationContext).addEvent("проверка ${file.name}: $abi")
            val text = try {
                installViaPmStdin(file)
            } catch (e: Exception) {
                "ошибка: ${e.javaClass.simpleName}: ${e.message}"
            }
            SettingsRepository(applicationContext).addEvent("установка ${file.name}: $text")
            runOnUiThread { result.text = "${file.name}\n$abi\n$text" }
        }.start()
    }

    /** Сравнивает архитектуры процессора ГУ с нативными библиотеками внутри APK. */
    private fun abiReport(file: File): String {
        val device = android.os.Build.SUPPORTED_ABIS.joinToString(",")
        val apkLibs = try {
            java.util.zip.ZipFile(file).use { zip ->
                java.util.Collections.list(zip.entries())
                    .map { it.name }
                    .filter { it.startsWith("lib/") }
                    .mapNotNull { it.split('/').getOrNull(1) }
                    .distinct()
                    .joinToString(",")
            }
        } catch (e: Exception) {
            "ошибка чтения: ${e.javaClass.simpleName}"
        }
        return "ГУ abi=[$device], APK lib=[${apkLibs.ifEmpty { "нет нативных библиотек" }}]"
    }

    /**
     * Передаёт APK в pm install через stdin: pm не открывает путь к файлу сам,
     * поэтому ограничения доступа к каталогам на него не действуют.
     */
    private fun installViaPmStdin(file: File): String {
        val quoted = "'" + file.absolutePath.replace("'", "'\\''") + "'"
        val cmd = "cat $quoted | pm install -r -S ${file.length()}"
        return runShell(cmd)
    }

    private fun runShell(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.trim().ifEmpty { "(пусто)" }.take(1000)
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }
}
