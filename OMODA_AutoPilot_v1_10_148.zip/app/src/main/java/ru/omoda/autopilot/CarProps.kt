package ru.omoda.autopilot

import java.lang.reflect.Constructor
import java.lang.reflect.Method

/** Общий доступ к свойствам машины через ICarProperty: одно подключение на процесс. */
object CarProps {
    private const val APK = "/system/priv-app/CarService/CarService.apk"

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private var link: Link? = null
    private val loader by lazy { dalvik.system.PathClassLoader(APK, ClassLoader.getSystemClassLoader()) }

    /** Значение или null, если свойство недоступно или статус не STATUS_AVAILABLE. */
    @Synchronized
    fun get(id: Int, area: Int): Any? = try {
        val l = link ?: connect().also { link = it }
        val got = l.getProp.invoke(l.prop, id, area)
        if (got != null && (l.getStatus.invoke(got) as Int) == 0) l.getValue.invoke(got) else null
    } catch (e: Throwable) {
        link = null
        null
    }

    /** Null — записано, иначе причина отказа. */
    @Synchronized
    fun set(id: Int, area: Int, v: Any): String? = try {
        val l = link ?: connect().also { link = it }
        l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, v))
        null
    } catch (e: Throwable) {
        link = null
        (e.cause ?: e).javaClass.simpleName
    }

    private fun connect(): Link {
        val cl = loader
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
