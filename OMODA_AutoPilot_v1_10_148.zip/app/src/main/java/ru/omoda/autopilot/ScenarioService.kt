package ru.omoda.autopilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Сценарии климата. Раз в 30 с читает температуру улицы и при похолодании ниже порога
 * включает подогревы. Срабатывает только при переходе вниз, чтобы не спорить с ручными настройками.
 * В скрытом режиме не работает.
 */
class ScenarioService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var level = 0

    private val tick = object : Runnable {
        override fun run() {
            worker.execute { evaluate() }
            handler.postDelayed(this, PERIOD_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Служба", NotificationManager.IMPORTANCE_MIN))
        }
        val n = Notification.Builder(this)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Служба")
            .setOngoing(true)
        if (Build.VERSION.SDK_INT >= 26) n.setChannelId(CHANNEL)
        startForeground(NOTIF_ID, n.build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (LpLauncher.armed(this) || !Scenarios.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun evaluate() {
        if (LpLauncher.armed(this)) {
            handler.post { stopSelf() }
            return
        }
        val t = (CarProps.get(OUTSIDE, 0) as? Number)?.toDouble() ?: return
        val newLevel = when {
            t < Scenarios.t2(this) -> 2
            t < Scenarios.t1(this) -> 1
            else -> 0
        }
        if (newLevel > level) {
            for (stage in (level + 1)..newLevel) runStage(stage)
        }
        level = newLevel
    }

    /** Ручной запуск: все этапы сразу, без проверки температуры. */
    fun applyNow() {
        worker.execute {
            runStage(1)
            runStage(2)
        }
    }

    private fun runStage(stage: Int) {
        val out = StringBuilder()
        fun put(name: String, id: Int, area: Int, v: Any) {
            val err = CarProps.set(id, area, v)
            out.append(name).append(if (err == null) " ок; " else " ($err); ")
        }
        if (stage == 1) {
            if (Scenarios.flag(this, "seats")) {
                put("подогрев водителя", DRV_SEAT, 16, Scenarios.seatLevel(this))
                put("подогрев пассажира", PASS_SEAT, 64, Scenarios.seatLevel(this))
            }
            if (Scenarios.flag(this, "hi")) {
                put("HI слева", LEFT_TEMP, 0, 30.5f)
                put("HI справа", RIGHT_TEMP, 64, 30.5f)
            }
        } else {
            if (Scenarios.flag(this, "front")) put("лобовое", FRONT_DEFROST, 0, 1)
            if (Scenarios.flag(this, "rear")) put("заднее", REAR_DEFROST, 0, 1)
        }
        Scenarios.setLast(this, "этап $stage: $out")
    }

    companion object {
        const val ACTION_APPLY = "ru.omoda.autopilot.SCENARIO_APPLY"
        private const val CHANNEL = "scen_min"
        private const val NOTIF_ID = 77
        private const val PERIOD_MS = 30_000L
        private const val OUTSIDE = 33554496
        private const val DRV_SEAT = 33554453
        private const val PASS_SEAT = 33554569
        private const val LEFT_TEMP = 33554551
        private const val RIGHT_TEMP = 33554552
        private const val FRONT_DEFROST = 33554486
        private const val REAR_DEFROST = 33554459
    }
}
