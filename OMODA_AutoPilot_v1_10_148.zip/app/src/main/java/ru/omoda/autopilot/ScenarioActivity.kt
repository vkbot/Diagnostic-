package ru.omoda.autopilot

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Экран сценариев: пороги, уровень сидений, какие действия включать. */
class ScenarioActivity : Activity() {
    private val views = HashMap<String, TextView>()
    private val seatLevels = listOf(2, 3, 4)
    private val seatNames = mapOf(2 to "уровень 1", 3 to "уровень 2", 4 to "уровень 3")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Сценарии климата"; textSize = 22f })

        root.addView(button("on") { toggleEnabled() })
        root.addView(line("t1", "−", { adjust("t1", -1, 3, 20) }, "+", { adjust("t1", 1, 3, 20) }))
        root.addView(line("t2", "−", { adjust("t2", -1, -15, Scenarios.t1(this) - 1) }, "+", { adjust("t2", 1, -15, Scenarios.t1(this) - 1) }))
        root.addView(line("seat", "−", { cycleSeat(-1) }, "+", { cycleSeat(1) }))
        root.addView(button("hi") { toggleFlag("hi") })
        root.addView(button("front") { toggleFlag("front") })
        root.addView(button("rear") { toggleFlag("rear") })
        root.addView(button("seats") { toggleFlag("seats") })
        root.addView(button("Проверить сейчас") { applyNow() })

        val status = TextView(this).apply { textSize = 14f }
        views["last"] = status
        root.addView(status)

        setContentView(ScrollView(this).apply { addView(root) })
        redraw()
    }

    private fun button(key: String, onClick: () -> Unit): Button =
        Button(this).apply {
            textSize = 16f
            setOnClickListener { onClick() }
            views[key] = this
        }

    private fun line(key: String, minusLabel: String, minus: () -> Unit, plusLabel: String, plus: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(this@ScenarioActivity).apply { text = minusLabel; textSize = 20f; setOnClickListener { minus() } })
            addView(TextView(this@ScenarioActivity).apply { textSize = 17f; views[key] = this })
            addView(Button(this@ScenarioActivity).apply { text = plusLabel; textSize = 20f; setOnClickListener { plus() } })
        }

    private fun adjust(key: String, delta: Int, min: Int, max: Int) {
        val cur = when (key) {
            "t1" -> Scenarios.t1(this)
            else -> Scenarios.t2(this)
        }
        val next = (cur + delta).coerceIn(min, max)
        Scenarios.setInt(this, key, next)
        redraw()
    }

    private fun cycleSeat(sign: Int) {
        val cur = Scenarios.seatLevel(this)
        val idx = seatLevels.indexOf(cur).let { if (it < 0) 0 else it }
        Scenarios.setInt(this, "seat", seatLevels[(idx + sign).coerceIn(0, seatLevels.size - 1)])
        redraw()
    }

    private fun toggleFlag(key: String) {
        Scenarios.setFlag(this, key, !Scenarios.flag(this, key))
        redraw()
    }

    private fun toggleEnabled() {
        if (LpLauncher.armed(this)) {
            Toast.makeText(this, "В скрытом режиме сценарии не работают", Toast.LENGTH_LONG).show()
            return
        }
        val on = !Scenarios.enabled(this)
        Scenarios.setEnabled(this, on)
        val intent = Intent(this, ScenarioService::class.java)
        if (on) {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } else {
            stopService(intent)
        }
        redraw()
    }

    private fun applyNow() {
        if (!Scenarios.enabled(this)) {
            Toast.makeText(this, "Сначала включите сценарии", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, ScenarioService::class.java).setAction(ScenarioService.ACTION_APPLY)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Запущено. Результат появится ниже", Toast.LENGTH_SHORT).show()
    }

    private fun redraw() {
        views["on"]?.text = "Сценарии: " + if (Scenarios.enabled(this)) "ВКЛ" else "ВЫКЛ"
        views["t1"]?.text = "Ниже ${Scenarios.t1(this)} °C: подогрев сидений и HI"
        views["t2"]?.text = "Ниже ${Scenarios.t2(this)} °C: ещё лобовое и заднее"
        views["seat"]?.text = "Уровень сидений: " + (seatNames[Scenarios.seatLevel(this)] ?: "")
        views["hi"]?.text = "HI 30,5: " + onOff("hi")
        views["front"]?.text = "Лобовое стекло: " + onOff("front")
        views["rear"]?.text = "Заднее стекло: " + onOff("rear")
        views["seats"]?.text = "Подогрев сидений: " + onOff("seats")
        views["last"]?.text = "Последний результат: " + Scenarios.last(this)
    }

    private fun onOff(key: String) = if (Scenarios.flag(this, key)) "вкл" else "выкл"
}
