@echo off
setlocal
set "SDK="
if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not defined SDK if exist "%USERPROFILE%\AppData\Local\Android\Sdk\platform-tools\adb.exe" set "SDK=%USERPROFILE%\AppData\Local\Android\Sdk"
if not defined SDK if exist "C:\Android\Sdk\platform-tools\adb.exe" set "SDK=C:\Android\Sdk"
if not defined SDK if exist "C:\Users\Vkbot\AppData\Local\Android\Sdk\platform-tools\adb.exe" set "SDK=C:\Users\Vkbot\AppData\Local\Android\Sdk"
if not defined SDK if exist "%LOCALAPPDATA%\Android\Sdk\platforms" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not defined SDK if exist "%USERPROFILE%\AppData\Local\Android\Sdk\platforms" set "SDK=%USERPROFILE%\AppData\Local\Android\Sdk"
if not defined SDK goto missing
(
  echo sdk.dir=%SDK:\=\\%
) > "%~dp0local.properties"
echo.
echo Android SDK found:
echo %SDK%
echo.
echo Created local.properties in the project folder.
echo Now reopen/sync the project in Android Studio.
echo.
pause
exit /b 0
:missing
echo.
echo Android SDK was not found in the usual locations.
echo This project cannot build until Android SDK is installed.
echo If Android Studio built another project, open that project and check its local.properties
necho to find the SDK path; then tell me the path and I will make a project-specific fix.
echo.
pause
exit /b 1
