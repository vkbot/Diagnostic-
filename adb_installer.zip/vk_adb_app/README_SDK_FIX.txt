SDK location helper
===================

If Android Studio says SDK location not found, double-click fix-sdk.bat in this project folder.
It searches common Android SDK locations and writes local.properties automatically.
Then return to Android Studio and sync the project.

If it says Android SDK was not found, the SDK is not in a standard location (or is not installed).
No Gradle project can build without an installed Android SDK. In that case, use the SDK path configured in an Android Studio project that already builds, or install the SDK through Android Studio.
