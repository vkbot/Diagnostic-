pluginManagement {
    repositories {
        google()
        // Maven Central mirror: use this when repo.maven.apache.org returns HTTP 403.
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        gradlePluginPortal()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // Maven Central mirror: use this when repo.maven.apache.org returns HTTP 403.
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        mavenCentral()
    }
}
rootProject.name = "vk_adb"
include(":app")
