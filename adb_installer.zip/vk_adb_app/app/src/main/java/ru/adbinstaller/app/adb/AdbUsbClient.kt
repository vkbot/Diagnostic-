package ru.adbinstaller.app.adb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger

internal data class ShellResult(
    val output: String,
    val exitCode: Int?,
    val completed: Boolean
)

/** Minimal ADB host transport over Android USB Host bulk endpoints. */
internal class AdbUsbClient(
    private val usbManager: UsbManager,
    private val device: UsbDevice,
    filesDir: File
) : Closeable {
    companion object {
        private const val CMD_CNXN = 0x4E584E43
        private const val CMD_AUTH = 0x48545541
        private const val CMD_OPEN = 0x4E45504F
        private const val CMD_OKAY = 0x59414B4F
        private const val CMD_WRTE = 0x45545257
        private const val CMD_CLSE = 0x45534C43
        private const val AUTH_TOKEN = 1
        private const val AUTH_SIGNATURE = 2
        private const val AUTH_RSAPUBLICKEY = 3
        private const val A_VERSION = 0x01000000
        private const val A_MAXDATA = 16384
        private const val USB_TIMEOUT_MS = 5000
        private const val MAX_PAYLOAD = 16384
        private val nextLocalId = AtomicInteger(1)
    }

    private var connection: UsbDeviceConnection? = null
    private var usbInterface: UsbInterface? = null
    private var inEndpoint: UsbEndpoint? = null
    private var outEndpoint: UsbEndpoint? = null
    private val crypto = AdbCrypto(File(filesDir, "adb_keys"))
    @Volatile private var closed = false
    @Volatile private var connected = false

    fun connect() {
        check(usbManager.hasPermission(device)) { "Нет разрешения Android USB Host API" }
        val intf = findAdbInterface() ?: error("У устройства нет ADB USB-интерфейса (FF/42/01 с Bulk IN/OUT)")
        val conn = usbManager.openDevice(device) ?: error("Android не смог открыть USB-устройство")
        connection = conn
        usbInterface = intf
        if (!conn.claimInterface(intf, true)) error("Не удалось захватить USB-интерфейс ADB")
        for (i in 0 until intf.endpointCount) {
            val endpoint = intf.getEndpoint(i)
            if (endpoint.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (endpoint.direction == UsbConstants.USB_DIR_IN) inEndpoint = endpoint
                if (endpoint.direction == UsbConstants.USB_DIR_OUT) outEndpoint = endpoint
            }
        }
        check(inEndpoint != null && outEndpoint != null) { "Не найдены Bulk IN/OUT endpoints" }
        crypto.loadOrCreate()
        val banner = "host::features=shell_v2,cmd\u0000".toByteArray(Charsets.UTF_8)
        sendPacket(CMD_CNXN, A_VERSION, A_MAXDATA, banner)

        var signatureSent = false
        var publicKeySent = false
        val deadline = System.currentTimeMillis() + 120_000L
        while (!connected && System.currentTimeMillis() < deadline) {
            val packet = readPacket((deadline - System.currentTimeMillis()).coerceAtLeast(1L).coerceAtMost(120_000L).toInt())
            when (packet.command) {
                CMD_CNXN -> connected = true
                CMD_AUTH -> {
                    if (packet.arg0 != AUTH_TOKEN) error("Неизвестный тип ADB AUTH: ${packet.arg0}")
                    when {
                        !signatureSent -> {
                            sendPacket(CMD_AUTH, AUTH_SIGNATURE, 0, crypto.signToken(packet.data))
                            signatureSent = true
                        }
                        !publicKeySent -> {
                            sendPacket(CMD_AUTH, AUTH_RSAPUBLICKEY, 0, crypto.publicKeyPayload())
                            publicKeySent = true
                        }
                        else -> sendPacket(CMD_AUTH, AUTH_SIGNATURE, 0, crypto.signToken(packet.data))
                    }
                }
                else -> error("Неожиданный ADB handshake packet: ${commandName(packet.command)}")
            }
        }
        check(connected) { "Тайм-аут ADB handshake. Подтвердите RSA-диалог на целевом телефоне и повторите подключение." }
    }

    fun shell(command: String): ShellResult {
        check(connected && !closed) { "ADB не подключён" }
        val localId = nextLocalId.getAndIncrement()
        val service = "shell,v2,raw:$command\u0000".toByteArray(Charsets.UTF_8)
        sendPacket(CMD_OPEN, localId, 0, service)
        var remoteId: Int? = null
        var exitCode: Int? = null
        val stdout = ByteArrayOutputStream()
        val stderr = ByteArrayOutputStream()
        val frameBuffer = ByteArrayOutputStream()
        val deadline = System.currentTimeMillis() + 90_000L

        while (System.currentTimeMillis() < deadline) {
            val packet = readPacket((deadline - System.currentTimeMillis()).coerceAtLeast(1L).coerceAtMost(90_000L).toInt())
            when (packet.command) {
                CMD_OKAY -> {
                    if (packet.arg1 == localId) remoteId = packet.arg0
                }
                CMD_WRTE -> {
                    if (packet.arg1 != localId) continue
                    val rid = remoteId ?: packet.arg0.also { remoteId = it }
                    sendPacket(CMD_OKAY, localId, rid, ByteArray(0))
                    frameBuffer.write(packet.data)
                    parseShellFrames(frameBuffer, stdout, stderr) { exitCode = it }
                }
                CMD_CLSE -> {
                    val rid = remoteId ?: packet.arg0
                    if (packet.arg1 == localId || packet.arg1 == 0) {
                        try { sendPacket(CMD_CLSE, localId, rid, ByteArray(0)) } catch (_: Exception) { }
                        val combined = buildString {
                            val out = stdout.toString(Charsets.UTF_8.name())
                            val err = stderr.toString(Charsets.UTF_8.name())
                            if (out.isNotEmpty()) append(out)
                            if (err.isNotEmpty()) {
                                if (isNotEmpty() && !endsWith("\n")) append('\n')
                                append("[stderr]\n").append(err)
                            }
                        }
                        return ShellResult(combined, exitCode, true)
                    }
                }
                CMD_CNXN -> Unit
                else -> error("Неожиданный пакет ADB shell: ${commandName(packet.command)}")
            }
        }
        return ShellResult((stdout.toString(Charsets.UTF_8.name()) + stderr.toString(Charsets.UTF_8.name())), exitCode, false)
    }

    private fun parseShellFrames(
        pending: ByteArrayOutputStream,
        stdout: ByteArrayOutputStream,
        stderr: ByteArrayOutputStream,
        onExit: (Int) -> Unit
    ) {
        var bytes = pending.toByteArray()
        var offset = 0
        while (bytes.size - offset >= 5) {
            val id = bytes[offset].toInt() and 0xFF
            val length = ByteBuffer.wrap(bytes, offset + 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (length < 0 || length > 1_048_576) error("Некорректная длина shell-v2 frame: $length")
            if (bytes.size - offset < 5 + length) break
            val payload = bytes.copyOfRange(offset + 5, offset + 5 + length)
            when (id) {
                1 -> stdout.write(payload)
                2 -> stderr.write(payload)
                3 -> onExit(if (payload.isNotEmpty()) payload[0].toInt() and 0xFF else 0)
                else -> Unit
            }
            offset += 5 + length
        }
        if (offset > 0) {
            val rest = bytes.copyOfRange(offset, bytes.size)
            pending.reset()
            pending.write(rest)
        }
    }

    /**
     * Загружает поток на устройство через ADB sync-сервис (SEND / DATA / DONE).
     * Возвращает количество отправленных байт.
     */
    fun push(input: java.io.InputStream, remotePath: String, mode: Int = 33188): Long {
        check(connected && !closed) { "ADB не подключён" }
        val localId = nextLocalId.getAndIncrement()
        sendPacket(CMD_OPEN, localId, 0, "sync:\u0000".toByteArray(Charsets.UTF_8))
        val remoteId = awaitOpenOkay(localId)
        val reply = ByteArrayOutputStream()
        var sent = 0L
        try {
            val pathMode = "$remotePath,$mode".toByteArray(Charsets.UTF_8)
            syncWrite(localId, remoteId, reply, syncHeader("SEND", pathMode.size) + pathMode)

            val buffer = ByteArray(16_000) // 8 байт заголовка + данные укладываются в MAX_PAYLOAD
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                if (n == 0) continue
                syncWrite(localId, remoteId, reply, syncHeader("DATA", n) + buffer.copyOf(n))
                sent += n
            }
            syncWrite(localId, remoteId, reply, syncHeader("DONE", (System.currentTimeMillis() / 1000).toInt()))
            val failure = awaitSyncAnswer(localId, reply)
            if (failure != null) error("Ошибка загрузки на устройство: $failure")
            return sent
        } finally {
            try { sendPacket(CMD_CLSE, localId, remoteId, ByteArray(0)) } catch (_: Exception) { }
        }
    }

    private fun syncHeader(id: String, value: Int): ByteArray =
        ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            .put(id.toByteArray(Charsets.US_ASCII)).putInt(value).array()

    private fun remainingMs(deadline: Long): Int =
        (deadline - System.currentTimeMillis()).coerceIn(1L, 60_000L).toInt()

    private fun awaitOpenOkay(localId: Int): Int {
        val deadline = System.currentTimeMillis() + 15_000L
        while (System.currentTimeMillis() < deadline) {
            val p = readPacket(remainingMs(deadline))
            if (p.arg1 != localId) continue
            when (p.command) {
                CMD_OKAY -> return p.arg0
                CMD_CLSE -> error("Устройство не открыло sync-сервис")
            }
        }
        error("Тайм-аут открытия sync-сервиса")
    }

    /** Отправляет WRTE и ждёт подтверждения OKAY; попутные ответы сервера складываются в reply. */
    private fun syncWrite(localId: Int, remoteId: Int, reply: ByteArrayOutputStream, bytes: ByteArray) {
        sendPacket(CMD_WRTE, localId, remoteId, bytes)
        val deadline = System.currentTimeMillis() + 60_000L
        while (System.currentTimeMillis() < deadline) {
            val p = readPacket(remainingMs(deadline))
            if (p.arg1 != localId) continue
            when (p.command) {
                CMD_OKAY -> return
                CMD_WRTE -> {
                    reply.write(p.data)
                    sendPacket(CMD_OKAY, localId, p.arg0, ByteArray(0))
                }
                CMD_CLSE -> error("Устройство закрыло sync-канал")
            }
        }
        error("Тайм-аут записи sync-канала")
    }

    /** null — успех (OKAY), иначе текст ошибки от FAIL. */
    private fun awaitSyncAnswer(localId: Int, reply: ByteArrayOutputStream): String? {
        val deadline = System.currentTimeMillis() + 60_000L
        while (System.currentTimeMillis() < deadline) {
            val bytes = reply.toByteArray()
            if (bytes.size >= 8) {
                val id = String(bytes, 0, 4, Charsets.US_ASCII)
                val len = ByteBuffer.wrap(bytes, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (id == "OKAY") return null
                if (id == "FAIL" && bytes.size >= 8 + len) return String(bytes, 8, len, Charsets.UTF_8)
                if (id != "FAIL") error("Неожиданный ответ sync: $id")
            }
            val p = readPacket(remainingMs(deadline))
            if (p.arg1 != localId) continue
            when (p.command) {
                CMD_WRTE -> {
                    reply.write(p.data)
                    sendPacket(CMD_OKAY, localId, p.arg0, ByteArray(0))
                }
                CMD_CLSE -> error("Устройство закрыло sync-канал без ответа")
            }
        }
        error("Тайм-аут ответа sync-сервиса")
    }

    private data class Packet(val command: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

    private fun sendPacket(command: Int, arg0: Int, arg1: Int, data: ByteArray) {
        check(data.size <= MAX_PAYLOAD) { "ADB payload превышает $MAX_PAYLOAD байт" }
        val header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(command).putInt(arg0).putInt(arg1).putInt(data.size)
            .putInt(checksum(data)).putInt(command.inv()).array()
        writeFully(header)
        if (data.isNotEmpty()) writeFully(data)
    }

    private fun readPacket(timeoutMs: Int): Packet {
        val deadline = System.currentTimeMillis() + timeoutMs
        val header = readFully(24, deadline)
        val b = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val command = b.int
        val arg0 = b.int
        val arg1 = b.int
        val length = b.int
        val expectedChecksum = b.int
        val magic = b.int
        check(magic == command.inv()) { "Повреждён ADB header: magic не совпадает" }
        check(length in 0..MAX_PAYLOAD) { "Недопустимый размер ADB payload: $length" }
        val data = if (length == 0) ByteArray(0) else readFully(length, deadline)
        check(checksum(data) == expectedChecksum) { "Ошибка контрольной суммы ADB packet" }
        return Packet(command, arg0, arg1, data)
    }

    private fun checksum(data: ByteArray): Int {
        var sum = 0
        for (byte in data) sum += byte.toInt() and 0xFF
        return sum
    }

    private fun readFully(length: Int, deadline: Long): ByteArray {
        val endpoint = inEndpoint ?: error("USB IN endpoint не готов")
        val conn = connection ?: error("USB connection закрыто")
        val result = ByteArray(length)
        var offset = 0
        while (offset < length) {
            check(!closed) { "USB соединение закрыто" }
            if (System.currentTimeMillis() >= deadline) error("Тайм-аут ожидания ADB packet")
            val remaining = (deadline - System.currentTimeMillis()).coerceAtLeast(1L).coerceAtMost(USB_TIMEOUT_MS.toLong()).toInt()
            val count = conn.bulkTransfer(endpoint, result, offset, length - offset, remaining)
            if (count <= 0) continue
            offset += count
        }
        return result
    }

    private fun writeFully(bytes: ByteArray) {
        val endpoint = outEndpoint ?: error("USB OUT endpoint не готов")
        val conn = connection ?: error("USB connection закрыто")
        var offset = 0
        while (offset < bytes.size) {
            check(!closed) { "USB соединение закрыто" }
            val count = conn.bulkTransfer(endpoint, bytes, offset, bytes.size - offset, USB_TIMEOUT_MS)
            if (count <= 0) error("USB запись ADB packet завершилась ошибкой")
            offset += count
        }
    }

    private fun findAdbInterface(): UsbInterface? {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass != 0xFF || intf.interfaceSubclass != 0x42 || intf.interfaceProtocol != 0x01) continue
            var input = false
            var output = false
            for (e in 0 until intf.endpointCount) {
                val endpoint = intf.getEndpoint(e)
                if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (endpoint.direction == UsbConstants.USB_DIR_IN) input = true
                if (endpoint.direction == UsbConstants.USB_DIR_OUT) output = true
            }
            if (input && output) return intf
        }
        return null
    }

    private fun commandName(command: Int) = when (command) {
        CMD_CNXN -> "CNXN"
        CMD_AUTH -> "AUTH"
        CMD_OPEN -> "OPEN"
        CMD_OKAY -> "OKAY"
        CMD_WRTE -> "WRTE"
        CMD_CLSE -> "CLSE"
        else -> "0x${command.toUInt().toString(16)}"
    }

    override fun close() {
        closed = true
        connected = false
        try { if (connection != null && usbInterface != null) connection?.releaseInterface(usbInterface) } catch (_: Exception) { }
        try { connection?.close() } catch (_: Exception) { }
        connection = null
        usbInterface = null
        inEndpoint = null
        outEndpoint = null
    }
}
