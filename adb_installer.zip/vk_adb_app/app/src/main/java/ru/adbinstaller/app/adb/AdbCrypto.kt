package ru.adbinstaller.app.adb

import android.util.Base64
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

/** ADB's RSA key format and token signing, using app-private files only. */
internal class AdbCrypto(private val directory: File) {
    private val privateFile = File(directory, "adb_private.pk8")
    private val publicFile = File(directory, "adb_public.x509")
    private lateinit var privateKey: PrivateKey
    private lateinit var publicKey: PublicKey

    fun loadOrCreate() {
        if (!directory.exists() && !directory.mkdirs()) error("Не удалось создать каталог ключей ADB")
        val factory = KeyFactory.getInstance("RSA")
        if (privateFile.exists() && publicFile.exists()) {
            privateKey = factory.generatePrivate(PKCS8EncodedKeySpec(privateFile.readBytes()))
            publicKey = factory.generatePublic(X509EncodedKeySpec(publicFile.readBytes()))
        } else {
            val generator = KeyPairGenerator.getInstance("RSA")
            generator.initialize(2048)
            val pair: KeyPair = generator.generateKeyPair()
            privateKey = pair.private
            publicKey = pair.public
            privateFile.writeBytes(privateKey.encoded)
            publicFile.writeBytes(publicKey.encoded)
            privateFile.setReadable(false, false)
            privateFile.setWritable(false, false)
            privateFile.setReadable(true, true)
            privateFile.setWritable(true, true)
        }
    }

    /** ADB AUTH signature is RSA PKCS#1 v1.5 padding over the raw 20-byte token. */
    fun signToken(token: ByteArray): ByteArray {
        require(token.size <= 245) { "Слишком длинный ADB AUTH token" }
        val modulusBytes = ((publicKey as java.security.interfaces.RSAPublicKey).modulus.bitLength() + 7) / 8
        val padded = ByteArray(modulusBytes)
        padded[0] = 0
        padded[1] = 1
        val separator = modulusBytes - token.size - 1
        for (i in 2 until separator) padded[i] = 0xFF.toByte()
        padded[separator] = 0
        System.arraycopy(token, 0, padded, separator + 1, token.size)
        val cipher = Cipher.getInstance("RSA/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, privateKey)
        return cipher.doFinal(padded)
    }

    fun publicKeyPayload(): ByteArray {
        val rsa = publicKey as? java.security.interfaces.RSAPublicKey ?: error("ADB public key is not RSA")
        val n = rsa.modulus
        val words = 64
        val n0inv = BigInteger.ONE.shiftLeft(32).subtract(n.modInverse(BigInteger.ONE.shiftLeft(32))).and(BigInteger("FFFFFFFF", 16)).toLong()
        val rr = BigInteger.ONE.shiftLeft(words * 32 * 2).mod(n)
        val raw = ByteBuffer.allocate((2 + words * 2) * 4).order(ByteOrder.LITTLE_ENDIAN)
        raw.putInt(words)
        raw.putInt(n0inv.toInt())
        putLittleEndianWords(raw, n, words)
        putLittleEndianWords(raw, rr, words)
        val encoded = Base64.encodeToString(raw.array(), Base64.NO_WRAP)
        return ("$encoded vk_adb@android\u0000").toByteArray(Charsets.US_ASCII)
    }

    private fun putLittleEndianWords(buffer: ByteBuffer, value: BigInteger, wordCount: Int) {
        val bytes = value.toByteArray()
        val little = ByteArray(wordCount * 4)
        for (i in bytes.indices) {
            val sourceIndex = bytes.size - 1 - i
            if (i < little.size) little[i] = bytes[sourceIndex]
        }
        for (i in 0 until wordCount) {
            val offset = i * 4
            val word = (little[offset].toInt() and 0xFF) or
                ((little[offset + 1].toInt() and 0xFF) shl 8) or
                ((little[offset + 2].toInt() and 0xFF) shl 16) or
                ((little[offset + 3].toInt() and 0xFF) shl 24)
            buffer.putInt(word)
        }
    }
}
