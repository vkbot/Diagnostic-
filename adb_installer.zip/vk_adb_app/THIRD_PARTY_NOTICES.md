# Third-party notices

Проект использует следующие зависимости через Maven/Google Maven; их исходные лицензии распространяются вместе с соответствующими пакетами:

- AndroidX Core KTX — Apache License 2.0.
- AndroidX AppCompat — Apache License 2.0.
- AndroidX Lifecycle Runtime KTX — Apache License 2.0.
- kotlinx.coroutines-android — Apache License 2.0.
- Android Gradle Plugin и Kotlin Gradle Plugin используются только для сборки.

ADB transport и RSA/mincrypt-формат в этом проекте реализованы непосредственно в исходниках проекта; внешняя ADB-библиотека не подключена.
