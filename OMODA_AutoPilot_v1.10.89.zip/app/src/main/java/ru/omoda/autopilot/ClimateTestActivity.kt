package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Тест записи климата и обогрева через Car API. Только при нулевой скорости.
 * Для каждого свойства: исходное значение, тестовое, запись, чтение, возврат исходного, проверка возврата.
 * Всё возвращается в исходное состояние, даже если запись или чтение упали.
 */
class ClimateTestActivity : Activity() {
    private lateinit var out: TextView
    private val log = StringBuilder()

    companion object {
        private const val SPEED_ID = 0x11600207
        private const val SETTLE_MS = 2000L

        /** Свойства из дампа car_service: имя и ID. Зона берётся первая из конфигурации. */
        private val TARGETS: List<Pair<String, Int>> = listOf(
            "HVAC_FAN_SPEED" to 0x15400500,
            "HVAC_TEMPERATURE_SET" to 0x15600503,
            "HVAC_AC_ON" to 0x15200505,
            "HVAC_RECIRC_ON" to 0x15200508,
            "HVAC_SEAT_TEMPERATURE" to 0x1540050B,
            "HVAC_STEERING_WHEEL_HEAT" to 0x1140050D,
            "HVAC_SEAT_VENTILATION" to 0x15400513,
            "HVAC_ELECTRIC_DEFROSTER_ON" to 0x13200514,
            "HVAC_DEFROSTER" to 0x13200504
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Тест климата и обогрева", 18f))
        root.addView(labelView("Машина на стоянке. Каждое свойство меняется на время проверки и возвращается обратно.", 13f, 4))
        out = TextView(this)
        out.textSize = 12f
        out.typeface = android.graphics.Typeface.MONOSPACE
        out.setTextColor(COLOR_TEXT)
        out.setTextIsSelectable(true)
        out.text = "Готово к запуску"
        root.addView(out, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(actionButton("ЗАПУСТИТЬ ТЕСТ") { runTest() })
        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
    }

    private fun say(line: String) {
        log.append(line).append("\n")
        val snapshot = log.toString()
        runOnUiThread { out.text = snapshot }
    }

    private fun runTest() {
        log.setLength(0)
        say("Подключение к Car API...")
        Thread {
            try {
                val mgr = connect()
                val speed = getValue(mgr, SPEED_ID, 0)
                say("Скорость: $speed")
                if ((speed as? Number)?.toDouble() != 0.0) {
                    say("ОТМЕНА: скорость не нулевая или не читается. Тест не запускался.")
                } else {
                    for ((name, id) in TARGETS) testOne(mgr, name, id)
                    say("Готово. Записано в /sdcard/Download/climate_test.txt")
                }
            } catch (e: Throwable) {
                say("Ошибка: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                try { File("/sdcard/Download/climate_test.txt").writeText(log.toString()) } catch (e: Exception) { }
            }
        }.start()
    }

    /** Одно свойство: зона, исходное значение, тестовое, запись, чтение, возврат. Возврат в finally. */
    private fun testOne(mgr: Any, name: String, id: Int) {
        val area: Int
        val orig: Any
        try {
            area = areaOf(mgr, id)
            orig = getValue(mgr, id, area) ?: throw IllegalStateException("значение не читается")
        } catch (e: Exception) {
            say("--- $name: пропущено: ${e.message}")
            return
        }
        val test = pickTest(orig)
        if (test == null) {
            say("--- $name: исходное $orig, тип не поддержан")
            return
        }
        say("--- $name (0x${Integer.toHexString(id)}, зона 0x${Integer.toHexString(area)}): исходное $orig, тест $test")
        try {
            setValue(mgr, id, area, orig.javaClass, test)
            Thread.sleep(SETTLE_MS)
            val readTest = getValue(mgr, id, area)
            say("    после записи: $readTest ${if (readTest == test) "(ок)" else "(НЕ ИЗМЕНИЛОСЬ)"}")
        } catch (e: Throwable) {
            say("    запись: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            try {
                setValue(mgr, id, area, orig.javaClass, orig)
                Thread.sleep(SETTLE_MS)
                val readBack = getValue(mgr, id, area)
                say("    возврат: $readBack ${if (readBack == orig) "(ок)" else "(НЕ ВЕРНУЛОСЬ, проверить вручную)"}")
            } catch (e: Throwable) {
                say("    возврат: ОШИБКА ${e.javaClass.simpleName}: ${e.message}, проверить вручную")
            }
        }
    }

    /** Тестовое значение по типу исходного. Для обогрева и вентиляции: 0 ↔ 1, для остальных — ±1. */
    private fun pickTest(orig: Any): Any? = when (orig) {
        is Boolean -> !orig
        is Int -> if (orig == 0) 1 else 0
        is Float -> if (orig <= 30f) orig + 1f else orig - 1f
        else -> null
    }

    private fun connect(): Any {
        val carCls = Class.forName("android.car.Car")
        val car = carCls.getMethod("createCar", android.content.Context::class.java).invoke(null, this)
            ?: throw IllegalStateException("Car.createCar вернул null")
        val isConnected = carCls.getMethod("isConnected")
        var waited = 0
        while (waited < 5000 && isConnected.invoke(car) != true) {
            Thread.sleep(250)
            waited += 250
        }
        if (isConnected.invoke(car) != true) throw IllegalStateException("Car не подключился за 5 с")
        return carCls.getMethod("getCarManager", String::class.java).invoke(car, "property")
            ?: throw IllegalStateException("CarPropertyManager недоступен")
    }

    /** Первая зона свойства из конфигурации. */
    private fun areaOf(mgr: Any, id: Int): Int {
        val configs = mgr.javaClass.getMethod("getPropertyList").invoke(mgr) as List<*>
        for (cfg in configs) {
            if (cfg == null) continue
            val c = cfg.javaClass
            if ((c.getMethod("getPropertyId").invoke(cfg) as Int) == id) {
                val areas = c.getMethod("getAreaIds").invoke(cfg) as IntArray
                return areas.firstOrNull() ?: 0
            }
        }
        throw IllegalStateException("нет в конфигурации")
    }

    private fun getValue(mgr: Any, id: Int, area: Int): Any? {
        val pv = mgr.javaClass.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            .invoke(mgr, id, area) ?: return null
        return pv.javaClass.getMethod("getValue").invoke(pv)
    }

    private fun setValue(mgr: Any, id: Int, area: Int, clazz: Class<*>, value: Any) {
        mgr.javaClass.getMethod(
            "setProperty", Class::class.java, Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType, Any::class.java
        ).invoke(mgr, clazz, id, area, value)
    }
}
