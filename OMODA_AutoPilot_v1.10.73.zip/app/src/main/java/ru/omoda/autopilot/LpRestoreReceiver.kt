package ru.omoda.autopilot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Возвращает иконку помощника по таймеру после скрытия. */
class LpRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        LpLauncher.restore(context)
    }
}
