package ru.omoda.autopilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale

/**
 * Фоновое распознавание. Ждёт имя вызова, отвечает «слушаю» и 5 секунд слушает команду.
 * «голос выключить» останавливает службу в любой момент.
 */
class VoiceService : Service() {
    @Volatile private var running = false
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "Голос", NotificationManager.IMPORTANCE_MIN))
        }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
            builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Голос включён")
                .setOngoing(true)
            startForeground(NOTIF_ID, builder.build())
            running = true
            Thread { loop() }.start()
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        var recognizer: Recognizer? = null
        var rec: AudioRecord? = null
        try {
            val model = Model(VoiceModel.path(this) { })
            recognizer = Recognizer(model, RATE.toFloat())
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            val buf = ByteArray(4000)
            rec.startRecording()
            var listenUntil = 0L
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0 || !recognizer.acceptWaveForm(buf, n)) continue
                val text = JSONObject(recognizer.getResult()).optString("text")
                if (text.isEmpty()) continue
                val lower = text.lowercase()
                if (lower.contains("голос выключ")) {
                    SettingsRepository(applicationContext).addEvent("голос: выключен голосом")
                    running = false
                    break
                }
                val wake = VoiceCommands.wake(this).lowercase()
                if (lower.contains(wake)) {
                    val rest = lower.substringAfter(wake)
                    if (VoiceCommands.match(VoiceCommands.load(this), rest) != null) {
                        handle(rest)
                        listenUntil = 0L
                    } else {
                        speak("слушаю")
                        listenUntil = System.currentTimeMillis() + LISTEN_MS
                    }
                } else if (System.currentTimeMillis() < listenUntil) {
                    listenUntil = 0L
                    handle(text)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "voice loop failed", e)
            SettingsRepository(applicationContext).addEvent("голос: ошибка ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            try { rec?.stop() } catch (e: Exception) { }
            rec?.release()
            recognizer?.close()
            running = false
            stopSelf()
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wake")
    }

    private fun handle(spoken: String) {
        val cmd = VoiceCommands.match(VoiceCommands.load(this), spoken) ?: return
        SettingsRepository(applicationContext).addEvent("голос: «$spoken» → «${cmd.phrase}»")
        when (cmd.type) {
            "app" -> packageManager.getLaunchIntentForPackage(cmd.arg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
            "wifi_on" -> setWifi(true)
            "wifi_off" -> setWifi(false)
        }
    }

    @Suppress("DEPRECATION")
    private fun setWifi(on: Boolean) {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = on
    }

    override fun onDestroy() {
        running = false
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "ru.omoda.voice.STOP"
        const val CHANNEL = "voice"
        const val NOTIF_ID = 78
        const val RATE = 16000
        const val LISTEN_MS = 5000L
        const val TAG = "OmodaVoice"
    }
}
