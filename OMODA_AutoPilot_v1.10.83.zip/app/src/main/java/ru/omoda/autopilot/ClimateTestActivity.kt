package ru.omoda.autopilot

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Тест записи климата через Car API. Только при нулевой скорости.
 * Меняет скорость вентилятора, температуру и кондиционер на время проверки и возвращает исходные значения.
 * Сиденья, руль и стёкла не трогает.
 */
class ClimateTestActivity : Activity() {
    private lateinit var out: TextView
    private val log = StringBuilder()

    companion object {
        private const val SPEED_ID = 0x11600207
        private const val FAN_ID = 0x15400500
        private const val TEMP_ID = 0x15600503
        private const val AC_ID = 0x15200505
        private const val SETTLE_MS = 2000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Тест записи климата", 18f))
        root.addView(labelView("Машина должна стоять. Тест меняет вентилятор, температуру и кондиционер и возвращает их обратно.", 13f, 4))
        out = TextView(this)
        out.textSize = 12f
        out.typeface = android.graphics.Typeface.MONOSPACE
        out.setTextColor(COLOR_TEXT)
        out.setTextIsSelectable(true)
        out.text = "Готово к запуску"
        root.addView(out, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(actionButton("ЗАПУСТИТЬ ТЕСТ ЗАПИСИ") { runTest() })
        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
    }

    private fun say(line: String) {
        log.append(line).append("\n")
        val snapshot = log.toString()
        runOnUiThread { out.text = snapshot }
    }

    private fun runTest() {
        log.setLength(0)
        say("Подключение к Car API...")
        Thread {
            try {
                val mgr = connect()
                val speed = getValue(mgr, SPEED_ID, 0)
                say("Скорость: $speed")
                if (speed == null || (speed as? Number)?.toDouble() != 0.0) {
                    say("ОТМЕНА: скорость не нулевая или не читается. Тест не запускался.")
                } else {
                    testFan(mgr)
                    testTemperature(mgr)
                    testAc(mgr)
                    say("Готово. Записано в /sdcard/Download/climate_test.txt")
                }
            } catch (e: Throwable) {
                say("Ошибка: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                try { File("/sdcard/Download/climate_test.txt").writeText(log.toString()) } catch (e: Exception) { }
            }
        }.start()
    }

    private fun testFan(mgr: Any) {
        val area = areaOf(mgr, FAN_ID)
        val orig = getValue(mgr, FAN_ID, area) as Int
        val test = if (orig >= 7) orig - 1 else orig + 1
        check(mgr, "HVAC_FAN_SPEED", FAN_ID, area, Int::class.javaObjectType, orig, test)
    }

    private fun testTemperature(mgr: Any) {
        val area = areaOf(mgr, TEMP_ID)
        val orig = getValue(mgr, TEMP_ID, area) as Float
        val test = if (orig <= 30f) orig + 1f else orig - 1f
        check(mgr, "HVAC_TEMPERATURE_SET", TEMP_ID, area, Float::class.javaObjectType, orig, test)
    }

    private fun testAc(mgr: Any) {
        val area = areaOf(mgr, AC_ID)
        val orig = getValue(mgr, AC_ID, area) as Boolean
        check(mgr, "HVAC_AC_ON", AC_ID, area, Boolean::class.javaObjectType, orig, !orig)
    }

    /** Записывает тестовое значение, читает обратно, возвращает исходное и проверяет. */
    private fun check(mgr: Any, name: String, id: Int, area: Int, clazz: Class<*>, orig: Any, test: Any) {
        say("--- $name: исходное $orig, тест $test")
        setValue(mgr, id, area, clazz, test)
        Thread.sleep(SETTLE_MS)
        val readTest = getValue(mgr, id, area)
        say("    после записи: $readTest ${if (readTest == test) "(ок)" else "(НЕ ИЗМЕНИЛОСЬ)"}")
        setValue(mgr, id, area, clazz, orig)
        Thread.sleep(SETTLE_MS)
        val readBack = getValue(mgr, id, area)
        say("    возврат: $readBack ${if (readBack == orig) "(ок)" else "(НЕ ВЕРНУЛОСЬ, проверить вручную)"}")
    }

    private fun connect(): Any {
        val carCls = Class.forName("android.car.Car")
        val car = carCls.getMethod("createCar", android.content.Context::class.java).invoke(null, this)
            ?: throw IllegalStateException("Car.createCar вернул null")
        val isConnected = carCls.getMethod("isConnected")
        var waited = 0
        while (waited < 5000 && isConnected.invoke(car) != true) {
            Thread.sleep(250)
            waited += 250
        }
        if (isConnected.invoke(car) != true) throw IllegalStateException("Car не подключился за 5 с")
        return carCls.getMethod("getCarManager", String::class.java).invoke(car, "property")
            ?: throw IllegalStateException("CarPropertyManager недоступен")
    }

    /** Первая зона свойства из конфигурации. */
    private fun areaOf(mgr: Any, id: Int): Int {
        val configs = mgr.javaClass.getMethod("getPropertyList").invoke(mgr) as List<*>
        for (cfg in configs) {
            if (cfg == null) continue
            val c = cfg.javaClass
            if ((c.getMethod("getPropertyId").invoke(cfg) as Int) == id) {
                val areas = c.getMethod("getAreaIds").invoke(cfg) as IntArray
                return areas.firstOrNull() ?: 0
            }
        }
        throw IllegalStateException("свойство 0x${Integer.toHexString(id)} не найдено")
    }

    private fun getValue(mgr: Any, id: Int, area: Int): Any? {
        val pv = mgr.javaClass.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            .invoke(mgr, id, area) ?: return null
        return pv.javaClass.getMethod("getValue").invoke(pv)
    }

    private fun setValue(mgr: Any, id: Int, area: Int, clazz: Class<*>, value: Any) {
        mgr.javaClass.getMethod(
            "setProperty", Class::class.java, Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType, Any::class.java
        ).invoke(mgr, clazz, id, area, value)
    }
}
