package ru.omoda.autopilot

import android.content.Context
import android.util.Base64
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.ByteArrayInputStream
import java.io.File
import java.util.Vector

/**
 * Обновление по SFTP. Новый APK ищется по имени: OMODA_AutoPilot-signed-ГГГГММДД-ЧЧММ.apk.
 * Версия сравнивается с временем установки приложения. Установка только по подтверждению.
 *
 * Ключ только на чтение кладётся в assets на этапе сборки из секрета SFTP_READ_KEY_B64.
 * Он виден в APK, поэтому на сервере у него должны быть права только на чтение.
 */
object UpdateChecker {
    /** Конфигурация SFTP вписывается в assets на этапе сборки из секретов GitHub (см. workflow). */
    private const val CFG_ASSET = "sftp_config.txt"
    private const val KEY_ASSET = "sftp_read_key.b64"

    private class Cfg(val host: String, val port: Int, val user: String, val knownHosts: String)

    private fun cfg(c: Context): Cfg {
        val text = c.assets.open(CFG_ASSET).use { it.readBytes() }.toString(Charsets.UTF_8)
        val m = text.lines().filter { it.contains('=') }
            .associate { it.substringBefore('=').trim() to it.substringAfter('=').trim() }
        val knownHosts = String(Base64.decode(m.getValue("known_hosts_b64"), Base64.DEFAULT), Charsets.UTF_8).trim()
        return Cfg(m.getValue("host"), m.getValue("port").toInt(), m.getValue("user"), knownHosts)
    }

    private val NAME = Regex("""OMODA_AutoPilot-signed-\d{8}-\d{4}\.apk""")

    class Remote(val name: String, val mtimeMs: Long)

    /**
     * Android 11 (API 30) не умеет проверять подписи Ed25519 своим провайдером.
     * Ставим BouncyCastle первым: тогда и ключ пользователя, и ключ сервера проверяются.
     */
    private fun ensureEd25519() {
        val current = java.security.Security.getProvider("BC")
        if (current == null || current.javaClass.name != "org.bouncycastle.jce.provider.BouncyCastleProvider") {
            java.security.Security.removeProvider("BC")
            java.security.Security.insertProviderAt(org.bouncycastle.jce.provider.BouncyCastleProvider(), 1)
        }
    }

    private fun connect(c: Context): Pair<Session, ChannelSftp> {
        ensureEd25519()
        val keyB64 = c.assets.open(KEY_ASSET).use { it.readBytes() }.toString(Charsets.US_ASCII).trim()
        var key = Base64.decode(keyB64, Base64.DEFAULT)
        // если в секрете base64 от base64 — декодируем второй раз
        if (!String(key, Charsets.US_ASCII).contains("PRIVATE KEY")) {
            key = Base64.decode(String(key, Charsets.US_ASCII).trim(), Base64.DEFAULT)
        }
        if (!String(key, Charsets.US_ASCII).contains("PRIVATE KEY")) {
            throw IllegalStateException("ключ не распознан: нужен приватный ключ OpenSSH")
        }
        val k = cfg(c)
        val jsch = JSch()
        jsch.setKnownHosts(ByteArrayInputStream(k.knownHosts.toByteArray()))
        try {
            jsch.addIdentity("omoda-read", key, null, null)
        } catch (e: Exception) {
            // диагностика без содержимого ключа: только заголовок и формат
            val text = String(key, Charsets.US_ASCII)
            val header = text.lines().firstOrNull()?.trim() ?: ""
            throw IllegalStateException(
                "${e.message}; заголовок='$header', строк=${text.lines().size}, CR=${text.contains('\r')}"
            )
        }
        val session = jsch.getSession(k.user, k.host, k.port)
        // просим у сервера ключ того типа, что уже есть в known_hosts (без смены секрета)
        session.setConfig("server_host_key", "ssh-ed25519")
        session.connect(15_000)
        val ch = session.openChannel("sftp") as ChannelSftp
        ch.connect(10_000)
        return Pair(session, ch)
    }

    /** Самый новый APK по имени (в имени дата-время, сортировка совпадает со временем). Null — файлов нет. */
    fun latestRemote(c: Context): Remote? {
        val (session, ch) = connect(c)
        try {
            var best: Remote? = null
            @Suppress("UNCHECKED_CAST")
            val entries = ch.ls(".") as Vector<ChannelSftp.LsEntry>
            for (e in entries) {
                val name = e.filename
                if (!NAME.matches(name)) continue
                if (best == null || name > best.name) {
                    best = Remote(name, e.attrs.mTime.toLong() * 1000L)
                }
            }
            return best
        } finally {
            ch.disconnect()
            session.disconnect()
        }
    }

    /** Новее ли файл на сервере, чем установленное приложение. */
    fun isNewer(c: Context, r: Remote): Boolean =
        r.mtimeMs > c.packageManager.getPackageInfo(c.packageName, 0).lastUpdateTime

    /** Скачивает, проверяет имя пакета и версию, ставит через pm install. Возвращает текст результата. */
    fun download(c: Context, r: Remote): String {
        var result: String
        try {
            val file = File(c.cacheDir, "update.apk")
            val (session, ch) = connect(c)
            try {
                ch.get(r.name, file.absolutePath)
            } finally {
                ch.disconnect()
                session.disconnect()
            }
            val pi = c.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
            val current = c.packageManager.getPackageInfo(c.packageName, 0).versionCode
            if (pi == null || pi.packageName != c.packageName || pi.versionCode <= current) {
                file.delete()
                result = "Пакет не совпадает с приложением или версия не новее"
            } else {
                InstallNotice.expect(c, r.name, pi.versionCode)
                val p = ProcessBuilder("sh", "-c", "pm install -r '${file.absolutePath}'")
                    .redirectErrorStream(true).start()
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor()
                result = out.take(300)
            }
        } catch (e: Throwable) {
            result = "Ошибка установки: ${e.javaClass.simpleName}: ${e.message}"
        }
        return result
    }
}
