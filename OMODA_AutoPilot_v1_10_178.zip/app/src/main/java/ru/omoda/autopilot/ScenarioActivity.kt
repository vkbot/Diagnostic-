package ru.omoda.autopilot

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Список профилей: создать, включить/выключить, изменить, проверить, удалить. */
class ScenarioActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Сценарии климата"; textSize = 22f })
        root.addView(button("+ Новый профиль") { edit(null) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        status = TextView(this).apply { textSize = 14f }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
        redraw()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            setOnClickListener { onClick() }
        }

    private fun redraw() {
        list.removeAllViews()
        for (pr in Scenarios.all(this)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            row.addView(TextView(this).apply { textSize = 16f; text = describe(pr) })
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(button(if (pr.enabled) "ВЫКЛ" else "ВКЛ") { toggle(pr.id) })
            btns.addView(button("Изменить") { edit(pr) })
            btns.addView(button("Проверить") { check(pr) })
            btns.addView(button("Удалить") { delete(pr.id) })
            row.addView(btns)
            list.addView(row)
        }
        status.text = "Последний результат: " + Scenarios.last(this)
    }

    private fun describe(pr: Scenarios.Profile): String {
        val acts = listOfNotNull(
            if (pr.seats) "сиденья, уровень ${pr.seatLevel - 1}" else null,
            if (pr.hi) "HI" else null,
            if (pr.front) "лобовое" else null,
            if (pr.rear) "заднее" else null,
            if (pr.steer) "руль" else null
        )
        return "${pr.name} [${if (pr.enabled) "ВКЛ" else "выкл"}]\n" +
            "условие: улица ${pr.op} ${pr.threshold} °C\n" +
            "действия: ${if (acts.isEmpty()) "нет" else acts.joinToString(", ")}"
    }

    private fun toggle(id: Long) {
        if (LpLauncher.armed(this)) {
            toast("В скрытом режиме сценарии не работают")
            return
        }
        val all = Scenarios.all(this)
        all.find { it.id == id }?.let { it.enabled = !it.enabled }
        Scenarios.save(this, all)
        syncService(all)
        redraw()
    }

    private fun delete(id: Long) {
        val all = Scenarios.all(this)
        all.removeAll { it.id == id }
        Scenarios.save(this, all)
        syncService(all)
        redraw()
    }

    /** Служба работает, пока включён хотя бы один профиль. */
    private fun syncService(all: List<Scenarios.Profile>) {
        val intent = Intent(this, ScenarioService::class.java)
        if (all.any { it.enabled }) {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } else {
            stopService(intent)
        }
    }

    /** Ручной запуск действий профиля, без проверки условия. */
    private fun check(pr: Scenarios.Profile) {
        val intent = Intent(this, ScenarioService::class.java)
            .setAction(ScenarioService.ACTION_APPLY)
            .putExtra(ScenarioService.EXTRA_ID, pr.id)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        toast("Запущено: ${pr.name}. Результат появится ниже")
    }

    /** Создание или изменение профиля: название, условие, порог, действия. */
    private fun edit(existing: Scenarios.Profile?) {
        val name = EditText(this).apply { hint = "Название"; setText(existing?.name ?: "Новый профиль") }
        var op = existing?.op ?: "<"
        val opBtn = Button(this).apply { text = "условие: $op" }
        opBtn.setOnClickListener {
            op = if (op == "<") ">" else "<"
            opBtn.text = "условие: $op"
        }
        var src = existing?.src ?: "out"
        val srcBtn = Button(this).apply { text = if (src == "in") "датчик: салон" else "датчик: улица" }
        srcBtn.setOnClickListener {
            src = if (src == "in") "out" else "in"
            srcBtn.text = if (src == "in") "датчик: салон" else "датчик: улица"
        }
        val thr = EditText(this).apply {
            hint = "порог, °C"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText((existing?.threshold ?: 10).toString())
        }
        val seats = CheckBox(this).apply { text = "подогрев сидений"; isChecked = existing?.seats ?: true }
        val lvl = EditText(this).apply {
            hint = "уровень сидений 1-3"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(((existing?.seatLevel ?: 4) - 1).toString())
        }
        val hi = CheckBox(this).apply { text = "HI 30,5"; isChecked = existing?.hi ?: true }
        val front = CheckBox(this).apply { text = "лобовое (не подтверждено на машине)"; isChecked = existing?.front ?: false }
        val rear = CheckBox(this).apply { text = "заднее стекло"; isChecked = existing?.rear ?: false }
        val steer = CheckBox(this).apply { text = "обогрев руля (только ВКЛ)"; isChecked = existing?.steer ?: false }

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            addView(name); addView(opBtn); addView(srcBtn); addView(thr)
            addView(seats); addView(lvl); addView(hi); addView(front); addView(rear); addView(steer)
        }
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Новый профиль" else "Изменить профиль")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("Сохранить") { _, _ ->
                val all = Scenarios.all(this)
                val target = all.find { it.id == existing?.id }
                val level = (lvl.text.toString().toIntOrNull() ?: 3).coerceIn(1, 3) + 1
                val t = thr.text.toString().toIntOrNull()?.coerceIn(-30, 40) ?: 10
                if (target == null) {
                    all.add(
                        Scenarios.Profile(
                            Scenarios.newId(), name.text.toString().ifBlank { "Профиль" }, false, op, t,
                            seats.isChecked, level, hi.isChecked, front.isChecked, rear.isChecked, steer.isChecked, src
                        )
                    )
                } else {
                    target.name = name.text.toString().ifBlank { "Профиль" }
                    target.op = op
                    target.threshold = t
                    target.seats = seats.isChecked
                    target.seatLevel = level
                    target.hi = hi.isChecked
                    target.front = front.isChecked
                    target.rear = rear.isChecked
                    target.steer = steer.isChecked
                    target.src = src
                }
                Scenarios.save(this, all)
                redraw()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
