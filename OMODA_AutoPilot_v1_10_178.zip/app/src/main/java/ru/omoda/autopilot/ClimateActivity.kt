package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.util.Locale
import java.util.concurrent.Executors

/** Климат для ежедневного использования: только подтверждённые на машине функции. */
class ClimateActivity : Activity() {
    private val apk = "/system/priv-app/CarService/CarService.apk"
    private val loader by lazy { dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader()) }
    private val pollBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private var msgView: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var link: Link? = null
    private val vals = HashMap<String, Any>()
    private val views = HashMap<String, TextView>()
    private val lastWrite = HashMap<String, Long>()

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private enum class Kind { TEMP, INT, LEVELS, DIR, SENSOR, TOGGLE }

    private class Row(
        val key: String,
        val title: String,
        val id: Int,
        val area: Int,
        val kind: Kind,
        val step: Double = 0.0,
        val min: Double = 0.0,
        val max: Double = 0.0,
        val levels: List<Int> = emptyList(),
        val names: Map<Int, String> = emptyMap(),
        /** Для TOGGLE: значение записи «вкл», «выкл» и значение чтения, при котором включено */
        val onV: Int = 0,
        val offV: Int = 0,
        val onRead: Int = 1
    )

    private class Fixed(val label: String, val id: Int, val area: Int, val value: Any)

    // выключение у машины — значение 1 (0 она игнорирует), уровни 1–3 — значения 2, 3, 4
    private val seatLevels = listOf(1, 2, 3, 4)
    private val seatNames = mapOf(0 to "выкл", 1 to "выкл", 2 to "уровень 1", 3 to "уровень 2", 4 to "уровень 3")
    private val dirNames = mapOf(0 to "выкл", 1 to "верх", 2 to "низ", 3 to "верх+низ", 4 to "стекло")

    private val rows = listOf(
        Row("left", "Температура слева", 33554551, 0, Kind.TEMP, 0.5, 16.0, 28.0),
        Row("right", "Температура справа", 33554552, 64, Kind.TEMP, 0.5, 16.0, 28.0),
        Row("fan", "Скорость обдува", 33554448, 80, Kind.INT, 1.0, 0.0, 10.0),
        Row("dir", "Направление обдува", 33554449, 80, Kind.DIR, names = dirNames),
        Row("seatDrv", "Подогрев водителя", 33554453, 16, Kind.LEVELS, levels = seatLevels, names = seatNames),
        Row("seatPass", "Подогрев переднего пассажира", 33554569, 64, Kind.LEVELS, levels = seatLevels, names = seatNames),
        Row("seatRL", "Подогрев задний левый", 33554570, 256, Kind.LEVELS, levels = seatLevels, names = seatNames),
        Row("seatRR", "Подогрев задний правый", 33554572, 1024, Kind.LEVELS, levels = seatLevels, names = seatNames),
        Row("ventDrv", "Вентиляция водителя", 33554454, 16, Kind.LEVELS, levels = seatLevels, names = seatNames),
        // Выключение найдено на ГУ (зона 0x400): руль 3, стекло 3, A/C 2, SYNC 2
        Row("steer", "Обогрев руля", 50331649, 1024, Kind.TOGGLE, onV = 1, offV = 3, onRead = 1),
        Row("rear", "Заднее стекло", 33554459, 1024, Kind.TOGGLE, onV = 1, offV = 3, onRead = 1),
        Row("ac", "Кондиционер A/C", 33554438, 1024, Kind.TOGGLE, onV = 1, offV = 2, onRead = 1),
        Row("sync", "SYNC", 33554436, 1024, Kind.TOGGLE, onV = 0, offV = 2, onRead = 0),
        Row("outside", "Температура улицы", 33554496, 0, Kind.SENSOR),
        Row("inside", "Температура салона", 33554497, 0, Kind.SENSOR)
    )

    private val fixed = listOf(
        Fixed("HI слева", 33554551, 0, 30.5f),
        Fixed("LO слева", 33554551, 0, 15.5f),
        Fixed("HI справа", 33554552, 64, 30.5f),
        Fixed("LO справа", 33554552, 64, 15.5f),
        Fixed("Авто климат", 33554435, 80, 1),
        Fixed("Рецирк внутр", 33554451, 0, 1),
        Fixed("Рецирк наруж", 33554451, 0, 2),
    )

    private val poll = object : Runnable {
        override fun run() {
            if (pollBusy.getAndSet(true)) {
                ui.postDelayed(this, 2000)
                return
            }
            worker.execute {
                try {
                    val l = link ?: connect().also { link = it }
                    for (r in rows) {
                        val got = l.getProp.invoke(l.prop, r.id, r.area)
                        val ok = got != null && (l.getStatus.invoke(got) as Int) == 0
                        val nv = if (ok) l.getValue.invoke(got) else null
                        runOnUiThread {
                            // сразу после нажатия не даём опросу вернуть старое значение
                            val recent = System.currentTimeMillis() - (lastWrite[r.key] ?: 0L) < 3000
                            if (!recent) {
                                // неудачное чтение не стирает последнее хорошее значение
                                if (nv != null) vals[r.key] = nv
                            }
                            render(r)
                        }
                    }
                } catch (e: Throwable) {
                    link = null
                } finally {
                    pollBusy.set(false)
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Климат"; textSize = 22f })
        msgView = TextView(this).apply { textSize = 15f; text = "" }
        root.addView(msgView)

        for (r in rows) {
            val label = TextView(this).apply { textSize = 17f; text = "${r.title}: —" }
            views[r.key] = label
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            when (r.kind) {
                Kind.TEMP, Kind.INT, Kind.LEVELS -> {
                    line.addView(button("−") { change(r, -1) })
                    line.addView(label)
                    line.addView(button("+") { change(r, 1) })
                }
                Kind.DIR -> {
                    line.addView(label)
                    listOf(1, 2, 3, 4).forEach { v ->
                        line.addView(button(dirNames[v] ?: v.toString()) { write(r.id, r.area, v, r.title) })
                    }
                }
                Kind.SENSOR -> line.addView(label)
                Kind.TOGGLE -> {
                    line.addView(label)
                    line.addView(button("вкл / выкл") { toggleRow(r) })
                }
            }
            root.addView(line)
        }

        root.addView(TextView(this).apply { textSize = 17f; text = "Быстрые кнопки:" })
        fixed.chunked(3).forEach { chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in chunk) line.addView(button(f.label) { write(f.id, f.area, f.value, f.label) })
            root.addView(line)
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** Запись во все зоны по очереди с логом в файл. */
    private fun writeAll(id: Int, value: Int, label: String) {
        worker.execute {
            CarProps.writeZones(id, value) { ClimateLog.line("$label: $it") }
            ClimateLog.line("$label: готово")
            runOnUiThread { msgView?.text = "$label: готово, см. omoda_climate_log.txt" }
        }
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            setOnClickListener { onClick() }
        }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun render(r: Row) {
        val v = vals[r.key]
        val text = when (r.kind) {
            Kind.TEMP, Kind.SENSOR -> if (v == null) "—" else String.format(Locale.US, "%.1f °C", (v as Number).toDouble())
            Kind.INT -> v?.toString() ?: "—"
            Kind.LEVELS, Kind.DIR -> if (v == null) "—" else r.names[(v as Number).toInt()] ?: v.toString()
            Kind.TOGGLE -> if (v == null) "—" else if ((v as Number).toInt() == r.onRead) "вкл" else "выкл"
        }
        views[r.key]?.text = "${r.title}: $text"
    }

    /** Шаг по температуре, скорости или уровню подогрева/вентиляции. */
    private fun change(r: Row, sign: Int) {
        val cur = vals[r.key]
        val v: Any = when (r.kind) {
            Kind.LEVELS -> {
                // следующий уровень по значению, а не по индексу: работает и если машина отдала не список-значение
                val c = (cur as? Number)?.toInt()?.coerceAtLeast(1) ?: 1
                val sorted = r.levels.sorted()
                if (sign > 0) sorted.firstOrNull { it > c } ?: sorted.last()
                else sorted.lastOrNull { it < c } ?: sorted.first()
            }
            Kind.TEMP -> ((cur as? Number)?.toDouble() ?: 22.0)
                .let { (it + sign * r.step).coerceIn(r.min, r.max).toFloat() }
            Kind.INT -> ((cur as? Number)?.toDouble() ?: 4.0)
                .let { (it + sign * r.step).coerceIn(r.min, r.max).toInt() }
            Kind.DIR, Kind.SENSOR, Kind.TOGGLE -> return
        }
        vals[r.key] = v
        lastWrite[r.key] = System.currentTimeMillis()
        render(r)
        write(r.id, r.area, v, r.title)
    }

    /** Переключение по текущему состоянию: если включено — пишем «выкл», иначе «вкл». */
    private fun toggleRow(r: Row) {
        val on = (vals[r.key] as? Number)?.toInt() == r.onRead
        write(r.id, r.area, if (on) r.offV else r.onV, r.title)
    }

    private fun write(id: Int, area: Int, v: Any, label: String = "") {
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, v))
            } catch (e: Throwable) {
                link = null
                val why = e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName
                runOnUiThread { msgView?.text = "не ушло: $label ($why)" }
            }
        }
    }

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = loader
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
