package ru.omoda.autopilot

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Ищет APK на флешке и внутренней памяти и ставит выбранный через системный PackageInstaller.
 * Копирование в /data/local/tmp и команды pm не используются.
 */
class InstallTestActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var result: TextView

    private val searchRoots = listOf("/storage", "/mnt/media_rw", "/sdcard")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("Установка APK с флешки", 18f))
        root.addView(actionButton("ОБНОВИТЬ СПИСОК") { scan() })
        root.addView(actionButton("РАЗРЕШИТЬ RUSTORE УСТАНОВКУ") { allowRuStore() })
        root.addView(actionButton("АВТО-УСТАНОВКА (ОТКРОЙТЕ RUSTORE)") { autoInstallFromStore() })

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        result = labelView("", 13f, 12)
        root.addView(result)

        scan()
    }

    /** Выставляет RuStore разрешение на установку приложений и сразу проверяет его. */
    private fun allowRuStore() {
        result.text = "Разрешаю установку для RuStore..."
        Thread {
            val out = runShell(
                "cmd appops set ru.vk.store REQUEST_INSTALL_PACKAGES allow; " +
                "cmd appops get ru.vk.store REQUEST_INSTALL_PACKAGES"
            )
            SettingsRepository(applicationContext).addEvent("appops RuStore: $out")
            runOnUiThread { result.text = "RuStore, REQUEST_INSTALL_PACKAGES:\n$out" }
        }.start()
    }

    /**
     * Повторяет вашу ручную последовательность: клавиша 61 (Tab) переводит фокус,
     * клавиша 66 (Enter) нажимает кнопку «Установить». Дамп экрана нужен, чтобы знать,
     * где сейчас фокус. Окон установки может быть несколько, поэтому цикл продолжается,
     * пока кнопка «Установить» появляется на экране.
     */
    private fun autoInstallFromStore() {
        toast("Откройте RuStore на странице калькулятора. Начинаю через 10 секунд")
        Thread {
            Thread.sleep(10000)
            var enters = 0
            var tabs = 0
            var idleRounds = 0
            val started = System.currentTimeMillis()
            while (System.currentTimeMillis() - started < 120000 && idleRounds < 8) {
                val nodes = parseNodes(dumpXml()).filter { it["package"] != packageName }
                val installNodes = nodes.filter {
                    it["text"].orEmpty().trim().equals("Установить", ignoreCase = true)
                }
                if (installNodes.isEmpty()) {
                    idleRounds++
                    Thread.sleep(1500)
                    continue
                }
                idleRounds = 0
                val focusedAny = nodes.firstOrNull { it["focused"] == "true" }
                if (focusedAny == null) {
                    // Фокус не виден в дампе: не нажимаем ничего, ждём, пока окно устаканится
                    Thread.sleep(1200)
                    continue
                }
                val focusedInstall = installNodes.firstOrNull { it["focused"] == "true" }
                if (focusedInstall != null && focusedInstall["enabled"] == "true") {
                    runShell("input keyevent 66")
                    enters++
                    // Ждём, пока откроется следующее окно, прежде чем снова смотреть на экран
                    Thread.sleep(4000)
                } else {
                    runShell("input keyevent 61")
                    tabs++
                    Thread.sleep(800)
                }
            }
            val msg = if (enters == 0 && tabs == 0) {
                "кнопка «Установить» не найдена на экране"
            } else {
                "Tab=$tabs, Enter=$enters (кнопка «Установить» нажата $enters раз)"
            }
            SettingsRepository(applicationContext).addEvent("автоустановка: $msg")
            runOnUiThread { result.text = msg }
        }.start()
    }

    /** Снимает дамп экрана в файл и возвращает XML. */
    private fun dumpXml(): String {
        val path = File(filesDir, "ui.xml").absolutePath
        runShell("uiautomator dump $path")
        return try { File(path).readText() } catch (e: Exception) { "" }
    }

    /** Выполняет команду и возвращает весь вывод без обрезки. */
    private fun runRaw(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text
        } catch (e: Exception) {
            ""
        }

    /** Разбирает узлы uiautomator dump: каждый узел — набор атрибутов key="value". */
    private fun parseNodes(xml: String): List<Map<String, String>> =
        Regex("<node [^>]*>").findAll(xml).map { match ->
            Regex("([\\w-]+)=\"([^\"]*)\"").findAll(match.value)
                .associate { it.groupValues[1] to it.groupValues[2] }
        }.toList()

    private fun scan() {
        list.removeAllViews()
        list.addView(labelView("Поиск APK...", 14f))
        Thread {
            val found = mutableListOf<File>()
            for (path in searchRoots) {
                try {
                    File(path).walkTopDown().maxDepth(4)
                        .filter { it.isFile && it.name.lowercase().endsWith(".apk") }
                        .forEach { found.add(it) }
                } catch (e: Exception) {
                    // недоступная папка пропускается
                }
            }
            runOnUiThread { showFiles(found) }
        }.start()
    }

    private fun showFiles(files: List<File>) {
        list.removeAllViews()
        if (files.isEmpty()) {
            list.addView(labelView("APK не найдены в: ${searchRoots.joinToString(", ")}", 14f))
            return
        }
        for (file in files.take(100)) {
            list.addView(actionButton("${file.name}  (${file.length() / 1024} КБ)\n${file.parent}") {
                install(file)
            })
        }
    }

    private fun install(file: File) {
        result.text = "Установка: ${file.name} ..."
        Thread {
            val abi = abiReport(file)
            SettingsRepository(applicationContext).addEvent("проверка ${file.name}: $abi")
            val text = try {
                installViaPmStdin(file)
            } catch (e: Exception) {
                "ошибка: ${e.javaClass.simpleName}: ${e.message}"
            }
            SettingsRepository(applicationContext).addEvent("установка ${file.name}: $text")
            runOnUiThread { result.text = "${file.name}\n$abi\n$text" }
        }.start()
    }

    /** Сравнивает архитектуры процессора ГУ с нативными библиотеками внутри APK. */
    private fun abiReport(file: File): String {
        val device = android.os.Build.SUPPORTED_ABIS.joinToString(",")
        val apkLibs = try {
            java.util.zip.ZipFile(file).use { zip ->
                java.util.Collections.list(zip.entries())
                    .map { it.name }
                    .filter { it.startsWith("lib/") }
                    .mapNotNull { it.split('/').getOrNull(1) }
                    .distinct()
                    .joinToString(",")
            }
        } catch (e: Exception) {
            "ошибка чтения: ${e.javaClass.simpleName}"
        }
        return "ГУ abi=[$device], APK lib=[${apkLibs.ifEmpty { "нет нативных библиотек" }}]"
    }

    /**
     * Передаёт APK в pm install через stdin: pm не открывает путь к файлу сам,
     * поэтому ограничения доступа к каталогам на него не действуют.
     */
    private fun installViaPmStdin(file: File): String {
        val quoted = "'" + file.absolutePath.replace("'", "'\\''") + "'"
        val cmd = "cat $quoted | pm install -r -S ${file.length()}"
        return runShell(cmd)
    }

    private fun runShell(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.trim().ifEmpty { "(пусто)" }.take(1000)
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }
}
