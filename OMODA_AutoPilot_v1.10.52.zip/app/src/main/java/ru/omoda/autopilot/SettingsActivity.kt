package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class SettingsActivity : Activity() {
    private lateinit var settings: SettingsRepository
    private lateinit var appsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsRepository(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("Настройки", 22f))
        root.addView(actionButton("Назад") { finish() })

        root.addView(checkBox("Включать Wi-Fi при загрузке", settings.isWifiEnabledOnBoot()) {
            settings.setWifiEnabledOnBoot(it)
        })
        root.addView(checkBox("Запускать приложения при загрузке", settings.isLaunchEnabledOnBoot()) {
            settings.setLaunchEnabledOnBoot(it)
        })

        root.addView(labelView("Задержка перед запуском при загрузке, мс", 15f, 16))
        val delay = EditText(this)
        delay.inputType = InputType.TYPE_CLASS_NUMBER
        delay.setText(settings.launchDelayMs().toString())
        root.addView(delay)
        root.addView(actionButton("Сохранить задержку") {
            val value = delay.text.toString().toLongOrNull()
            if (value == null || value < 0 || value > AutoStartConfig.MAX_DELAY_MS) {
                toast("Введи число от 0 до 60000")
            } else {
                settings.setLaunchDelayMs(value)
                toast("Сохранено")
            }
        })

        root.addView(labelView("Приложения автозапуска (package ID)", 16f, 20))
        appsContainer = LinearLayout(this)
        appsContainer.orientation = LinearLayout.VERTICAL
        root.addView(appsContainer)

        val pkgInput = EditText(this)
        pkgInput.hint = "например: com.github.uiautomator.test"
        pkgInput.setSingleLine(true)
        root.addView(pkgInput)
        root.addView(actionButton("Добавить приложение") {
            when (settings.addApp(pkgInput.text.toString())) {
                AddResult.ADDED -> {
                    pkgInput.text.clear()
                    refreshApps()
                    toast("Добавлено")
                }
                AddResult.INVALID -> toast("Некорректный package ID")
                AddResult.DUPLICATE -> toast("Уже в списке")
            }
        })

        refreshApps()
    }

    private fun refreshApps() {
        appsContainer.removeAllViews()
        val apps = settings.getApps()
        if (apps.isEmpty()) {
            appsContainer.addView(labelView("Список пуст", 14f))
        }
        for (app in apps) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            row.addView(
                labelView(app.packageName, 15f),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(actionButton("Удалить") {
                settings.removeApp(app.packageName)
                refreshApps()
            })
            appsContainer.addView(row)
        }
    }

    private fun checkBox(label: String, checked: Boolean, onChange: (Boolean) -> Unit): CheckBox {
        val box = CheckBox(this)
        box.text = label
        box.isChecked = checked
        box.setOnCheckedChangeListener { _, value -> onChange(value) }
        return box
    }
}
