package ru.omoda.autopilot

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

// Палитра: тёмный фон, карточки, акцент голубой
val COLOR_BG: Int = Color.parseColor("#0B0F14")
val COLOR_CARD: Int = Color.parseColor("#161D26")
val COLOR_ACCENT: Int = Color.parseColor("#29D3FF")
val COLOR_TEXT: Int = Color.parseColor("#E8EEF5")

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

fun Context.labelView(value: String, size: Float = 15f, topPadDp: Int = 0): TextView {
    val view = TextView(this)
    view.text = value
    view.textSize = size
    if (size >= 16f) {
        // заголовки: акцентный цвет и жирный шрифт
        view.setTextColor(COLOR_ACCENT)
        view.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    } else {
        view.setTextColor(COLOR_TEXT)
    }
    view.setPadding(0, dp(topPadDp), 0, dp(4))
    return view
}

fun Context.actionButton(caption: String, onClick: () -> Unit): Button {
    val button = Button(this)
    button.text = caption
    button.setAllCaps(false)
    button.textSize = 15f
    button.setTextColor(COLOR_TEXT)
    button.setPadding(dp(16), dp(12), dp(16), dp(12))
    button.background = GradientDrawable().apply {
        setColor(COLOR_CARD)
        cornerRadius = dp(14).toFloat()
        setStroke(dp(1), COLOR_ACCENT)
    }
    button.layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 0, 0, dp(10)) }
    button.setOnClickListener { onClick() }
    return button
}

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
