package ru.omoda.autopilot

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/** Квадрат в правом верхнем углу: проверка касаний. Иконку пока не трогает. */
object LpSquare {
    private var view: View? = null
    private var wm: WindowManager? = null
    private var count = 0
    private var lastTap = 0L
    private val handler = Handler(Looper.getMainLooper())

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    /** Возвращает null при успехе, иначе текст ошибки. onTap получает текст для пользователя. */
    fun show(c: Context, onTap: (String) -> Unit): String? {
        if (view != null) return null
        if (!canDraw(c)) return "Нет права «поверх других окон»"
        val manager = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = c.resources.displayMetrics
        val size = (60 * dm.density).toInt()
        val x = (dm.widthPixels - size).coerceAtLeast(0)

        val v = View(c)
        v.setBackgroundColor(0x01000000) // почти прозрачный, но принимает касания
        v.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            count = if (now - lastTap > 1500) 1 else count + 1
            lastTap = now
            onTap("нажатие $count из 5")
            if (count >= 5) {
                count = 0
                onTap("5 нажатий распознано")
                remove()
            }
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = 0
        return try {
            manager.addView(v, lp)
            view = v
            wm = manager
            handler.postDelayed({ remove() }, 30000)
            null
        } catch (e: Exception) {
            "addView: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    fun remove() {
        val v = view ?: return
        try {
            wm?.removeViewImmediate(v)
        } catch (e: Exception) {
            // окно уже снято системой
        }
        view = null
        wm = null
    }
}
