package ru.omoda.autopilot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.wifi.SupplicantState
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

private val GREY: Int = Color.parseColor("#6B7280")
private val GREEN: Int = Color.parseColor("#4ADE80")
private val AMBER: Int = Color.parseColor("#FBBF24")

class MainActivity : Activity() {
    private lateinit var settings: SettingsRepository
    private lateinit var wifiGlyph: TextView
    private lateinit var wifiLabel: TextView
    private lateinit var autoGlyph: TextView
    private lateinit var autoLabel: TextView
    private lateinit var eventsView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var tick = 0

    private val ticker = object : Runnable {
        override fun run() {
            refreshIndicators()
            tick++
            if (tick % 4 == 0) refreshEvents()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsRepository(this)
        installCrashHandler()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(24), dp(16), dp(24), dp(24))
        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })

        // Верхняя строка: название слева, индикаторы Wi-Fi и автозапуска справа
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = labelView("Помощник", 26f)
        title.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        top.addView(title)

        val wifi = makeIndicator()
        wifiGlyph = wifi.second
        wifiLabel = wifi.third
        wifi.first.setOnClickListener { toggleWifi() }
        top.addView(wifi.first)

        val auto = makeIndicator()
        autoGlyph = auto.second
        autoLabel = auto.third
        auto.first.setOnClickListener { toggleAutostart() }
        top.addView(auto.first)
        root.addView(top)

        root.addView(labelView(versionText(), 13f, 4))

        val run = actionButton("ЗАПУСТИТЬ") { runNow() }
        run.textSize = 22f
        run.minimumHeight = dp(96)
        val runParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        runParams.topMargin = dp(20)
        root.addView(run, runParams)

        root.addView(actionButton("Установка APK") { openInstall("apk") })
        root.addView(actionButton("Скрытие приложений") {
            startActivity(Intent(this, HideAppsActivity::class.java))
        })
        root.addView(actionButton("Файловый менеджер") { openFiles() })
        root.addView(actionButton("ТЕСТ КВАДРАТА (временно)") { testSquare() })
        root.addView(actionButton("Лог падения") {
            startActivity(Intent(this, CrashLogActivity::class.java))
        })
        root.addView(actionButton("Настройки") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        root.addView(actionButton("Настройки Android") {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        })

        root.addView(labelView("Уведомления", 16f, 20))
        eventsView = labelView("", 13f, 4)
        root.addView(eventsView)

        refreshIndicators()
        refreshEvents()
    }

    override fun onResume() {
        super.onResume()
        if (::eventsView.isInitialized) handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun versionText(): String =
        try {
            val info = packageManager.getPackageInfo(packageName, 0)
            "Версия ${info.versionName} (код ${info.versionCode})"
        } catch (e: Exception) {
            "Версия неизвестна"
        }

    /** Временный тест: квадрат в углу, каждое касание подтверждается сообщением. */
    private fun testSquare() {
        if (!LpSquare.canDraw(this)) {
            startActivity(android.content.Intent(
                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            ))
            toast("Разрешите «поверх других окон» и нажмите ещё раз")
            return
        }
        val err = LpSquare.show(this) { msg ->
            toast(msg)
            SettingsRepository(applicationContext).addEvent("тест квадрата: $msg")
        }
        toast(err ?: "Квадрат в правом верхнем углу на 30 секунд")
    }

    /** Пишет текст падения в файл, чтобы его можно было посмотреть в окне «Лог падения». */
    private fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                File(filesDir, "crash.txt").writeText(
                    "Поток: ${thread.name}\n" + error.stackTraceToString()
                )
            } catch (e: Exception) {
                // запись не удалась, падение всё равно передаём системе
            }
            previous?.uncaughtException(thread, error)
        }
    }

    private fun openInstall(mode: String) {
        startActivity(Intent(this, InstallTestActivity::class.java).putExtra("mode", mode))
    }

    private fun openFiles() {
        val intent = packageManager.getLaunchIntentForPackage("com.android.documentsui")
        if (intent == null) {
            toast("Приложение «Файлы» не найдено (com.android.documentsui)")
            return
        }
        startActivity(intent)
    }

    private fun runNow() {
        startService(Intent(this, AutoPilotService::class.java).setAction(AutoStartConfig.ACTION_RUN_ALL))
        toast("Запущено")
    }

    private fun makeIndicator(): Triple<LinearLayout, TextView, TextView> {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(6), dp(10), dp(6))
        row.background = GradientDrawable().apply {
            setColor(COLOR_CARD)
            cornerRadius = dp(12).toFloat()
        }
        row.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(8), 0, 0, 0) }
        val glyph = TextView(this)
        glyph.textSize = 18f
        glyph.setPadding(0, 0, dp(6), 0)
        val label = TextView(this)
        label.textSize = 13f
        label.setTextColor(COLOR_TEXT)
        row.addView(glyph)
        row.addView(label)
        return Triple(row, glyph, label)
    }

    /** 0 — выключен, 1 — подключён, 2 — включён без сети, 3 — идёт подключение. */
    @Suppress("DEPRECATION")
    private fun wifiState(): Int {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) return 0
        val info = wm.connectionInfo
        val st = info?.supplicantState
        return when {
            st == SupplicantState.COMPLETED && info != null && info.networkId != -1 -> 1
            st == SupplicantState.ASSOCIATING || st == SupplicantState.ASSOCIATED ||
                st == SupplicantState.AUTHENTICATING || st == SupplicantState.FOUR_WAY_HANDSHAKE ||
                st == SupplicantState.GROUP_HANDSHAKE || st == SupplicantState.SCANNING -> 3
            else -> 2
        }
    }

    @Suppress("DEPRECATION")
    private fun toggleWifi() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.isWifiEnabled = !wm.isWifiEnabled
        refreshIndicators()
    }

    private fun toggleAutostart() {
        val on = settings.isWifiEnabledOnBoot() || settings.isLaunchEnabledOnBoot()
        settings.setWifiEnabledOnBoot(!on)
        settings.setLaunchEnabledOnBoot(!on)
        refreshIndicators()
    }

    private fun refreshIndicators() {
        when (wifiState()) {
            0 -> {
                wifiGlyph.text = "⊘"; wifiGlyph.setTextColor(GREY); wifiGlyph.alpha = 1f
                wifiLabel.text = "Wi-Fi выкл"
            }
            1 -> {
                wifiGlyph.text = "◉"; wifiGlyph.setTextColor(GREEN); wifiGlyph.alpha = 1f
                wifiLabel.text = "Wi-Fi подключён"
            }
            2 -> {
                wifiGlyph.text = "◌"; wifiGlyph.setTextColor(AMBER); wifiGlyph.alpha = 1f
                wifiLabel.text = "Wi-Fi нет сети"
            }
            else -> {
                wifiGlyph.text = "◌"; wifiGlyph.setTextColor(AMBER)
                wifiGlyph.alpha = if (tick % 2 == 0) 1f else 0.15f
                wifiLabel.text = "Wi-Fi подключение…"
            }
        }
        val on = settings.isWifiEnabledOnBoot() || settings.isLaunchEnabledOnBoot()
        autoGlyph.text = "●"
        autoGlyph.setTextColor(if (on) COLOR_ACCENT else GREY)
        autoLabel.text = if (on) "Автозапуск вкл" else "Автозапуск выкл"
    }

    /** Из уведомлений убираем служебный шум: автоустановку, перехват, службу доступности, скрытие. */
    private fun refreshEvents() {
        val lines = settings.events().filter { line -> NOISE.none { line.contains(it) } }
        eventsView.text = lines.ifEmpty { listOf("Пока пусто") }.joinToString("\n")
    }

    companion object {
        private val NOISE = listOf("автоустановка", "[установка]", "A11y", "сервис", "скрытие", "установка по пакету")
    }
}
