package ru.omoda.autopilot

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Временное окно: полный текст последнего падения на весь экран. */
class CrashLogActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(8), dp(8), dp(8), dp(8))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })

        val file = File(filesDir, "crash.txt")
        val text = TextView(this)
        text.text = if (file.exists()) file.readText() else "Падений не записано"
        text.textSize = 11f
        text.typeface = Typeface.MONOSPACE
        text.setTextColor(COLOR_TEXT)
        text.setTextIsSelectable(true)
        root.addView(text, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
    }
}
