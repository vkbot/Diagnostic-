package ru.omoda.autopilot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.zip.ZipInputStream

/** Голосовые команды офлайн: запись 5 секунд, распознавание Vosk, выполнение команды. */
class VoiceTestActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var text: TextView
    private lateinit var command: TextView
    private var model: Model? = null
    private val rate = 16000
    private val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"
    private val modelZipSize = 46236750L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.setBackgroundColor(COLOR_BG)
        root.addView(actionButton("НАЗАД") { finish() })
        root.addView(labelView("Голосовые команды", 18f))
        root.addView(labelView("Скажите: «карты», «музыка», «вай-фай включи», «вай-фай выключи»", 13f, 4))
        status = labelView("Нажмите «СЛУШАТЬ 5 СЕК» и говорите", 14f, 8)
        root.addView(status)
        text = labelView("", 22f, 8)
        root.addView(text)
        command = labelView("", 16f, 8)
        root.addView(command)
        root.addView(actionButton("СЛУШАТЬ 5 СЕК") { startCheck() })
        setContentView(ScrollView(this).also { it.setBackgroundColor(COLOR_BG); it.addView(root) })
    }

    private fun startCheck() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        record()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) record()
        else status.text = "Нет доступа к микрофону"
    }

    /**
     * Возвращает папку модели. Если её ещё нет: берёт из /sdcard/Download или скачивает архив с сайта Vosk.
     * Скачивание идёт один раз, дальше модель лежит во внутренней памяти приложения.
     */
    private fun ensureModel(progress: (String) -> Unit): String {
        val dest = File(filesDir, "vosk-model")
        if (dest.isDirectory) return dest.absolutePath
        val tmp = File(filesDir, "vosk-model.tmp")
        tmp.deleteRecursively()
        val external = File("/sdcard/Download/vosk-model-small-ru-0.22")
        if (assets.list("vosk-model-small-ru-0.22")?.contains("am") == true) {
            progress("Копирую модель из приложения...")
            copyAssets("vosk-model-small-ru-0.22", tmp)
        } else if (external.isDirectory) {
            progress("Копирую модель из Загрузок...")
            external.copyRecursively(tmp, overwrite = true)
        } else {
            val zip = File(filesDir, "vosk-model.zip")
            progress("Скачиваю модель (около 46 МБ), нужен Wi-Fi...")
            java.net.URL(modelUrl).openStream().use { input ->
                zip.outputStream().use { input.copyTo(it) }
            }
            if (zip.length() != modelZipSize) {
                zip.delete()
                throw IllegalStateException("архив скачан неполностью: ${zip.length()} байт")
            }
            progress("Распаковываю модель...")
            unzipModel(zip, tmp)
            zip.delete()
        }
        if (!tmp.isDirectory) throw IllegalStateException("модель не распаковалась")
        tmp.renameTo(dest)
        return dest.absolutePath
    }

    private fun copyAssets(path: String, dest: File) {
        val children = assets.list(path) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
        } else {
            dest.mkdirs()
            for (child in children) copyAssets("$path/$child", File(dest, child))
        }
    }

    /** Распаковывает архив, убирая верхнюю папку. Защита от путей с "..". */
    private fun unzipModel(zip: File, target: File) {
        ZipInputStream(zip.inputStream()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val rel = entry.name.substringAfter('/', "")
                if (rel.isNotEmpty() && !rel.contains("..")) {
                    val f = File(target, rel)
                    if (entry.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
    }

    private fun record() {
        status.text = "Идёт запись, говорите..."
        text.text = ""
        command.text = ""
        Thread {
            var recognizer: Recognizer? = null
            var rec: AudioRecord? = null
            try {
                val m = model ?: Model(ensureModel { msg -> runOnUiThread { status.text = msg } }).also { model = it }
                runOnUiThread { status.text = "Идёт запись, говорите..." }
                recognizer = Recognizer(m, rate.toFloat())
                val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
                val buf = ByteArray(4000)
                val until = System.currentTimeMillis() + 5000
                rec.startRecording()
                while (System.currentTimeMillis() < until) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) recognizer.acceptWaveForm(buf, n)
                }
                val result = JSONObject(recognizer.getFinalResult()).optString("text")
                runOnUiThread {
                    status.text = "Готово"
                    text.text = if (result.isEmpty()) "(ничего не распознано)" else result
                    if (result.isNotEmpty()) handle(result)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка: ${e.javaClass.simpleName}: ${e.message}" }
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                rec?.release()
                recognizer?.close()
            }
        }.start()
    }

    /** Выполняет команду по ключевым словам. Вызывается на UI-потоке. */
    private fun handle(spoken: String) {
        val t = spoken.lowercase()
        command.text = when {
            t.contains("карт") -> launch("ru.yandex.yandexmaps", "Яндекс Карты")
            t.contains("музык") -> launch("ru.yandex.music", "Яндекс Музыка")
            t.contains("вай фай") || t.contains("вайфай") || t.contains("wi-fi") || t.contains("wifi") || t.contains("вай-фай") -> wifi(t)
            else -> "Команда не распознана"
        }
    }

    private fun launch(pkg: String, name: String): String {
        val intent: Intent = packageManager.getLaunchIntentForPackage(pkg) ?: return "$name не установлено"
        startActivity(intent)
        return "Открываю: $name"
    }

    @Suppress("DEPRECATION")
    private fun wifi(t: String): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return when {
            t.contains("выключ") -> { wm.isWifiEnabled = false; "Wi-Fi выключен" }
            t.contains("включ") -> { wm.isWifiEnabled = true; "Wi-Fi включён" }
            else -> "Скажите «включи» или «выключи» Wi-Fi"
        }
    }

    override fun onDestroy() {
        model?.close()
        model = null
        super.onDestroy()
    }
}
