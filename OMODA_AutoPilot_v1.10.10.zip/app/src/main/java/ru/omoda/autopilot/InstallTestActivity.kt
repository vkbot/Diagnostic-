package ru.omoda.autopilot

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * Ищет APK на флешке и внутренней памяти и ставит выбранный через системный PackageInstaller.
 * Копирование в /data/local/tmp и команды pm не используются.
 */
class InstallTestActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var result: TextView

    private val searchRoots = listOf("/storage", "/mnt/media_rw", "/sdcard")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("Установка APK с флешки", 18f))
        root.addView(actionButton("ОБНОВИТЬ СПИСОК") { scan() })
        root.addView(actionButton("РАЗРЕШИТЬ RUSTORE УСТАНОВКУ") { allowRuStore() })
        root.addView(actionButton("АВТО-УСТАНОВКА (ОТКРОЙТЕ RUSTORE)") { autoInstallFromStore() })
        root.addView(actionButton("ЗАПИСЬ ЖУРНАЛА: ВКЛ") { startInstallLog() })
        root.addView(actionButton("ПРОЧИТАТЬ ЖУРНАЛ") { showInstallLog() })
        root.addView(actionButton("СКОПИРОВАТЬ ЖУРНАЛ В ЗАГРУЗКИ") { copyInstallLog() })

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        result = labelView("", 13f, 12)
        root.addView(result)

        scan()
    }

    /** Выставляет RuStore разрешение на установку приложений и сразу проверяет его. */
    private fun allowRuStore() {
        result.text = "Разрешаю установку для RuStore..."
        Thread {
            val out = runShell(
                "cmd appops set ru.vk.store REQUEST_INSTALL_PACKAGES allow; " +
                "cmd appops get ru.vk.store REQUEST_INSTALL_PACKAGES"
            )
            SettingsRepository(applicationContext).addEvent("appops RuStore: $out")
            runOnUiThread { result.text = "RuStore, REQUEST_INSTALL_PACKAGES:\n$out" }
        }.start()
    }

    /**
     * Повторяет вашу ручную последовательность: клавиша 61 (Tab) переводит фокус,
     * клавиша 66 (Enter) нажимает кнопку «Установить». Дамп экрана нужен, чтобы знать,
     * где сейчас фокус. Окон установки может быть несколько, поэтому цикл продолжается,
     * пока кнопка «Установить» появляется на экране.
     */
    private fun autoInstallFromStore() {
        toast("Откройте RuStore на странице калькулятора. Начинаю через 3 секунды")
        Thread {
            Thread.sleep(3000)
            var enters = 0
            var tabs = 0
            var idleRounds = 0
            val started = System.currentTimeMillis()
            while (System.currentTimeMillis() - started < 60000 && idleRounds < 3) {
                val nodes = parseNodes(dumpXml()).filter { it["package"] != packageName }
                val installNodes = nodes.filter {
                    it["text"].orEmpty().trim().equals("Установить", ignoreCase = true)
                }
                if (installNodes.isEmpty()) {
                    idleRounds++
                    showLive("Кнопки «Установить» нет на экране (попытка ${idleRounds}/3). Tab=$tabs, Enter=$enters")
                    Thread.sleep(500)
                    continue
                }
                idleRounds = 0
                val focusedAny = nodes.firstOrNull { it["focused"] == "true" }
                if (focusedAny == null) {
                    showLive("Фокус не виден в дампе, жду. Tab=$tabs, Enter=$enters")
                    Thread.sleep(500)
                    continue
                }
                val focusedInstall = installNodes.firstOrNull { it["focused"] == "true" }
                if (focusedInstall != null && focusedInstall["enabled"] == "true") {
                    runShell("input keyevent 66")
                    enters++
                    showLive("Нажал Enter на «Установить» (#$enters). Жду следующее окно")
                    Thread.sleep(3000)
                } else {
                    runShell("input keyevent 61")
                    tabs++
                    showLive("Tab → фокус на «Установить» ещё не стоит. Tab=$tabs, Enter=$enters")
                    Thread.sleep(800)
                }
            }
            val msg = if (enters == 0 && tabs == 0) {
                "кнопка «Установить» не найдена на экране"
            } else {
                "Готово. Tab=$tabs, Enter=$enters"
            }
            SettingsRepository(applicationContext).addEvent("автоустановка: $msg")
            runOnUiThread { result.text = msg }
        }.start()
    }

    private fun installLogPath(): String = File(filesDir, "install_log.txt").absolutePath

    /** Пишет полный журнал logcat в файл с ротацией, без буфера, чтобы строки не терялись. */
    private fun startInstallLog() {
        val file = installLogPath()
        runShell("logcat -f $file -r 2048 -n 2 -v time >/dev/null 2>&1 &")
        toast("Запись журнала установки включена")
    }

    private fun showInstallLog() {
        val text = runRaw("tail -n 60 ${installLogPath()}")
        result.text = if (text.isBlank()) "журнал пуст" else text.takeLast(2500)
    }

    /** Копирует журнал (обе части после ротации) в Загрузки средствами приложения. */
    private fun copyInstallLog() {
        val current = File(installLogPath())
        val rotated = File(installLogPath() + ".1")
        val dest = File("/sdcard/Download/omoda_install_log.txt")
        if (!current.exists() && !rotated.exists()) {
            result.text = "Файлов журнала нет: ${installLogPath()}\nСначала нажмите «ЗАПИСЬ ЖУРНАЛА: ВКЛ»"
            return
        }
        try {
            dest.outputStream().use { out ->
                for (part in listOf(rotated, current)) {
                    if (part.exists()) part.inputStream().use { it.copyTo(out) }
                }
            }
            result.text = "Журнал скопирован: ${dest.absolutePath}\nразмер ${dest.length() / 1024} КБ"
        } catch (e: Exception) {
            result.text = "Ошибка копирования: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Показывает текущий шаг автоустановки на экране, не дожидаясь конца цикла. */
    private fun showLive(text: String) {
        runOnUiThread { result.text = text }
    }

    /** Снимает дамп экрана в файл и возвращает XML. */
    private fun dumpXml(): String {
        val path = File(filesDir, "ui.xml").absolutePath
        runShell("uiautomator dump $path")
        return try { File(path).readText() } catch (e: Exception) { "" }
    }

    /** Выполняет команду и возвращает весь вывод без обрезки. */
    private fun runRaw(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text
        } catch (e: Exception) {
            ""
        }

    /** Разбирает узлы uiautomator dump: каждый узел — набор атрибутов key="value". */
    private fun parseNodes(xml: String): List<Map<String, String>> =
        Regex("<node [^>]*>").findAll(xml).map { match ->
            Regex("([\\w-]+)=\"([^\"]*)\"").findAll(match.value)
                .associate { it.groupValues[1] to it.groupValues[2] }
        }.toList()

    private fun scan() {
        list.removeAllViews()
        list.addView(labelView("Поиск APK...", 14f))
        Thread {
            val found = mutableListOf<File>()
            for (path in searchRoots) {
                try {
                    File(path).walkTopDown().maxDepth(4)
                        .filter { it.isFile && it.name.lowercase().endsWith(".apk") }
                        .forEach { found.add(it) }
                } catch (e: Exception) {
                    // недоступная папка пропускается
                }
            }
            runOnUiThread { showFiles(found) }
        }.start()
    }

    private fun showFiles(files: List<File>) {
        list.removeAllViews()
        if (files.isEmpty()) {
            list.addView(labelView("APK не найдены в: ${searchRoots.joinToString(", ")}", 14f))
            return
        }
        for (file in files.take(100)) {
            list.addView(actionButton("${file.name}  (${file.length() / 1024} КБ)\n${file.parent}") {
                install(file)
            })
        }
    }

    private fun install(file: File) {
        result.text = "Установка: ${file.name} ..."
        Thread {
            val abi = abiReport(file)
            SettingsRepository(applicationContext).addEvent("проверка ${file.name}: $abi")
            val text = try {
                installViaPmStdin(file)
            } catch (e: Exception) {
                "ошибка: ${e.javaClass.simpleName}: ${e.message}"
            }
            SettingsRepository(applicationContext).addEvent("установка ${file.name}: $text")
            runOnUiThread { result.text = "${file.name}\n$abi\n$text" }
        }.start()
    }

    /** Сравнивает архитектуры процессора ГУ с нативными библиотеками внутри APK. */
    private fun abiReport(file: File): String {
        val device = android.os.Build.SUPPORTED_ABIS.joinToString(",")
        val apkLibs = try {
            java.util.zip.ZipFile(file).use { zip ->
                java.util.Collections.list(zip.entries())
                    .map { it.name }
                    .filter { it.startsWith("lib/") }
                    .mapNotNull { it.split('/').getOrNull(1) }
                    .distinct()
                    .joinToString(",")
            }
        } catch (e: Exception) {
            "ошибка чтения: ${e.javaClass.simpleName}"
        }
        return "ГУ abi=[$device], APK lib=[${apkLibs.ifEmpty { "нет нативных библиотек" }}]"
    }

    /**
     * Передаёт APK в pm install через stdin: pm не открывает путь к файлу сам,
     * поэтому ограничения доступа к каталогам на него не действуют.
     */
    private fun installViaPmStdin(file: File): String {
        val quoted = "'" + file.absolutePath.replace("'", "'\\''") + "'"
        val cmd = "cat $quoted | pm install -r -S ${file.length()}"
        return runShell(cmd)
    }

    private fun runShell(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.trim().ifEmpty { "(пусто)" }.take(1000)
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }
}
