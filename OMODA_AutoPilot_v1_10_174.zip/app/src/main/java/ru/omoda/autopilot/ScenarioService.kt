package ru.omoda.autopilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Профили сценариев. Раз в 30 с читает температуру улицы; каждый включённый профиль срабатывает
 * при переходе условия из ложного в истинное. В скрытом режиме не работает.
 */
class ScenarioService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val wasTrue = HashMap<Long, Boolean>()

    private val tick = object : Runnable {
        override fun run() {
            worker.execute { evaluate() }
            handler.postDelayed(this, PERIOD_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Служба", NotificationManager.IMPORTANCE_MIN))
        }
        val n = Notification.Builder(this)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Служба")
            .setOngoing(true)
        if (Build.VERSION.SDK_INT >= 26) n.setChannelId(CHANNEL)
        startForeground(NOTIF_ID, n.build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (LpLauncher.armed(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val manual = intent?.action == ACTION_APPLY
        if (!manual && Scenarios.all(this).none { it.enabled }) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (manual) {
            val id = intent!!.getLongExtra(EXTRA_ID, -1L)
            worker.execute {
                Scenarios.all(this).filter { it.id == id }.forEach { applyProfile(it) }
            }
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun evaluate() {
        if (LpLauncher.armed(this)) {
            handler.post { stopSelf() }
            return
        }
        val profiles = Scenarios.all(this)
        if (profiles.none { it.enabled }) {
            handler.post { stopSelf() }
            return
        }
        val t = (CarProps.get(OUTSIDE, 0) as? Number)?.toDouble() ?: return
        for (pr in profiles) {
            if (!pr.enabled) {
                wasTrue.remove(pr.id)
                continue
            }
            val cond = if (pr.op == "<") t < pr.threshold else t > pr.threshold
            if (cond && wasTrue[pr.id] != true) applyProfile(pr)
            wasTrue[pr.id] = cond
        }
    }

    /** Выполняет действия профиля и записывает результат в «Последний результат». */
    private fun applyProfile(pr: Scenarios.Profile) {
        val out = StringBuilder(pr.name + ": ")
        fun put(name: String, id: Int, area: Int, v: Any) {
            val err = CarProps.set(id, area, v)
            out.append(name).append(if (err == null) " ок; " else " ($err); ")
        }
        if (pr.seats) {
            put("сиденье водит.", DRV_SEAT, 16, pr.seatLevel)
            put("сиденье пасс.", PASS_SEAT, 64, pr.seatLevel)
        }
        if (pr.hi) {
            put("HI слева", LEFT_TEMP, 0, 30.5f)
            put("HI справа", RIGHT_TEMP, 64, 30.5f)
        }
        if (pr.front) put("лобовое", FRONT_DEFROST, 0, 1)
        if (pr.rear) put("заднее", REAR_DEFROST, 0, 1)
        if (pr.steer) put("руль", STEER_HEAT, 0, 1)
        Scenarios.setLast(this, out.toString())
    }

    companion object {
        const val ACTION_APPLY = "ru.omoda.autopilot.SCENARIO_APPLY"
        const val EXTRA_ID = "profile_id"
        private const val CHANNEL = "scen_min"
        private const val NOTIF_ID = 77
        private const val PERIOD_MS = 30_000L
        private const val OUTSIDE = 33554496
        private const val DRV_SEAT = 33554453
        private const val PASS_SEAT = 33554569
        private const val LEFT_TEMP = 33554551
        private const val RIGHT_TEMP = 33554552
        private const val FRONT_DEFROST = 33554486
        private const val REAR_DEFROST = 33554459
        private const val STEER_HEAT = 50331649
    }
}
