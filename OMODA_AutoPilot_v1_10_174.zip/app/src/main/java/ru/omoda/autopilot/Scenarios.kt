package ru.omoda.autopilot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Профили сценариев климата. Хранятся в SharedPreferences в виде JSON. */
object Scenarios {
    private const val PREF = "scenarios"

    class Profile(
        val id: Long,
        var name: String,
        var enabled: Boolean,
        var op: String,
        var threshold: Int,
        var seats: Boolean,
        var seatLevel: Int,
        var hi: Boolean,
        var front: Boolean,
        var rear: Boolean,
        var steer: Boolean
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("id", id).put("name", name).put("enabled", enabled)
            .put("op", op).put("thr", threshold)
            .put("seats", seats).put("seat", seatLevel)
            .put("hi", hi).put("front", front).put("rear", rear).put("steer", steer)

        companion object {
            fun fromJson(o: JSONObject): Profile = Profile(
                o.getLong("id"), o.getString("name"), o.getBoolean("enabled"),
                o.getString("op"), o.getInt("thr"),
                o.getBoolean("seats"), o.getInt("seat"),
                o.getBoolean("hi"), o.getBoolean("front"), o.getBoolean("rear"), o.getBoolean("steer")
            )
        }
    }

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Profile> {
        val raw = p(c).getString("profiles", null)
        if (raw == null) {
            val d = defaults()
            save(c, d)
            return d.toMutableList()
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }.toMutableList()
    }

    fun save(c: Context, list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        p(c).edit().putString("profiles", arr.toString()).apply()
    }

    fun newId(): Long = System.currentTimeMillis()

    /** Стартовые профили: выключены, пользователь включает сам. Лобовое стекло по умолчанию выключено. */
    private fun defaults(): List<Profile> = listOf(
        Profile(1L, "Холод ниже 10", false, "<", 10, true, 4, true, false, false, false),
        Profile(2L, "Очень холод ниже 2", false, "<", 2, true, 4, true, false, true, false)
    )

    fun last(c: Context): String = p(c).getString("last", "") ?: ""
    fun setLast(c: Context, v: String) = p(c).edit().putString("last", v).apply()
}
