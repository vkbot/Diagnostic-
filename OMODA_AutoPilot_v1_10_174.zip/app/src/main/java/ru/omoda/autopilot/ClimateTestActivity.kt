package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.concurrent.Executors

/** Тестовый климат: непроверенные ID, монитор изменений и поиск ID. Ничего отсюда не переносится в обычный экран без проверки. */
class ClimateTestActivity : Activity() {
    private val apk = "/system/priv-app/CarService/CarService.apk"
    private val loader by lazy { dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader()) }
    private val worker = Executors.newCachedThreadPool()
    private var link: Link? = null
    private var scanView: TextView? = null
    @Volatile private var monitoring = false
    private val monLog = ArrayDeque<String>()
    private val screenLog = ArrayDeque<String>()

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private class Fixed(val label: String, val id: Int, val area: Int, val value: Any)

    private val tests = listOf(
        Fixed("Авто обдув 1 (463)", 33554463, 80, 1),
        Fixed("AUTO ВЫКЛ (435=0, зона 80)", 33554435, 80, 0),
        Fixed("AUTO фронт ВЫКЛ (540=0)", 33554540, 0, 0),
        Fixed("MAX A/C 1 (439)", 33554439, 0, 1),
        Fixed("MAX A/C 0", 33554439, 0, 0),
        Fixed("SWT? 500 =1", 33554500, 0, 1),
        Fixed("SWT? 500 =0", 33554500, 0, 0),
        Fixed("SWT_AUTO? 503 =1", 33554503, 0, 1),
        Fixed("SWT_AUTO? 503 =0", 33554503, 0, 0),
        Fixed("вент пасс 2 (574/64)", 33554574, 64, 2),
        Fixed("вент пасс ВЫКЛ (574=1)", 33554574, 64, 1),
        Fixed("подогрев вод ВЫКЛ (453=1)", 33554453, 16, 1)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Тестовый климат"; textSize = 22f })
        scanView = TextView(this).apply { textSize = 15f; text = "" }
        root.addView(scanView)

        root.addView(button("ТЕСТ: руль, стекло, кондиционер, SYNC (всё в файл)") { runTest() })
        root.addView(button("ПРОВЕРКА значений выключения (2 и 3)") { runOffTest() })
        root.addView(button("МОНИТОР (жмите кнопку на штатной панели)") { toggleMonitor() })
        root.addView(button("Поиск ID руля и ОЖ") { scan() })
        root.addView(button("Вернуть исходное (все тесты)") { restoreAll() })
        root.addView(button("Температуры: снимок ХОЛОДНЫЙ") { snapshot(1) })
        root.addView(button("Температуры: снимок ТЁПЛЫЙ") { snapshot(2) })
        root.addView(button("Температуры: сравнить") { compareSnaps() })
        root.addView(button("Температуры: все сейчас") { showAllTemps() })
        root.addView(button("ЛОБОВОЕ: снимок ВЫКЛ (только чтение)") { snapWindow(1) })
        root.addView(button("ЛОБОВОЕ: снимок ВКЛ (только чтение)") { snapWindow(2) })
        root.addView(button("ЛОБОВОЕ: сравнить снимки") { compareWin() })
        root.addView(button("РЕЕСТР свойств (только чтение, в лог)") { dumpRegistry() })

        tests.chunked(3).forEach { chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in chunk) line.addView(button(t.label) { write(t.id, t.area, t.value) })
            root.addView(line)
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onDestroy() {
        monitoring = false
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            setOnClickListener { onClick() }
        }

    private fun setScan(msg: String) {
        runOnUiThread { scanView?.text = msg }
    }

    /**
     * Запись без автовозврата: читаем исходное значение и статус, запоминаем исходное, пишем новое,
     * читаем обратно. Вернуть можно кнопкой «Вернуть исходное». Прочитанное значение — не доказательство реакции машины.
     */
    private fun write(id: Int, area: Int, v: Any) {
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                val before = l.getProp.invoke(l.prop, id, area)
                if (before == null || (l.getStatus.invoke(before) as Int) != 0) {
                    setScan("Запись отменена: свойство недоступно (id=$id, зона=$area)")
                    return@execute
                }
                val old = l.getValue.invoke(before)
                if (old != null) {
                    synchronized(savedOld) { savedOld.putIfAbsent("$id/$area", Triple(id, area, old)) }
                }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, v))
                Thread.sleep(1500)
                val seen = l.getProp.invoke(l.prop, id, area)?.let { l.getValue.invoke(it) }
                setScan("записано $v (id=$id, зона=$area), прочитано обратно: $seen, исходное: $old")
            } catch (e: Throwable) {
                link = null
                setScan("ошибка записи: ${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}: ${e.cause?.message ?: e.message}")
            }
        }
    }

    /** Выключение во всех зонах, где штатная кнопка меняет значение (по монитору: 1024, 256, 64, 16, 0). */
    /** Проверка значений выключения: ВКЛ, затем значения 2 и 3 по очереди, затем возврат к ВЫКЛ. Всё в лог. */
    private fun runOffTest() {
        val items = listOf(
            Triple("руль", 50331649, Pair(1, 3)),
            Triple("заднее стекло", 33554459, Pair(1, 3)),
            Triple("кондиционер A/C", 33554438, Pair(1, 2)),
            Triple("SYNC", 33554436, Pair(0, 1))
        )
        worker.execute {
            show("=== ПРОВЕРКА значений выключения начата ===")
            for ((name, id, onOff) in items) {
                show("== $name: ВКЛ (${onOff.first})")
                CarProps.writeZones(id, onOff.first) { show(it) }
                for (v in listOf(2, 3)) {
                    show("== $name: пробую значение $v")
                    CarProps.writeZones(id, v) { show(it) }
                }
                show("== $name: возврат ВЫКЛ (${onOff.second})")
                CarProps.writeZones(id, onOff.second) { show(it) }
            }
            show("=== ПРОВЕРКА готова: см. omoda_climate_log.txt ===")
        }
    }

    /** Единый тест: для каждого устройства ВКЛ, затем ВЫКЛ, по всем зонам, всё в лог и на экран. */
    private fun runTest() {
        val items = listOf(
            Triple("руль (50331649)", 50331649, Pair(1, 3)),
            Triple("заднее стекло (33554459)", 33554459, Pair(1, 3)),
            Triple("кондиционер A/C (33554438)", 33554438, Pair(1, 2)),
            Triple("SYNC (33554436)", 33554436, Pair(0, 1))
        )
        worker.execute {
            show("=== ТЕСТ начат ===")
            for ((name, id, onOff) in items) {
                show("== $name: ВКЛ (${onOff.first})")
                CarProps.writeZones(id, onOff.first) { show(it) }
                show("== $name: ВЫКЛ (${onOff.second})")
                CarProps.writeZones(id, onOff.second) { show(it) }
            }
            show("=== ТЕСТ готов: см. omoda_climate_log.txt ===")
        }
    }

    /** Запись во все зоны по очереди с логом (файл и последние строки на экране). */
    private fun allZones(id: Int, value: Int) {
        worker.execute {
            CarProps.writeZones(id, value) { show(it) }
            show("готово: id=$id значение=$value")
        }
    }

    /** Только чтение: снимок всех int-свойств в диапазонах, где могут быть обогревы. Ничего не пишет. */
    private val winSnaps = arrayOfNulls<Map<String, String>>(2)

    private fun readRange(l: Link, onProgress: (String) -> Unit): Map<String, String> {
        val out = HashMap<String, String>()
        // Домены: 1 — зеркала (Cabin), 2 — климат/сиденья (Climate, хвост до 0xFF), 3 — руль, 9 — дворники (VehicleBody), 20 — электродефлекторы
        val ranges = listOf(
            0x02000000..0x020000FF, 0x03000000..0x030000FF, 0x01000000..0x010000FF,
            0x09000000..0x090000FF, 0x14000000..0x140000FF,
            0x13200400..0x132004FF, 0x11400400..0x114004FF
        )
        // Зоны: добавлены 2, 4, 8, 32, 128, 512 (раньше не проверялись)
        val areas = intArrayOf(0, 1, 2, 4, 8, 16, 32, 64, 80, 128, 256, 512, 1024)
        var count = 0
        for (r in ranges) for (id in r) {
            count++
            if (count % 64 == 0) onProgress("читаю: ${count} ID из ${ranges.sumOf { it.count() }}...")
            for (a in areas) {
            try {
                val got = l.getProp.invoke(l.prop, id, a) ?: continue
                if ((l.getStatus.invoke(got) as Int) != 0) continue
                out["$id/$a"] = l.getValue.invoke(got).toString()
            } catch (e: Throwable) {
                // свойство недоступно: пропускаем
            }
            }
        }
        return out
    }

    private fun snapWindow(n: Int) {
        setScan("Снимок $n: читаю диапазоны, подождите...")
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                val m = readRange(l) { msg -> setScan("Снимок $n: $msg") }
                winSnaps[n - 1] = m
                show("ЛОБОВОЕ снимок $n готов: ${m.size} значений")
            } catch (e: Throwable) {
                link = null
                setScan("ошибка снимка: ${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private fun compareWin() {
        val a = winSnaps[0]
        val b = winSnaps[1]
        if (a == null || b == null) { setScan("Сначала сделайте оба снимка"); return }
        val diffs = a.keys.intersect(b.keys).filter { a[it] != b[it] }.sorted()
        if (diffs.isEmpty()) show("ЛОБОВОЕ сравнение: различий нет")
        else show("ЛОБОВОЕ сравнение (id/зона: выкл → вкл):\n" + diffs.joinToString("\n") { "$it: ${a[it]} → ${b[it]}" })
    }

    /** Только чтение: метаданные свойств из статической карты CarPropertyProvider. Ничего не пишет. Не проверено на ГУ. */
    private fun dumpRegistry() {
        setScan("Читаю реестр свойств...")
        worker.execute {
            var count = 0
            try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                val prov = Class.forName("mega.car.config.CarPropertyProvider", true, cl)
                val f = prov.getDeclaredField("CAR_PROPERTY_ANNOTATION_DEFINE").apply { isAccessible = true }
                val sa = f.get(null)
                val cls = sa.javaClass
                val size = cls.getMethod("size").invoke(sa) as Int
                val keyAt = cls.getMethod("keyAt", Int::class.javaPrimitiveType)
                val valueAt = cls.getMethod("valueAt", Int::class.javaPrimitiveType)
                val filter = Regex("Defrost|Defog|Windshield|Windscreen|FWH|Heat|Swt|Mirror|Wiper|Vent", RegexOption.IGNORE_CASE)
                ClimateLog.line("=== РЕЕСТР: всего свойств $size ===")
                for (i in 0 until size) {
                    val id = keyAt.invoke(sa, i) as Int
                    val ann = valueAt.invoke(sa, i)?.toString() ?: continue
                    if (!filter.containsMatchIn(ann)) continue
                    count++
                    ClimateLog.line("${id} 0x${Integer.toHexString(id)} $ann")
                }
                ClimateLog.line("=== РЕЕСТР готов: найдено по фильтру $count, полный текст в файле ===")
                show("РЕЕСТР: найдено по фильтру $count. Смотрите omoda_climate_log.txt")
            } catch (e: Throwable) {
                show("РЕЕСТР ошибка: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private fun show(msg: String) {
        ClimateLog.line(msg)
        val text = synchronized(screenLog) {
            screenLog.addLast(msg)
            while (screenLog.size > 25) screenLog.removeFirst()
            screenLog.joinToString("\n")
        }
        setScan(text)
    }

    /** Возвращает исходные значения всех тестовых записей, которые были сделаны в этом сеансе. */
    private fun restoreAll() {
        worker.execute {
            val items = synchronized(savedOld) { savedOld.values.toList().also { savedOld.clear() } }
            if (items.isEmpty()) {
                setScan("Нечего возвращать")
                return@execute
            }
            val l = try {
                link ?: connect().also { link = it }
            } catch (e: Throwable) {
                setScan("нет связи с машиной: $e")
                return@execute
            }
            val report = StringBuilder()
            for ((id, area, old) in items) {
                try {
                    l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, old))
                    report.append("id=$id зона=$area -> $old: ок\n")
                } catch (e: Throwable) {
                    link = null
                    report.append("id=$id зона=$area: ОШИБКА, верните вручную (было $old)\n")
                }
            }
            setScan(report.toString())
        }
    }

    /** Показывает, какие ID климата меняются при нажатии на штатной панели. */
    private fun toggleMonitor() {
        if (monitoring) {
            monitoring = false
            setScan("Монитор остановлен")
            return
        }
        monitoring = true
        synchronized(monLog) { monLog.clear() }
        setScan("Монитор запущен: нажмите кнопку на штатной панели и ждите строку")
        worker.execute {
            val names = try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val classNames = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.") }
                df.close()
                classNames.filter { !it.contains("fuel", true) && !it.contains("network", true) }.flatMap { cn ->
                    try {
                        Class.forName(cn, false, cl).declaredFields
                            .filter {
                                Modifier.isStatic(it.modifiers) && it.type == Int::class.javaPrimitiveType &&
                                    it.name.startsWith("ID_") && !it.name.contains("FUEL", true) && !it.name.contains("NETWORK", true) && !it.name.contains("EP_MOTOR_SPEED", true)
                            }
                            .map { f -> f.isAccessible = true; "${cn.removePrefix("mega.car.config.")}.${f.name}" to (f.get(null) as Int) }
                    } catch (e: Throwable) {
                        emptyList()
                    }
                }
            } catch (e: Throwable) {
                monitoring = false
                setScan("ошибка списка ID: $e")
                return@execute
            }
            val l = try {
                link ?: connect().also { link = it }
            } catch (e: Throwable) {
                monitoring = false
                setScan("нет связи с машиной: $e")
                return@execute
            }
            val areas = intArrayOf(0, 16, 64, 80, 256, 1024)
            val last = HashMap<String, String>()
            var pass = 0
            while (monitoring) {
                pass++
                if (pass == 2) setScan("Базовый проход готов: можно нажимать штатную кнопку")
                for ((name, id) in names) {
                    for (a in areas) {
                        val cur = try {
                            val got = l.getProp.invoke(l.prop, id, a)
                            if (got == null) "null" else {
                                val st = l.getStatus.invoke(got) as Int
                                if (st != 0) "статус$st" else l.getValue.invoke(got).toString()
                            }
                        } catch (e: Throwable) {
                            "ошибка"
                        }
                        val prev = last["$id/$a"]
                        if (prev != null && prev != cur && cur != "ошибка") {
                            val text = synchronized(monLog) {
                                monLog.addFirst("$name зона=0x${Integer.toHexString(a)}: $prev → $cur")
                                while (monLog.size > 40) monLog.removeLast()
                                monLog.joinToString("\n")
                            }
                            setScan("МОНИТОР (жмите кнопку на штатной панели):\n$text")
                        }
                        last["$id/$a"] = cur
                    }
                }
            }
        }
    }

    /** Исходные значения до тестовых записей: для кнопки «вернуть исходное». Автовозврата нет. */
    private val savedOld = LinkedHashMap<String, Triple<Int, Int, Any>>()
    private var snap1: Map<String, Double>? = null
    private var snap2: Map<String, Double>? = null

    /** Все ID с TEMP в названии из классов mega.car.*, у которых есть численное значение. */
    private fun collectTemps(): Map<String, Double> {
        @Suppress("DEPRECATION")
        val df = dalvik.system.DexFile(apk)
        val classes = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.") }
        df.close()
        val out = LinkedHashMap<String, Double>()
        val areas = intArrayOf(0, 16, 64, 80, 256, 1024)
        for (cn in classes) {
            val fields = try { Class.forName(cn, false, loader).declaredFields } catch (e: Throwable) { continue }
            for (f in fields) {
                if (!Modifier.isStatic(f.modifiers) || f.type != Int::class.javaPrimitiveType) continue
                if (!f.name.startsWith("ID_") || !f.name.contains("TEMP")) continue
                f.isAccessible = true
                val id = f.get(null) as Int
                for (a in areas) {
                    val v = CarProps.get(id, a) as? Number ?: continue
                    out["${cn.removePrefix("mega.car.")}.${f.name}@0x${Integer.toHexString(a)}"] = v.toDouble()
                }
            }
        }
        return out
    }

    private fun snapshot(n: Int) {
        setScan("Снимаю температуры...")
        worker.execute {
            val m = collectTemps()
            if (n == 1) snap1 = m else snap2 = m
            setScan("Снимок $n: ${m.size} значений. " + if (n == 1) "Прогрейте двигатель и сделайте снимок ТЁПЛЫЙ" else "Теперь нажмите «сравнить»")
        }
    }

    private fun compareSnaps() {
        val a = snap1
        val b = snap2
        if (a == null || b == null) {
            setScan("Нужны оба снимка: ХОЛОДНЫЙ и ТЁПЛЫЙ")
            return
        }
        val diffs = a.keys.intersect(b.keys).mapNotNull { k ->
            val d = b[k]!! - a[k]!!
            if (kotlin.math.abs(d) < 0.01) null else Pair(k, d)
        }.sortedByDescending { kotlin.math.abs(it.second) }.take(60)
        setScan(
            if (diffs.isEmpty()) "Изменений нет"
            else "Изменилось (по величине):\n" + diffs.joinToString("\n") { (k, d) ->
                "$k: ${"%.1f".format(a[k])} → ${"%.1f".format(b[k])} (Δ ${"%+.1f".format(d)})"
            }
        )
    }

    private fun showAllTemps() {
        setScan("Считаю...")
        worker.execute {
            val m = collectTemps()
            setScan(if (m.isEmpty()) "Ни одного значения" else m.entries.joinToString("\n") { "${it.key} = ${"%.1f".format(it.value)}" }.take(8000))
        }
    }

    /** Ищет в SDK поля с ключевыми словами руля и охлаждающей жидкости, плюс все enum-ы Climate. */
    private fun scan() {
        setScan("Поиск...")
        worker.execute {
            val found = StringBuilder()
            try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val names = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.") }
                df.close()
                val key = Regex("STEER|STRW|STRG|WHEEL|HANDLE|SWT|HEAT|COOLANT|ENG_TEMP|ENGINE_TEMP|WATER|ECT")
                for (n in names) {
                    val c = try { Class.forName(n, false, cl) } catch (e: Throwable) { continue }
                    val allFields = n.startsWith("mega.car.config.Climate\$")
                    for (f in c.declaredFields) {
                        if (!Modifier.isStatic(f.modifiers) || !(allFields || key.containsMatchIn(f.name))) continue
                        val v = try { f.isAccessible = true; f.get(null).toString() } catch (e: Throwable) { "?" }
                        found.append(n).append('.').append(f.name).append(" = ").append(v).append('\n')
                    }
                }
            } catch (e: Throwable) {
                found.append("ошибка: ").append(e)
            }
            setScan(if (found.isEmpty()) "ничего не найдено" else found.take(8000).toString())
        }
    }

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = loader
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
