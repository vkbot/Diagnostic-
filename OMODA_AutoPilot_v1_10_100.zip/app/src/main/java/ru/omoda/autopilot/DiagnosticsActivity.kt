package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Сбор диагностики моста к машине. Все команды пишутся в один текстовый файл в Загрузках,
 * его потом отдают для разбора. Ничего не меняет на системе: только чтение.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Диагностика моста"; textSize = 18f })
        root.addView(Button(this).apply {
            text = "СОБРАТЬ ДИАГНОСТИКУ"
            setOnClickListener { collect() }
        })
        info = TextView(this).apply {
            textSize = 14f
            text = "Нажмите кнопку. Файл появится в /sdcard/Download/ (около минуты)."
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun collect() {
        info.text = "Сбор... подождите"
        Thread {
            val file = File("/sdcard/Download/omoda_diag_${System.currentTimeMillis() / 1000}.txt")
            val sb = StringBuilder()
            for ((title, cmd) in COMMANDS) {
                sb.append("\n===== ").append(title).append(" =====\n$ ").append(cmd).append('\n')
                sb.append(run(cmd)).append('\n')
            }
            sb.append("\n===== вендорский binder mega.car =====\n").append(vendorProbe()).append('\n')
            val result = try {
                file.writeText(sb.toString())
                "Готово: ${file.absolutePath}, ${file.length() / 1024} КБ"
            } catch (e: Exception) {
                "Ошибка записи: ${e.message}"
            }
            runOnUiThread { info.text = result }
        }.start()
    }

    /**
     * Пробник вендорского binder mega.car.ICar. Только читает: имена классов, есть ли сервис,
     * его дескриптор и список методов интерфейса. Ни один метод не вызывается.
     */
    private fun vendorProbe(): String {
        val sb = StringBuilder()
        for (n in listOf("mega.car.ICar", "mega.car.ICar\$Stub")) {
            sb.append(n).append(": ")
              .append(try { Class.forName(n); "есть" } catch (e: Throwable) { "нет" }).append('\n')
        }
        try {
            val b = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java)
                .invoke(null, "com.mega.car.CarService") as? android.os.IBinder
            sb.append("binder: ").append(b != null).append('\n')
            if (b != null) {
                sb.append("descriptor: ").append(try { b.interfaceDescriptor } catch (e: Throwable) { "?" }).append('\n')
                val iface = Class.forName("mega.car.ICar\$Stub")
                    .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, b)
                iface.javaClass.methods.forEach { m ->
                    sb.append("  ").append(m.name).append('(')
                      .append(m.parameterTypes.joinToString { it.simpleName }).append(")\n")
                }
            }
        } catch (e: Throwable) {
            sb.append("err: ").append(e).append('\n')
        }
        return sb.toString()
    }

    private fun run(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        var out = ""
        val reader = Thread { out = p.inputStream.bufferedReader().readText() }
        reader.start()
        reader.join(TIMEOUT_S * 1000)
        if (reader.isAlive) {
            p.destroy()
            out.take(MAX_OUT) + "\n(таймаут)"
        } else {
            p.waitFor(1, TimeUnit.SECONDS)
            out.take(MAX_OUT)
        }
    } catch (e: Exception) {
        "ошибка: ${e.message}"
    }

    companion object {
        private const val TIMEOUT_S = 25L
        private const val MAX_OUT = 300_000

        private val COMMANDS = listOf(
            "свойства" to "getprop | grep -E 'ro.product|ro.build|ro.hardware|ro.board|mega|vehicle|automotive'",
            "service list" to "service list",
            "lshal" to "lshal 2>&1 | head -400",
            "vintf манифесты" to "for f in /vendor/etc/vintf/manifest*.xml /vendor/manifest.xml /system/etc/vintf/manifest*.xml; do echo \"--- \$f\"; cat \"\$f\" 2>/dev/null; done",
            "vintf каталоги" to "ls -la /vendor/etc/vintf /system/etc/vintf 2>&1",
            "файлы mega" to "find /vendor /system /odm -iname '*mega*' 2>/dev/null | head -300",
            "процессы" to "ps -A | grep -i -E 'mega|vehicle|car'",
            "/dev" to "ls -la /dev | head -200",
            "BOOTCLASSPATH" to "echo \$BOOTCLASSPATH; echo \$SYSTEMSERVERCLASSPATH",
            "jar с mega.car" to "grep -rl -a 'mega/car/' /system/framework /vendor/framework /system_ext/framework /product/framework /system/priv-app /vendor/priv-app /system_ext/priv-app /vendor/app /system/app 2>/dev/null | head -100",
            "jar с message_center" to "grep -rl -a -E 'message_center|MessageCenter' /system/framework /vendor/framework /system_ext/framework /product/framework /system/priv-app /vendor/priv-app /system_ext/priv-app /vendor/app /system/app 2>/dev/null | head -100",
            "init message_center" to "cat /vendor/etc/init/vendor.mega.message_center@1.0-service.rc 2>&1",
            "init tboxprotocol" to "cat /vendor/etc/init/vendor.mega.tboxprotocol@1.0-service.rc 2>&1",
            "процессы tbox/message" to "ps -A | grep -i -E 'tbox|message|mega'",
            "журнал HAL" to "logcat -d -t 3000 2>&1 | grep -i -E 'mega|message_center|IVehicle|VehicleHal|libvintf|hwservice' | tail -400"
        )
    }
}
