package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.concurrent.Executors

/** Тестовый климат: непроверенные ID, монитор изменений и поиск ID. Ничего отсюда не переносится в обычный экран без проверки. */
class ClimateTestActivity : Activity() {
    private val apk = "/system/priv-app/CarService/CarService.apk"
    private val worker = Executors.newSingleThreadExecutor()
    private var link: Link? = null
    private var scanView: TextView? = null
    @Volatile private var monitoring = false
    private val monLog = ArrayDeque<String>()

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    private class Fixed(val label: String, val id: Int, val area: Int, val value: Any)

    private val tests = listOf(
        Fixed("Авто обдув 1 (463)", 33554463, 80, 1),
        Fixed("SYNC зона 16 =1 (436)", 33554436, 16, 1),
        Fixed("SYNC зона 16 =0", 33554436, 16, 0),
        Fixed("SYNC зона 64 =1", 33554436, 64, 1),
        Fixed("SYNC зона 64 =0", 33554436, 64, 0),
        Fixed("A/C зона 16 =1 (438)", 33554438, 16, 1),
        Fixed("A/C зона 16 =0", 33554438, 16, 0),
        Fixed("A/C зона 64 =1", 33554438, 64, 1),
        Fixed("A/C зона 64 =0", 33554438, 64, 0),
        Fixed("A/C режим 1 (438)", 33554438, 0, 1),
        Fixed("A/C режим 0", 33554438, 0, 0),
        Fixed("MAX A/C 1 (439)", 33554439, 0, 1),
        Fixed("MAX A/C 0", 33554439, 0, 0),
        Fixed("A/C запрос 1 (498)", 33554498, 0, 1),
        Fixed("A/C запрос 0", 33554498, 0, 0),
        Fixed("A/C зона 1 (549)", 33554549, 0, 1),
        Fixed("A/C зона 0", 33554549, 0, 0),
        Fixed("SWT? 500 =1", 33554500, 0, 1),
        Fixed("SWT? 500 =0", 33554500, 0, 0),
        Fixed("SWT_AUTO? 503 =1", 33554503, 0, 1),
        Fixed("SWT_AUTO? 503 =0", 33554503, 0, 0),
        Fixed("зерк лев 1 (578)", 33554578, 0, 1),
        Fixed("зерк лев 0", 33554578, 0, 0),
        Fixed("зерк прав 1 (579)", 33554579, 0, 1),
        Fixed("зерк прав 0", 33554579, 0, 0),
        Fixed("вент пасс 2 (574/64)", 33554574, 64, 2),
        Fixed("вент пасс 0", 33554574, 64, 0),
        Fixed("вент 573 вод 2", 33554573, 16, 2)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Тестовый климат"; textSize = 22f })
        scanView = TextView(this).apply { textSize = 15f; text = "" }
        root.addView(scanView)

        root.addView(button("МОНИТОР (жмите кнопку на штатной панели)") { toggleMonitor() })
        root.addView(button("Поиск ID руля и ОЖ") { scan() })

        tests.chunked(3).forEach { chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in chunk) line.addView(button(t.label) { write(t.id, t.area, t.value) })
            root.addView(line)
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onDestroy() {
        monitoring = false
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 16f
            setOnClickListener { onClick() }
        }

    private fun setScan(msg: String) {
        runOnUiThread { scanView?.text = msg }
    }

    private fun write(id: Int, area: Int, v: Any) {
        worker.execute {
            try {
                val l = link ?: connect().also { link = it }
                l.setProp.invoke(l.prop, l.cpvCtor.newInstance(id, area, v))
            } catch (e: Throwable) {
                link = null
                setScan("ошибка записи: ${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}: ${e.cause?.message ?: e.message}")
            }
        }
    }

    /** Показывает, какие ID климата меняются при нажатии на штатной панели. */
    private fun toggleMonitor() {
        if (monitoring) {
            monitoring = false
            setScan("Монитор остановлен")
            return
        }
        monitoring = true
        synchronized(monLog) { monLog.clear() }
        setScan("Монитор запущен: нажмите кнопку на штатной панели и ждите строку")
        worker.execute {
            val names = try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val classNames = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.config.") }
                df.close()
                classNames.flatMap { cn ->
                    try {
                        Class.forName(cn, false, cl).declaredFields
                            .filter { Modifier.isStatic(it.modifiers) && it.type == Int::class.javaPrimitiveType && it.name.startsWith("ID_") }
                            .map { f -> f.isAccessible = true; "${cn.removePrefix("mega.car.config.")}.${f.name}" to (f.get(null) as Int) }
                    } catch (e: Throwable) {
                        emptyList()
                    }
                }
            } catch (e: Throwable) {
                monitoring = false
                setScan("ошибка списка ID: $e")
                return@execute
            }
            val l = try {
                link ?: connect().also { link = it }
            } catch (e: Throwable) {
                monitoring = false
                setScan("нет связи с машиной: $e")
                return@execute
            }
            val areas = intArrayOf(0, 16, 64, 80, 256, 1024)
            val last = HashMap<String, String>()
            while (monitoring) {
                for ((name, id) in names) {
                    for (a in areas) {
                        val cur = try {
                            val got = l.getProp.invoke(l.prop, id, a)
                            if (got == null) "null" else {
                                val st = l.getStatus.invoke(got) as Int
                                if (st != 0) "статус$st" else l.getValue.invoke(got).toString()
                            }
                        } catch (e: Throwable) {
                            "ошибка"
                        }
                        val prev = last["$id/$a"]
                        if (prev != null && prev != cur && cur != "ошибка") {
                            val text = synchronized(monLog) {
                                monLog.addFirst("$name зона=0x${Integer.toHexString(a)}: $prev → $cur")
                                while (monLog.size > 40) monLog.removeLast()
                                monLog.joinToString("\n")
                            }
                            setScan("МОНИТОР (жмите кнопку на штатной панели):\n$text")
                        }
                        last["$id/$a"] = cur
                    }
                }
            }
        }
    }

    /** Ищет в SDK поля с ключевыми словами руля и охлаждающей жидкости, плюс все enum-ы Climate. */
    private fun scan() {
        setScan("Поиск...")
        worker.execute {
            val found = StringBuilder()
            try {
                val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
                @Suppress("DEPRECATION")
                val df = dalvik.system.DexFile(apk)
                val names = java.util.Collections.list(df.entries()).filter { it.startsWith("mega.car.") }
                df.close()
                val key = Regex("STEER|STRW|STRG|WHEEL|HANDLE|SWT|HEAT|COOLANT|ENG_TEMP|ENGINE_TEMP|WATER|ECT")
                for (n in names) {
                    val c = try { Class.forName(n, false, cl) } catch (e: Throwable) { continue }
                    val allFields = n.startsWith("mega.car.config.Climate\$")
                    for (f in c.declaredFields) {
                        if (!Modifier.isStatic(f.modifiers) || !(allFields || key.containsMatchIn(f.name))) continue
                        val v = try { f.isAccessible = true; f.get(null).toString() } catch (e: Throwable) { "?" }
                        found.append(n).append('.').append(f.name).append(" = ").append(v).append('\n')
                    }
                }
            } catch (e: Throwable) {
                found.append("ошибка: ").append(e)
            }
            setScan(if (found.isEmpty()) "ничего не найдено" else found.take(8000).toString())
        }
    }

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }
}
