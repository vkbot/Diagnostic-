package ru.omoda.autopilot

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Возврат иконки без adb: невидимый квадрат в правом верхнем углу.
 * 5 нажатий подряд в течение 1,5 с возвращают иконку помощника в лаунчер.
 * Работает только при разрешённом «поверх других окон», иначе скрывать нельзя.
 */
object LpSquare {
    private const val PREFS = "lp"
    private const val KEY = "hidden"
    private const val ICON = "ru.omoda.autopilot.LpIcon"

    private var view: View? = null
    private var wm: WindowManager? = null
    private var count = 0
    private var lastTap = 0L

    fun isHidden(c: Context): Boolean =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun canOverlay(c: Context): Boolean = Settings.canDrawOverlays(c)

    /** Скрывает иконку. Возвращает текст для пользователя. */
    fun hide(c: Context): String {
        if (!canOverlay(c)) return "Сначала разрешите «поверх других окон» для Помощника и нажмите ещё раз"
        setIcon(c, false)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()
        show(c)
        LpGuardService.start(c)
        return "Иконка скрыта. Чтобы вернуть: 5 нажатий подряд в правом верхнем углу экрана"
    }

    fun restore(c: Context) {
        remove()
        setIcon(c, true)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, false).apply()
        c.stopService(android.content.Intent(c, LpGuardService::class.java))
    }

    /** Создаёт квадрат, если иконка скрыта. Вызывается при запуске помощника. */
    fun show(c: Context) {
        if (view != null || !canOverlay(c)) return
        val manager = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = c.dp(72)
        val v = View(c)
        v.setBackgroundColor(0x01000000) // почти прозрачный, но принимает касания
        v.setOnClickListener { tap(c) }
        val lp = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        try {
            manager.addView(v, lp)
            view = v
            wm = manager
        } catch (e: Exception) {
            view = null
        }
    }

    private fun remove() {
        val v = view ?: return
        try {
            wm?.removeViewImmediate(v)
        } catch (e: Exception) {
            // окно уже снято системой
        }
        view = null
        wm = null
    }

    private fun tap(c: Context) {
        val now = SystemClock.elapsedRealtime()
        count = if (now - lastTap > 1500) 1 else count + 1
        lastTap = now
        if (count >= 5) {
            count = 0
            restore(c)
            Toast.makeText(c, "Иконка помощника возвращена", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setIcon(c: Context, on: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            ComponentName(c, ICON),
            if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
