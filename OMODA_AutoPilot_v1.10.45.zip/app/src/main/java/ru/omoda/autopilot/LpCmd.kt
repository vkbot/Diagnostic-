package ru.omoda.autopilot

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Возвращает иконку помощника: adb shell am broadcast -a ru.omoda.lp.RESTORE */
class LpCmd : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != "ru.omoda.lp.RESTORE") return
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context, "ru.omoda.autopilot.LpIcon"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        SettingsRepository(context.applicationContext).addEvent("иконка помощника возвращена")
    }
}
