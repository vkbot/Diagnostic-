package ru.omoda.autopilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * Держит невидимый квадрат возврата, пока иконка помощника скрыта.
 * Запускается при скрытии и при загрузке (BootReceiver). Останавливается сам, когда иконка возвращена.
 */
class LpGuardService : Service() {

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "Служба помощника", NotificationManager.IMPORTANCE_MIN))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!LpSquare.isHidden(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Служба помощника")
            .setOngoing(true)
        // Обязательно при запуске в переднем плане на Android 8+
        startForeground(NOTIF_ID, builder.build())
        LpSquare.show(this)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "lp_guard"
        const val NOTIF_ID = 77

        /** Запускает службу-хранитель квадрата (только если иконка скрыта). */
        fun start(ctx: android.content.Context) {
            val intent = Intent(ctx, LpGuardService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(intent) else ctx.startService(intent)
        }
    }
}
