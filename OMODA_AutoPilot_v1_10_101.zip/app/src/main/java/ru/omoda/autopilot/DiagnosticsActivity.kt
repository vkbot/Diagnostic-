package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/**
 * Сбор диагностики моста к машине. Пишет в файл по мере сбора, поэтому частичный результат
 * сохраняется даже при обрыве. Любая ошибка попадает в файл вместе с трассировкой.
 * Только чтение: ничего на системе не меняет.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Диагностика моста"; textSize = 18f })
        root.addView(Button(this).apply {
            text = "СОБРАТЬ ДИАГНОСТИКУ"
            setOnClickListener { collect() }
        })
        info = TextView(this).apply {
            textSize = 14f
            text = "Нажмите кнопку. Файл появится в /sdcard/Download/ (около минуты)."
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun collect() {
        setInfo("Сбор... подождите")
        Thread {
            val file = File("/sdcard/Download/omoda_diag_${System.currentTimeMillis() / 1000}.txt")
            val total = COMMANDS.size + 1
            appendSafe(file, "=== omoda diag 1.10.101 ===\n")
            try {
                COMMANDS.forEachIndexed { i, (title, cmd) ->
                    setInfo("Шаг ${i + 1} из $total: $title")
                    appendSafe(file, "\n===== $title =====\n$ $cmd\n" + run(cmd) + "\n")
                }
                setInfo("Шаг $total из $total: вендорский binder")
                appendSafe(file, "\n===== вендорский binder mega.car =====\n" + safe { vendorProbe() } + "\n")
                setInfo("Готово: ${file.absolutePath}, ${file.length() / 1024} КБ")
            } catch (e: Throwable) {
                appendSafe(file, "\n!!! СБОР ПРЕРВАН: $e\n" + e.stackTraceToString())
                setInfo("Сбор прерван: $e. Подробности в файле.")
            }
        }.start()
    }

    private fun setInfo(msg: String) {
        runOnUiThread { if (!isDestroyed) info.text = msg }
    }

    private fun appendSafe(file: File, text: String) {
        try {
            file.appendText(text)
        } catch (e: Throwable) {
            // запись не удалась: сбор продолжаем, сообщение уйдёт в экран
        }
    }

    private fun safe(block: () -> String): String = try {
        block()
    } catch (e: Throwable) {
        "ошибка: $e\n" + e.stackTraceToString()
    }

    /** Пробник вендорского binder mega.car.ICar. Только читает, ни один метод не вызывает. */
    private fun vendorProbe(): String {
        val sb = StringBuilder()
        for (n in listOf("mega.car.ICar", "mega.car.ICar\$Stub")) {
            sb.append(n).append(": ")
                .append(try { Class.forName(n); "есть" } catch (e: Throwable) { "нет" }).append('\n')
        }
        try {
            val b = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java)
                .invoke(null, "com.mega.car.CarService") as? android.os.IBinder
            sb.append("binder: ").append(b != null).append('\n')
            if (b != null) {
                sb.append("descriptor: ").append(try { b.interfaceDescriptor } catch (e: Throwable) { "?" }).append('\n')
                val iface = Class.forName("mega.car.ICar\$Stub")
                    .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, b)
                iface.javaClass.methods.forEach { m ->
                    sb.append("  ").append(m.name).append('(')
                        .append(m.parameterTypes.joinToString { it.simpleName }).append(")\n")
                }
            }
        } catch (e: Throwable) {
            sb.append("err: ").append(e).append('\n')
        }
        return sb.toString()
    }

    /** Выполняет команду с таймаутом. Ошибки возвращаются текстом, исключений наружу не выходит. */
    private fun run(cmd: String): String {
        val holder = AtomicReference("")
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val reader = Thread {
                try {
                    holder.set(p.inputStream.bufferedReader().readText())
                } catch (e: Throwable) {
                    holder.set("ошибка чтения: $e")
                }
            }
            reader.isDaemon = true
            reader.start()
            reader.join(TIMEOUT_S * 1000)
            if (reader.isAlive) {
                p.destroy()
                holder.get().take(MAX_OUT) + "\n(таймаут ${TIMEOUT_S} с)"
            } else {
                holder.get().take(MAX_OUT)
            }
        } catch (e: Throwable) {
            "ошибка запуска: $e"
        }
    }

    companion object {
        private const val TIMEOUT_S = 15L
        private const val MAX_OUT = 200_000

        private val COMMANDS = listOf(
            "свойства" to "getprop | grep -E 'ro.product|ro.build|ro.hardware|ro.board|mega|vehicle|automotive'",
            "service list" to "service list",
            "lshal" to "lshal 2>&1 | head -400",
            "vintf манифесты" to "for f in /vendor/etc/vintf/manifest*.xml /vendor/manifest.xml /system/etc/vintf/manifest*.xml; do echo \"--- \$f\"; cat \"\$f\" 2>/dev/null; done",
            "vintf каталоги" to "ls -la /vendor/etc/vintf /system/etc/vintf 2>&1",
            "файлы mega" to "find /vendor /system /odm -iname '*mega*' 2>/dev/null | head -300",
            "процессы" to "ps -A | grep -i -E 'mega|vehicle|car'",
            "/dev" to "ls -la /dev 2>&1 | head -200",
            "BOOTCLASSPATH" to "echo \$BOOTCLASSPATH; echo \$SYSTEMSERVERCLASSPATH",
            "jar с mega.car" to "grep -rl -a 'mega/car/' /system/framework /vendor/framework /system_ext/framework /product/framework /system/priv-app /vendor/priv-app /system_ext/priv-app 2>/dev/null | head -100",
            "jar с message_center" to "grep -rl -a -E 'message_center|MessageCenter' /system/framework /vendor/framework /system_ext/framework /product/framework /system/priv-app /vendor/priv-app /system_ext/priv-app 2>/dev/null | head -100",
            "init message_center" to "cat /vendor/etc/init/vendor.mega.message_center@1.0-service.rc 2>&1",
            "init tboxprotocol" to "cat /vendor/etc/init/vendor.mega.tboxprotocol@1.0-service.rc 2>&1",
            "процессы tbox/message" to "ps -A | grep -i -E 'tbox|message|mega'",
            "журнал HAL" to "logcat -d -t 3000 2>&1 | grep -i -E 'mega|message_center|IVehicle|VehicleHal|libvintf|hwservice' | tail -400"
        )
    }
}
