package ru.omoda.autopilot

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller

/** Получает результат установки от системного PackageInstaller и пишет его в журнал. */
class InstallResultReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(confirm)
            }
            SettingsRepository(context).addEvent("установка: требуется подтверждение на экране")
            return
        }
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        SettingsRepository(context).addEvent("установка: статус=$status $message")
        if (status != PackageInstaller.STATUS_SUCCESS) {
            Thread {
                val log = readInstallLog()
                SettingsRepository(context).addEvent("журнал установки: $log")
            }.start()
        }
    }

    /** Строки журнала, где могут быть причины отказа: установка, PackageManager, белый список. */
    private fun readInstallLog(): String =
        try {
            Thread.sleep(2000)
            val process = ProcessBuilder(
                "sh", "-c",
                "logcat -d -t 3000 | grep -iE 'packageinstaller|packagemanager|installinstalling|pmservice|whitelist|white list|allowlist|INSTALL_FAILED|blocked|denied' | grep -v InstallTestActivity | grep -v ru.omoda | tail -n 40"
            ).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.trim().replace("\n", " | ").ifEmpty { "(пусто)" }.take(1500)
        } catch (e: Exception) {
            "ошибка чтения журнала: ${e.javaClass.simpleName}"
        }
}
