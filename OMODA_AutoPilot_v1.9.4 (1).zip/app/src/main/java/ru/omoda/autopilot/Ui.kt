package ru.omoda.autopilot

import android.content.Context
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

fun Context.labelView(value: String, size: Float = 15f, topPadDp: Int = 0): TextView {
    val view = TextView(this)
    view.text = value
    view.textSize = size
    view.setPadding(0, dp(topPadDp), 0, 0)
    return view
}

fun Context.actionButton(caption: String, onClick: () -> Unit): Button {
    val button = Button(this)
    button.text = caption
    button.setOnClickListener { onClick() }
    return button
}

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
