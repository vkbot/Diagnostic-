package ru.omoda.autopilot

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class DiagnosticsActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var outputScroll: ScrollView
    private val lock = Any()
    private val log = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(8), dp(8), dp(8), dp(8))
        setContentView(root)

        root.addView(labelView("Диагностика: ${DiagnosticCommands.ALL.size} команд", 17f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(actionButton("ВЫПОЛНИТЬ ВСЕ") { runAll() }, weightParams())
        row.addView(actionButton("ОЧИСТИТЬ") { clearLog() }, weightParams())
        root.addView(row)

        output = TextView(this)
        output.typeface = Typeface.MONOSPACE
        output.textSize = 11f
        outputScroll = ScrollView(this)
        outputScroll.addView(output)
        root.addView(outputScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))

        val listScroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        var group = ""
        for (item in DiagnosticCommands.ALL) {
            if (item.group != group) {
                group = item.group
                list.addView(labelView(group, 15f, 12))
            }
            list.addView(actionButton(item.title) { runOne(item) })
        }
        listScroll.addView(list)
        root.addView(listScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    private fun runOne(item: DiagnosticCommand) {
        Thread { appendResult(item, runCommand(item.command), "") }.start()
    }

    private fun runAll() {
        val items = DiagnosticCommands.ALL
        Thread {
            items.forEachIndexed { index, item ->
                appendResult(item, runCommand(item.command), "${index + 1}/${items.size} ")
            }
            appendText("=== Готово ===")
        }.start()
    }

    private fun appendResult(item: DiagnosticCommand, result: String, counter: String) {
        appendText("### $counter${item.title}\n\$ ${item.command}\n$result")
    }

    private fun appendText(text: String) {
        val snapshot = synchronized(lock) {
            log.append(text).append("\n\n")
            if (log.length > MAX_CHARS) log.delete(0, log.length - MAX_CHARS)
            log.toString()
        }
        runOnUiThread {
            output.text = snapshot
            outputScroll.post { outputScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun clearLog() {
        synchronized(lock) { log.setLength(0) }
        output.text = ""
    }

    /** Выполняет одну команду в shell. Если команда зависла, она убивается через 8 секунд. */
    private fun runCommand(command: String): String =
        try {
            val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val watchdog = Thread {
                try {
                    Thread.sleep(8000)
                    process.destroy()
                } catch (e: InterruptedException) {
                    // команда завершилась раньше таймаута
                }
            }
            watchdog.isDaemon = true
            watchdog.start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            watchdog.interrupt()
            text.trim().ifEmpty { "(пусто)" }.take(2000)
        } catch (e: Exception) {
            "ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }

    private companion object {
        const val MAX_CHARS = 60000
    }
}
