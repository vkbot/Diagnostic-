package ru.omoda.autopilot

import android.content.Context
import android.content.pm.PackageManager
import java.security.MessageDigest

object SystemSignature {
    /** SHA-256 сертификата platform_x509.pem (публичный тестовый ключ AOSP). */
    const val OUR_KEY_FINGERPRINT =
        "C8:A2:E9:BC:CF:59:7C:2F:B6:DC:66:BE:E2:93:FC:13:F2:FC:47:EC:77:BC:6B:2B:0D:52:C1:1F:51:19:2A:B8"

    /** Отпечаток подписи пакета в формате SHA-256 с двоеточиями, либо null при ошибке. */
    fun fingerprintOf(context: Context, packageName: String): String? {
        return try {
            @Suppress("DEPRECATION")
            val info = context.packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            val signature = info.signatures?.firstOrNull() ?: return null
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
                .joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Строка для экрана: совпадает ли подпись системы с нашим ключом. */
    fun statusLine(context: Context): String {
        val system = fingerprintOf(context, "android")
            ?: return "Подпись системы: не удалось прочитать"
        return if (system.equals(OUR_KEY_FINGERPRINT, ignoreCase = true)) {
            "Подпись системы СОВПАДАЕТ с нашим ключом."
        } else {
            "Подпись системы НЕ совпадает с нашим ключом.\nSHA-256 системы: $system"
        }
    }
}
