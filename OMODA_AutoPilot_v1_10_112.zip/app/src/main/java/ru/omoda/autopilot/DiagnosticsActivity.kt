package ru.omoda.autopilot

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.lang.reflect.Constructor
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicReference

/**
 * Тест климата: чтение и шаги с изменением и откатом. Всё возвращается к исходным значениям.
 * Экран подсказывает, на что смотреть в каждый момент.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var info: TextView
    private val apk = "/system/priv-app/CarService/CarService.apk"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "Тест климата"; textSize = 20f })
        root.addView(TextView(this).apply {
            textSize = 15f
            text = "Перед запуском:\n" +
                "1. Зажигание ON.\n" +
                "2. Смотрите на экран климата и на сиденья.\n\n" +
                "Что будет:\n" +
                "• Температура слева +0,5 °C, держится 3 с, затем откат.\n" +
                "• Обдув переднего ряда +1 уровень, держится 3 с, затем откат.\n" +
                "• Подогрев сиденья переднего левого: только если датчик отдаёт статус 0, иначе пропуск.\n\n" +
                "Каждый шаг написан на экране ниже. Всё возвращается к исходным значениям."
        })
        root.addView(Button(this).apply {
            text = "ЗАПУСТИТЬ ТЕСТ"
            setOnClickListener { collect() }
        })
        info = TextView(this).apply {
            textSize = 16f
            text = "Нажмите кнопку, когда будете готовы."
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun collect() {
        setInfo("Старт. Смотрите на экран климата.")
        Thread {
            val file = File("/sdcard/Download/omoda_climate_${System.currentTimeMillis() / 1000}.txt")
            appendSafe(file, "=== omoda climate test 1.10.111 ===\n")
            try {
                setInfo("Проверка связи с CarService...")
                appendSafe(file, "\n===== служба =====\n" + run("service list | grep -i car") + "\n")
                appendSafe(file, "\n===== чтение =====\n" + safe { liveReadProbe() } + "\n")
                appendSafe(file, "\n===== шаги =====\n" + safe { stepProbe() } + "\n")
                setInfo("Готово. Файл: ${file.absolutePath}. Пришлите его мне.")
            } catch (e: Throwable) {
                appendSafe(file, "\n!!! СБОР ПРЕРВАН: $e\n" + e.stackTraceToString())
                setInfo("Прервано: $e. Файл: ${file.absolutePath}")
            }
        }.start()
    }

    private fun setInfo(msg: String) {
        runOnUiThread { if (!isDestroyed) info.text = msg }
    }

    private fun appendSafe(file: File, text: String) {
        try {
            file.appendText(text)
        } catch (e: Throwable) {
            // запись не удалась: тест идёт дальше, сообщение уходит на экран
        }
    }

    private fun safe(block: () -> String): String = try {
        block()
    } catch (e: Throwable) {
        "ошибка: $e\n" + e.stackTraceToString()
    }

    /** Выполняет команду с таймаутом, исключений наружу не выходит. */
    private fun run(cmd: String): String {
        val holder = AtomicReference("")
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val reader = Thread {
                try {
                    holder.set(p.inputStream.bufferedReader().readText())
                } catch (e: Throwable) {
                    holder.set("ошибка чтения: $e")
                }
            }
            reader.isDaemon = true
            reader.start()
            reader.join(15_000)
            if (reader.isAlive) {
                p.destroy()
                holder.get().take(20_000) + "\n(таймаут)"
            } else {
                holder.get().take(20_000)
            }
        } catch (e: Throwable) {
            "ошибка запуска: $e"
        }
    }

    private class Link(
        val prop: Any,
        val getProp: Method,
        val setProp: Method,
        val cpvCtor: Constructor<*>,
        val getValue: Method,
        val getStatus: Method
    )

    /** ServiceManager → mega.car.CarService (ICar) → getCarService(PROPERTY_SERVICE) → ICarProperty. */
    private fun connect(): Link {
        val cl = dalvik.system.PathClassLoader(apk, ClassLoader.getSystemClassLoader())
        val mega = Class.forName("mega.car.MegaCar", true, cl)
        fun constStr(name: String): String =
            mega.getDeclaredField(name).also { it.isAccessible = true }.get(null).toString()
        val svc = constStr("CAR_SERVICE_BINDER_SERVICE_NAME")
        val propSvc = constStr("PROPERTY_SERVICE")
        val carBinder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, svc) as android.os.IBinder
        val iCar = Class.forName("mega.car.ICar\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, carBinder)
        val propBinder = Class.forName("mega.car.ICar", true, cl)
            .getMethod("getCarService", String::class.java).invoke(iCar, propSvc) as android.os.IBinder
        val iProp = Class.forName("mega.car.hardware.property.ICarProperty", true, cl)
        val prop = Class.forName("mega.car.hardware.property.ICarProperty\$Stub", true, cl)
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, propBinder)!!
        val cpv = Class.forName("mega.car.hardware.CarPropertyValue", true, cl)
        return Link(
            prop = prop,
            getProp = iProp.getMethod("getProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType),
            setProp = iProp.getMethod("setProperty", cpv),
            cpvCtor = cpv.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Any::class.java),
            getValue = cpv.getMethod("getValue"),
            getStatus = cpv.getMethod("getStatus")
        )
    }

    /** Только чтение ключевых значений. */
    private fun liveReadProbe(): String {
        val sb = StringBuilder()
        try {
            val l = connect()
            val ids = listOf(
                Triple(33554551, 0, "температура слева"),
                Triple(33554552, 0, "температура справа"),
                Triple(33554497, 0, "температура салона"),
                Triple(33554496, 0, "температура улицы"),
                Triple(33554448, 80, "обдув переднего ряда"),
                Triple(33554453, 16, "подогрев сиденья переднего левого")
            )
            for ((id, area, name) in ids) {
                val r = try {
                    l.getProp.invoke(l.prop, id, area)?.toString() ?: "null"
                } catch (e: Throwable) {
                    "err: ${e.cause ?: e}"
                }
                sb.append(name).append(" id=").append(id).append(" area=").append(area)
                    .append(" -> ").append(r.take(300)).append('\n')
            }
        } catch (e: Throwable) {
            sb.append("err: ").append(e).append('\n')
        }
        return sb.toString()
    }

    private class StepSpec(
        val name: String,
        val id: Int,
        val area: Int,
        val delta: Double,
        val min: Double,
        val max: Double
    )

    /** Шаги с изменением и откатом. Экран показывает, что сейчас происходит. */
    private fun stepProbe(): String {
        val sb = StringBuilder()
        try {
            val l = connect()
            val steps = listOf(
                StepSpec("температура слева", 33554551, 0, 0.5, 16.0, 28.0),
                StepSpec("обдув переднего ряда", 33554448, 80, 1.0, 0.0, 7.0),
                StepSpec("подогрев сиденья переднего левого", 33554453, 16, 1.0, 0.0, 3.0)
            )
            for (st in steps) {
                sb.append("== ").append(st.name).append(" ==\n")
                val before = l.getProp.invoke(l.prop, st.id, st.area)
                if (before == null) {
                    sb.append("пропуск: нет значения\n")
                    setInfo("${st.name}: нет значения, пропуск")
                    continue
                }
                val status = l.getStatus.invoke(before) as Int
                if (status != 0) {
                    sb.append("пропуск: статус ").append(status).append('\n')
                    setInfo("${st.name}: датчик не отдаёт значение (статус $status), пропуск")
                    continue
                }
                val v0 = l.getValue.invoke(before)
                val v1: Any = when (v0) {
                    is Float -> v0 + st.delta.toFloat()
                    is Int -> v0 + st.delta.toInt()
                    else -> {
                        sb.append("пропуск: тип ").append(v0?.javaClass?.name).append('\n')
                        continue
                    }
                }
                val num = (v1 as Number).toDouble()
                if (num < st.min || num > st.max) {
                    sb.append("пропуск: $num вне диапазона ${st.min}..${st.max}\n")
                    continue
                }
                val newObj = l.cpvCtor.newInstance(st.id, st.area, v1)
                val back = l.cpvCtor.newInstance(st.id, st.area, v0)
                var changed = false
                try {
                    setInfo("СЕЙЧАС: ${st.name} → $v1. Смотрите на экран климата (3 с).")
                    l.setProp.invoke(l.prop, newObj)
                    changed = true
                    sb.append("запись $v1: ok\n")
                    sb.append("сразу: ").append(l.getProp.invoke(l.prop, st.id, st.area)).append('\n')
                    Thread.sleep(500)
                    sb.append("0.5 с: ").append(l.getProp.invoke(l.prop, st.id, st.area)).append('\n')
                    Thread.sleep(2500)
                    sb.append("3 с: ").append(l.getProp.invoke(l.prop, st.id, st.area)).append('\n')
                } catch (e: Throwable) {
                    sb.append("ошибка записи: ").append(e.cause ?: e).append('\n')
                    setInfo("Ошибка записи: ${st.name}")
                } finally {
                    if (changed) {
                        setInfo("Откат: ${st.name} → $v0")
                        try {
                            l.setProp.invoke(l.prop, back)
                            sb.append("откат $v0: ok\n")
                        } catch (e: Throwable) {
                            sb.append("ошибка отката: ").append(e.cause ?: e).append('\n')
                            setInfo("ОШИБКА ОТКАТА: ${st.name}. Верните вручную.")
                        }
                    }
                }
                Thread.sleep(1000)
            }
        } catch (e: Throwable) {
            sb.append("err: ").append(e).append('\n')
        }
        return sb.toString()
    }
}
