package ru.omoda.autopilot

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.net.wifi.WifiManager
import android.os.SystemClock
import android.util.Log

data class WifiResult(val enabled: Boolean, val message: String)

class WifiController(context: Context) {
    private val appContext = context.applicationContext

    /**
     * Включает Wi-Fi через устаревший, но работающий для targetSdk 28 API
     * и проверяет фактическое состояние. Попыток ровно одна, без циклов повторов.
     */
    @Suppress("DEPRECATION")
    fun enable(): WifiResult {
        return try {
            val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifi.isWifiEnabled) {
                WifiResult(true, "уже включён")
            } else {
                val accepted = wifi.setWifiEnabled(true)
                Log.i(TAG, "setWifiEnabled(true) accepted=$accepted")
                if (!accepted) {
                    WifiResult(false, "система отклонила запрос. " + diagnostics(appContext, wifi))
                } else if (waitForState(wifi, true)) {
                    WifiResult(true, "включён")
                } else {
                    WifiResult(false, "не включился за ${AutoStartConfig.WIFI_VERIFY_TIMEOUT_MS / 1000} с")
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "No permission to change Wi-Fi state", e)
            WifiResult(false, "нет разрешения на смену состояния Wi-Fi")
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            WifiResult(false, "прервано")
        } catch (e: Exception) {
            Log.e(TAG, "Wi-Fi enable failed", e)
            WifiResult(false, "ошибка: ${e.javaClass.simpleName}")
        }
    }

    /** Собирает причину отказа прямо в приложении, без adb. */
    @Suppress("DEPRECATION")
    private fun diagnostics(context: Context, wifi: WifiManager): String {
        val airplane = Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, -1)
        val permission = if (context.checkSelfPermission("android.permission.CHANGE_WIFI_STATE") ==
            PackageManager.PERMISSION_GRANTED) "выдано" else "нет"
        val wifiOn = Settings.Global.getInt(context.contentResolver, "wifi_on", -1)
        val text = "режим полёта=$airplane, право CHANGE_WIFI_STATE=$permission, " +
            "wifi_on=$wifiOn, состояние Wi-Fi=${wifi.wifiState}"
        Log.w(TAG, "Wi-Fi refused: $text")
        return text
    }

    @Suppress("DEPRECATION")
    private fun waitForState(wifi: WifiManager, expected: Boolean): Boolean {
        val deadline = SystemClock.elapsedRealtime() + AutoStartConfig.WIFI_VERIFY_TIMEOUT_MS
        while (SystemClock.elapsedRealtime() < deadline) {
            if (wifi.isWifiEnabled == expected) return true
            Thread.sleep(POLL_MS)
        }
        return wifi.isWifiEnabled == expected
    }

    companion object {
        private const val TAG = AutoStartConfig.TAG
        private const val POLL_MS = 500L
    }
}
