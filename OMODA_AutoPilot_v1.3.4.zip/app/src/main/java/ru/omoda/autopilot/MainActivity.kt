package ru.omoda.autopilot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var settings: SettingsRepository
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsRepository(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        setContentView(ScrollView(this).also { it.addView(root) })

        root.addView(labelView("OMODA AutoPilot", 26f))
        status = labelView("", 14f, 16)
        root.addView(status)

        val run = actionButton("ЗАПУСТИТЬ") { runNow() }
        run.textSize = 22f
        run.minimumHeight = dp(96)
        val runParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        runParams.topMargin = dp(24)
        root.addView(run, runParams)

        root.addView(actionButton("Настройки") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        root.addView(actionButton("Обновить статус") { refreshStatus() })

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun runNow() {
        startService(Intent(this, AutoPilotService::class.java).setAction(AutoStartConfig.ACTION_RUN_ALL))
        toast("Запущено. Результат появится в статусе и в уведомлении")
    }

    private fun refreshStatus() {
        val autoOn = settings.isWifiEnabledOnBoot() || settings.isLaunchEnabledOnBoot()
        val lines = mutableListOf<String>()
        lines.add("Автозапуск при загрузке: " + (if (autoOn) "включён" else "выключен"))
        lines.add(
            if (settings.ranThisBoot()) "После текущего включения уже запускалось."
            else "После текущего включения ещё не запускалось."
        )
        val last = settings.lastResult()
        if (last.isNotEmpty()) {
            val time = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())
                .format(Date(settings.lastResultTime()))
            lines.add("")
            lines.add("Последний запуск $time:")
            lines.add(last)
        }
        status.text = lines.joinToString("\n")
    }
}
